# Commented part can be used for Android testing
import logging
import os
import sys
from time import sleep
from typing import Dict
import pytest
from appium import webdriver
from _pytest.reports import CollectReport
from _pytest.stash import StashKey
from py.xml import html

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src import common

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

import importlib

phase_report_key = StashKey[Dict[str, CollectReport]]()
# capabilities = {
#     "deviceName": os.environ["androidDeviceName"],
#     "platformName": os.environ["PlatformName"],
#     "platformVersion": os.environ["androidDeviceVersion"],
#     "automationName": "UiAutomator2",
#     "appPackage": os.environ["AppPackage"],
#     "appActivity": os.environ["AppActivity"],
#     "udid": os.environ["deviceId"],
#     "noReset": False,
# }

# Importing common file
objCommon = common.common()


def pytest_addoption(parser):
    parser.addoption("--tc_prefix", default="tc_", action="store", help="Test case prefix marked in all test cases")


# @pytest.fixture(scope="session")
# def locators():
#     return importlib.import_module(os.environ['AndroidLocatorFilePath'])


# @pytest.fixture(scope="session", autouse=True)
# def start_appium():
#     objCommon.startAppiumServer(os.environ["appiumPortNum"])
#     yield
#     objCommon.stopAppiumServer(os.environ["appiumPortNum"])


# @pytest.fixture
# def driver():
#     appium_server_url = os.environ["remoteURL"]
#     driver = webdriver.Remote(appium_server_url, capabilities)
#     sleep(2)
#     return driver


@pytest.fixture(autouse=True)
def tc_prefix(request):
    pytest.tc_prefix = request.config.getoption("--tc_prefix").lower()


@pytest.mark.hookwrapper
def pytest_runtest_makereport(item):
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, 'extra', [])
    marker_list = item.own_markers
    report.ticket = ''
    for i in marker_list:
        if pytest.tc_prefix == i.name[:len(pytest.tc_prefix)].lower():
            report.ticket = i.name
        pytest.description = f'{str(item.function.__doc__)}'
        report.extra = extra


@pytest.mark.optionalhook
def pytest_html_results_table_header(cells):
    cells.insert(1, html.th('Test Suite'))
    cells.insert(3, html.th('Test ID'))
    cells.insert(4, html.th('Test Category'))


@pytest.mark.optionalhook
def pytest_html_results_table_row(report, cells):
    cells.insert(1, html.td(report.nodeid.split(":")[0]))
    cells.insert(3, html.td(report.ticket))
    cells.insert(4, html.td(report.nodeid.split(":")[0].split(" ")[0].split("/")[0]))
