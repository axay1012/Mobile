import pytest
import time
import logging
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

web_url = 'https://www.amazon.in/'
logger = logging.getLogger(__name__)
driver = webdriver.Chrome()
driver.get(web_url)

search_bar = 'nav-search-submit-button'
homePage_slider = 'twotabsearchtextbox'
result = '(//*[@class="a-color-state a-text-bold"])'
firstCheckbox = '(//*[@class="a-icon a-icon-checkbox"])[3]'
amazon_logo = 'nav-logo-sprites'

def validate_homescreen():
    try:
        driver.maximize_window()
        time.sleep(5)
        logger.info('Amazon Home page should display')
        is_visible = driver.find_element_by_id(search_bar).is_displayed()
        assert is_visible, 'Amazon logo is not displayed'
        is_validated = True
    except Exception as e:
        is_validated = False
        logger.debug(e)
    return is_validated

def search_for_watch():
    try:
        logger.info('Search bar should display')
        search_bar_status = driver.find_element_by_id(homePage_slider)
        assert search_bar_status, 'Search bar is not displayed'
        search_bar_status.clear()
        search_bar_status.send_keys('Watch')
        search_bar_status.send_keys(Keys.RETURN)
        time.sleep(5)
        is_visible = driver.find_element_by_xpath(result)
        assert is_visible, 'Result not appeared on screen'
        is_validated = True
    except Exception as e:
        is_validated = False
        logger.debug(e)
    return is_validated

def apply_filter():
    try:
        logger.info('Filter should display')
        element = driver.find_element_by_xpath(firstCheckbox)
        element.click()
        time.sleep(5)
        is_validated = True
    except Exception as e:
        is_validated = False
        logger.debug(e)
    return is_validated

def verify_result():
    try:
        logger.info('Verify result of applied filter')
        is_visible = driver.find_element_by_xpath(result)
        assert is_visible
        is_validated = True
    except Exception as e:
        is_validated = False
        logger.debug(e)
    return is_validated

def click_on_amazon_logo():
    try:
        logger.info('Click on the Amazone logo')
        is_visible = driver.find_element_by_id(amazon_logo).is_displayed()
        assert is_visible, 'Amazon logo is not displayed'
        driver.find_element_by_id(amazon_logo).click()
        is_validated = True
    except Exception as e:
        is_validated = False
        logger.debug(e)
    return is_validated

@pytest.mark.TC_01
def test_amazon_web():
    assert validate_homescreen()
    assert search_for_watch()
    assert apply_filter()
    assert verify_result()
    assert click_on_amazon_logo()
    assert validate_homescreen()
    driver.close()
