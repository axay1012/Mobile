from appium.webdriver.common.mobileby import MobileBy as By


amazon_select_eng_language = (By.ACCESSIBILITY_ID, "Select English")
amazon_confirm_language = (By.ID, "in.amazon.mShop.android.shopping:id/continue_button")
amazon_skip_sign_in_button = (By.ID, "in.amazon.mShop.android.shopping:id/skip_sign_in_button")
amazon_search_bar_validation = (By.ID, "in.amazon.mShop.android.shopping:id/chrome_search_hint_view")

amazon_search_on_bar = (By.ID, "in.amazon.mShop.android.shopping:id/rs_search_src_text")
amazon_enable_prime = (By.ACCESSIBILITY_ID, "Prime Eligible")
amazon_first_product_from_result = (By.XPATH, '//android.view.View[@content-desc="product-detail"][1]')
amazon_first_product_title = (By.XPATH, '//android.widget.TextView[@resource-id="title"]')