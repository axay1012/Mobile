#!/usr/bin/env python

import re
import subprocess
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../../../src/common/')))
import common


class MobileCommon:

    def __init__(self):
        self.data = None
        self.devices = []
        self.objCommon = common.common()
        self.deviceDataDict = {}

    def _adbDevices(self):
        """
        Gives the list of connected android devices
        """
        return self.objCommon.splitLines(subprocess.check_output(["adb", "devices"]).decode('utf-8'))

    def _listOfDevices(self):
        """
        Performs string operation on list of devices
        """
        for self.data in self.getdevices[1:]:
            deviceId, deviceStatus = re.split(r'\s+', self.data, maxsplit=1)
            self.deviceDataDict[deviceId] = deviceStatus
        self.devices.append(self.deviceDataDict)
        return self.devices

    def iOSDeviceProductId(self):
        """
        Give the List of UDIDs of connected iPhone Devices
        """
        try:
            iOSDeviceId = subprocess.Popen(["idevice_id", "-l"], stdout=subprocess.PIPE)
            iOSDeviceId = iOSDeviceId.communicate()[0].decode("utf-8").split()
            return iOSDeviceId
        except Exception as err:
            print("Error: Failed to Get the iPhone ProductID", err)
            return False

    def iOSDeviceProductName(self, deviceUDIDList):
        """
        Give the list of name of connected iPhone Devices
        """
        try:
            iOSDeviceNameList = []
            for udid in deviceUDIDList:
                iOSDevice = subprocess.Popen(["ideviceinfo", "-k", "DeviceName", "-u", udid], stdout=subprocess.PIPE)
                iOSDeviceName = iOSDevice.communicate()[0].decode("utf-8").split()[-1]
                iOSDeviceNameList.append(iOSDeviceName)
            return iOSDeviceNameList
        except Exception as err:
            print("Error: Failed to Get the iPhone Product Name", err)
            return False

    def iOSDeviceProductVersion(self, deviceUDIDList):
        """
        Give the list of Product Version of connected iPhone Devices
        """
        try:
            iOSDeviceVersionList = []
            for udid in deviceUDIDList:
                iOSDevice = subprocess.Popen(["ideviceinfo", "-k", "ProductVersion", "-u", udid],
                                             stdout=subprocess.PIPE)
                iOSDeviceVersion = iOSDevice.communicate()[0].decode("utf-8").split()[-1]
                iOSDeviceVersionList.append(iOSDeviceVersion)
            return iOSDeviceVersionList
        except Exception as err:
            print("Error: Failed to Get the iPhone Product Version", err)
            return False

    def iOSDeviceProductClass(self, deviceUDIDList):
        """
        Give the list of Product Class of connected iPhone Devices
        """
        try:
            iOSDeviceClassList = []
            for udid in deviceUDIDList:
                iOSDevice = subprocess.Popen(["ideviceinfo", "-k", "DeviceClass", "-u", udid],
                                             stdout=subprocess.PIPE)
                iOSDeviceClass = iOSDevice.communicate()[0].decode("utf-8").split()[-1]
                iOSDeviceClassList.append(iOSDeviceClass)
            return iOSDeviceClassList
        except Exception as err:
            print("Error: Failed to Get the Device Product Class", err)
            return False

    def iOSDeviceUninstall(self, installedAPPID):
        """
        Uninstall application on connected iPhone Device
        """
        try:
            UUID = os.getenv('deviceId')
            subprocess.Popen(["ideviceinstaller", "-u", UUID, "--uninstall", installedAPPID],
                             stdout=subprocess.PIPE)
            return True
        except Exception as err:
            print("Error: Failed to Uninstall the installed application", err)
            return False

    def checkAndroidDeviceConnection(self, adbPort):
        """
        Gives the list of device IDs of connected android devices.
        Returns None in case of no device found.
        """
        try:
            self.objCommon.startADBServer(adbPort)
            self.getdevices = self._adbDevices()
            return self._listOfDevices()
        except Exception as err:
            print("Error: Failed to get the connected Android Device", err)
            return False
