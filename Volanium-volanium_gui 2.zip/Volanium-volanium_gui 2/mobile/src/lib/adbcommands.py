import os
import subprocess
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../../../src/')))
import common


class adbcommands:

    def __init__(self):
        self.data = None
        self.objCommonFile = common.common()

    def getMobileVersion(self, deviceid):
        """
        This Method will get Mobile Device Version
        :param deviceid:
        :return: Success : Mobile version Failed: False
        """
        try:
            adbCMD = "adb -s " + str(deviceid) + " shell getprop ro.build.version.release"
            MobileVersion = subprocess.getoutput(adbCMD)
            if "error" in MobileVersion:
                return False
            else:
                return MobileVersion
        except Exception as err:
            print("ERROR in getMobileVersion Method ", err)
            return False

    def getMobileModel(self, deviceid):
        """
        This Method will get Mobile Device Version
        :param deviceid:
        :return: Success : Mobile version Failed: False
        """
        try:
            adbCMD = "adb -s " + str(deviceid) + " shell getprop ro.product.model"
            mobileModel = subprocess.getoutput(adbCMD)
            if "error" in mobileModel:
                return False
            else:
                return mobileModel
        except Exception as err:
            print("ERROR in getMobileModel Method ", err)
            return False

    def getAppVersion(self, deviceid, appPackage):
        """
        This Method will get the installed app version
        :param deviceid:
        :param appPackage:
        :return: Success : Mobile version Failed: False
        """
        try:
            adbCMD = "adb -s " + str(deviceid) + " shell dumpsys package " + str(appPackage) + " | grep versionName"
            appVersion = subprocess.getoutput(adbCMD)
            trimAppVersion = appVersion.split("=")
            if "error" in str(trimAppVersion[1]):
                return False
            else:
                return str(trimAppVersion[1])
        except Exception as err:
            print("ERROR in get app version Method ", err)
            return False

    def openNotificationBar(self, deviceid):
        """
        This Method will open Notification Bar on Mobile Phone
        :return:
        """
        try:
            adbCMD = "adb -s " + str(deviceid) + " shell service call statusbar 1"
            Notification = subprocess.getoutput(adbCMD)
            if "error" in Notification:
                return False
            else:
                return Notification
        except Exception as err:
            print("ERROR in openNotificationBar Method ", err)
            return False

    def closeNotificationBar(self):
        """
        This Method will close Notification Bar on Mobile Phone
        :return:
        """
        try:
            adbCMD = "adb shell cmd statusbar collapse"
            closeNotificationStatus = subprocess.getoutput(adbCMD)
            return True
        except Exception as err:
            print("ERROR in closeNotificationBar Method ", err)
            return False

    def putAppInBackground(self):
        """
        This Method will put all the application into background using adb command
        That means it will move to home screen.
        :return:
        """
        try:
            adbCMD = "adb shell input keyevent 3"
            Notification = subprocess.getoutput(adbCMD)
            if "error" in Notification:
                return False
            else:
                return True
        except Exception as err:
            print("ERROR in openNotificationBar Method ", err)
            return False

    def takeAppInForeground(self):
        """
        This Method will take the application into foreground using adb command
        That means it will move to application from home screen.
        :return:
        """
        try:
            adbCMD = "adb shell monkey -p " + os.environ['AppPackage'] + " 1"
            Notification = subprocess.getoutput(adbCMD)
            if "error" in Notification:
                return False
            else:
                return True
        except Exception as err:
            print("ERROR in Taking App In Foreground Method ", err)
            return False

    def closeAppWithoutForceStop(self):
        """
        This Method will close the application without force-stopping it
        :return:
        """
        try:
            adbCMD = "adb shell am kill " + os.environ['AppPackage']
            Notification = subprocess.getoutput(adbCMD)
            if "error" in Notification:
                return False
            else:
                return True
        except Exception as err:
            print("ERROR in Closing App", err)
            return False

    def pressAEnterKey(self, deviceid):
        """
        This Method will press Enter Key
        :param deviceid:
        :return:
        """
        try:
            adbCMD = "adb -s " + str(deviceid) + " shell input keyevent 66"
            Notification = subprocess.getoutput(adbCMD)
            if "error" in Notification:
                return False
            else:
                return Notification
        except Exception as err:
            print("ERROR in Press Enter Key Method ", err)
            return False

    def getBluetoothStatus(self):
        """
        This Method will get the Bluetooth status
        :return: Success : Bluetooth Status Failed: False
        """
        try:
            adbCMD = "adb shell settings get global bluetooth_on"
            BTStatus = subprocess.getoutput(adbCMD)
            if "error" in BTStatus:
                return False
            else:
                return BTStatus
        except Exception as err:
            print("ERROR in Getting Bluetooth Status", err)
            return False

    def turnBluetoothOn(self):
        """
        This Method will turn on the Bluetooth
        :return:
        """
        try:
            adbCMD = "adb shell am start -a android.bluetooth.adapter.action.REQUEST_ENABLE"
            status = subprocess.getoutput(adbCMD)
            if "error" in status:
                return False
            else:
                return True
        except Exception as err:
            print("ERROR while Turning on Bluetooth", err)
            return False

    def turnBluetoothOff(self):
        """
        This Method will turn off the Bluetooth
        :return:
        """
        try:
            adbCMD = "adb shell am start -a android.bluetooth.adapter.action.REQUEST_DISABLE"
            status = subprocess.getoutput(adbCMD)
            if "error" in status:
                return False
            else:
                return True
        except Exception as err:
            print("ERROR while Turning off Bluetooth", err)
            return False


if __name__ == '__main__':
    objadbCMD = adbcommands()
