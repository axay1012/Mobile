import logging
from time import sleep

from mobile.resource.android.appium_common_utils import *
logger = logging.getLogger(__name__)


def validate_amazon_search_result(driver, locators):
    click_on_element(driver, locators.amazon_select_eng_language)
    click_on_element(driver, locators.amazon_confirm_language)
    logger.info("Selected English language")
    click_on_element(driver, locators.amazon_skip_sign_in_button)
    logger.info("Skipped sign in")
    assert is_element_visible(driver, locators.amazon_search_bar_validation)

    logger.info("Validated search bar, Home page is displayed")
    click_on_element(driver, locators.amazon_search_bar_validation)
    set_input_value(driver, locators.amazon_search_on_bar, "watch")
    logger.info("Searching on amazon...")
    driver.press_keycode(66)
    sleep(2)
    click_on_element(driver, locators.amazon_enable_prime)
    sleep(2)
    logger.info("Enabled prime")
    swipe_to_get_element_visible(driver, locators.amazon_first_product_from_result, swipe_only=True, swipe=3)
    sleep(2)
    logger.info("Found search results")
    click_on_element(driver, locators.amazon_first_product_from_result)
    sleep(3)
    logger.info("Clicked on first product")
    actual_text = WebDriverWait(driver, 15).until(EC.presence_of_element_located(locators.amazon_first_product_title)).text
    logger.info(f"Product title: {actual_text}")
    assert "watch" in actual_text.lower()
    
