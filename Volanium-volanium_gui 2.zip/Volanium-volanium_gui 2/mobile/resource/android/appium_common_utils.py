from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from logging import getLogger

logger = getLogger()
DEFAULT_TIMEOUT = 10


def is_text_visible(driver, element, text, timeout=DEFAULT_TIMEOUT):
    try:
        actual_text = WebDriverWait(driver, timeout).until(EC.presence_of_element_located(element)).text
        logger.info(f"Actual:{actual_text}; Expected: {text}")
        return actual_text == text
    except Exception as e:
        logger.warning(e)
        return False


def is_element_visible(driver, element, timeout=DEFAULT_TIMEOUT):
    try:
        is_visible = WebDriverWait(driver, timeout).until(EC.presence_of_element_located(element)).is_displayed()
    except Exception as e:
        is_visible = False
        logger.debug(e)
    return is_visible


def get_element(driver, element, timeout=DEFAULT_TIMEOUT):
    return WebDriverWait(driver, timeout).until(EC.presence_of_element_located(element))


def set_input_value(driver, element, input_value, timeout=DEFAULT_TIMEOUT):
    logger.info(f"Enter value: {input_value}")
    element_to_set_input = WebDriverWait(driver, timeout).until(EC.presence_of_element_located(element))
    element_to_set_input.send_keys(input_value)


def click_on_element(driver, element, timeout=DEFAULT_TIMEOUT):
    element_to_click = WebDriverWait(driver, timeout).until(EC.presence_of_element_located(element))
    element_to_click.click()


def take_screenshot(driver, file_name):
    driver.save_screenshot(file_name)


def if_element_visible_click_it(driver, element, timeout=DEFAULT_TIMEOUT):
    is_visible = is_element_visible(driver, element, timeout=timeout)
    if is_visible:
        click_on_element(driver, element)


def get_element_list(driver, element):
    return driver.find_elements(element)


def swipe_to_get_element_visible(driver, element, swipe=1, swipe_only=False):
    for i in range(1, swipe):
        if not swipe_only:
            if is_element_visible(driver, element):
                return True
        driver.swipe(150, 400, 150, 200, 1000)
        logger.info(f"Swipe count: {i}")
    if swipe_only:
        return True
    return False


