#!/usr/bin/env python

############################################################################
# Handler is a intermediate stage between TestDriver and iOS Test Executor
# Handler Performs below operations:
# 1. Initialize iOS Test Executor
# 2. Set iOS device prerequisite
# 3. Trigger Test execution over iOS device
############################################################################

import sys
import os
import time
import pathlib
from multiprocessing import Process

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../mobile/src/lib')))

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../src/')))

import common
import TestReportGenerator
import MobileCommon


class IosHandler:

    def __init__(self):
        self.configDict = None
        self.objiOSconn = MobileCommon.MobileCommon()
        self.objCommon = common.common()
        self.objTRG = TestReportGenerator.TestReportGenerator()
        self.exe_method = ""

    def setiOSPrerequisite(self):
        """
        Set Prerequsite to start iOS device execution
        """
        try:
            # Get Connected Mobile Device List
            iOSDeviceIdList = self.objiOSconn.iOSDeviceProductId()

            # Get connected mobile device Name List
            iOSDeviceNameList = self.objiOSconn.iOSDeviceProductName(iOSDeviceIdList)

            # Get connected mobile device version list
            iOSDeviceVersionList = self.objiOSconn.iOSDeviceProductVersion(iOSDeviceIdList)

            # Get connected mobile device class list
            iOSDeviceClassList = self.objiOSconn.iOSDeviceProductClass(iOSDeviceIdList)

            if not iOSDeviceIdList:
                print("""
                          -----------------------------------------------------------------
                          Device Not Connected, Please connect your device with test system
                          ------------------------------------------------------------------
                          """)
                return False
            else:
                return iOSDeviceIdList, iOSDeviceNameList, iOSDeviceVersionList, iOSDeviceClassList
        except Exception as err:
            print("ERROR: Set Prerequisite for iOS Failed", err)
            return False

    def getConfigData(self, configDict):
        """
        Parse config data from Config dict
        """
        try:
            os.environ["TestIteration"] = self.configDict["Configuration"]["SetupConfiguration"]["Common"]["TestIteration"]
            os.environ["PlatformName"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Platform"]
            os.environ["AppVersion"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"]["iOS"][
                "AppVersion"]
            os.environ["IpaPath"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"]["iOS"][
                "IpaPath"]
            os.environ["XcodeOrgId"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"]["iOS"][
                "XcodeOrgId"]
        except Exception as err:
            print("ERROR: Please Provide Correct AppConfiguration And AppCredential Data To config.xml File")
            print("ERROR: ", err)
            sys.exit(1)

        self._configDataValidation()

    def xmlDatatoDict(self, fileName):
        Status = self.objCommon.fileExists(fileName)
        if Status:
            self.configDict = self.objCommon.xmlParser(fileName)
            self.getConfigData(self.configDict)

    def _configDataValidation(self):
        """
        Validate given configuration data
        """
        try:
            if os.environ["PlatformName"].lower() != "ios":
                print("ERROR: Please Provide PlatformName As: ios")
                sys.exit(1)
            if not self.objCommon.fileExists(os.environ["IpaPath"]):
                print("ERROR: .ipa file Does Not Exists over " + os.environ["IpaPath"] + " Path !!")
                sys.exit(1)
        except Exception as err:
            print("ERROR: Config Data Validation Failed", err)
            return False

    def triggeriOSTestExecution(self, fileName, testSuiteToExec, testIncludeTag, testExcludeTag):
        """
        Trigger test execution over iOS device
        """
        try:
            appiumPortNum = 4723
            wdaLocalPort = 8100
            systemPort = 8200

            # Get the XML config file into dict
            self.xmlDatatoDict(fileName)

            # Get the device connected UID
            (DeviceID, DeviceName, DeviceVersion, DeviceClass) = self.setiOSPrerequisite()

            # Get the number of connected iOS devices and list of test suites to execute
            totalDevices = len((list(DeviceID)))
            allSuiteList = str(testSuiteToExec).split()

            for index, (deviceId, deviceName, deviceVersion, deviceClass) in enumerate(
                    zip(DeviceID, DeviceName, DeviceVersion, DeviceClass)):
                print("Connected Device ID is %s " % deviceId)

                appiumPortNum = int(appiumPortNum) + 5
                wdaLocalPort = int(wdaLocalPort) + 5
                systemPort = int(systemPort) + 5

                os.environ['deviceId'] = deviceId
                os.environ['deviceName'] = deviceName
                os.environ['deviceVersion'] = deviceVersion
                os.environ['deviceClass'] = deviceClass
                os.environ['appiumPortNum'] = str(appiumPortNum)
                os.environ['wdaLocalPort'] = str(wdaLocalPort)
                os.environ['systemPort'] = str(systemPort)

                # Get RemoteURL
                os.environ['remoteURL'] = self.objCommon.getAppiumRemoteUrl(os.environ['appiumPortNum'])

                # Build locator for iOS App
                self.setiOSLocatorPath()

                mobileDevice = str(os.environ['deviceName']) + " " + str(os.environ['deviceVersion'])

                # Get the list of test suite(s) to execute
                currentSuiteList = allSuiteList[:int(len(allSuiteList) / totalDevices)]
                testSuiteToExec = ' '.join([str(elem) for elem in currentSuiteList])

                # Reduce one iOS device and test suite(s) being executed
                totalDevices = totalDevices - 1
                allSuiteList = [i for i in allSuiteList if i not in currentSuiteList]

                globals()['process%s' % index] = Process(target=self.scriptExecutor,
                                                         args=(os.environ['deviceId'], os.environ['remoteURL'],
                                                               os.environ['appiumPortNum'], os.environ['wdaLocalPort'],
                                                               os.environ['systemPort'], testSuiteToExec, testIncludeTag,
                                                               testExcludeTag, mobileDevice))
                globals()['process%s' % index].start()
                time.sleep(5)

            # Wait till forked process completion
            for index, deviceId in enumerate(DeviceID):
                globals()['process%s' % index].join()
            return True
        except Exception as err:
            print("ERROR: Trigger ios Test Execution Failed ", err)
            return False

    def setiOSLocatorPath(self):
        """
        This Method will set the iOS locator path into os environment
        :return: True if setting environment variable is success, else False if exception found.
        """
        try:
            iOSDeviceVersion = os.environ["deviceVersion"]
            print("Connected Device Version is " + os.environ["deviceVersion"])
            print("Connected Device Type is " + os.environ["deviceClass"])

            iOS15_locators = {
                #'locator': f"mobile.locators.ios.amazon15locators"  # Use the locator files like this while using the pytest framework
                'locator': "${CURDIR}/../../locators/ios/ios15locators.robot"   # Use the locator files like this while using the Robot framework
            }

            iOS16_locators = {
                'locator': "${CURDIR}/../../locators/ios/ios16locators.robot"
            }

            # iOS Versions
            iOS15OSList = ["15.0", "15.0.1", "15.0.2", "15.1", "15.1.1", "15.2", "15.2.1", "15.3", "15.3.1", "15.4",
                           "15.4.1", "15.5", "15.6"]
            iOS16OSList = ["16.0", "16.0.1", "16.1", "16.1.1", "16.2", "16.2.1"]

            if iOSDeviceVersion in iOS15OSList:
                os.environ["iOSLocatorFilePath"] = iOS15_locators.get('locator')
                print("The selected locator path is: " + os.environ["iOSLocatorFilePath"])
                return True
            elif iOSDeviceVersion in iOS16OSList:
                os.environ["iOSLocatorFilePath"] = iOS16_locators.get('locator')
                print("The selected locator path is: " + os.environ["iOSLocatorFilePath"])
                return True
            else:
                print("Please connect supported iOS version with the test system")

        except Exception as err:
            print("ERROR: Failed to set iOS device version environment variable ", err)
            return False

    def robotCommandCreator(self, execRunCmd, outputXml, logHtml, reportHtml, allIncludeTagList, allExcludeTagList,
                            deviceId, remoteUrl, appiumPortNum, wdaLocalPort, systemPort):
        """
        This method will create robot execution command.
        """
        robotExecCmd = "{0} -o {1} -l {2} -r {3} -v {4} -v {5} -v {6} -v {7} -v {8}".format(execRunCmd, outputXml, logHtml,
                                                                                            reportHtml, deviceId, remoteUrl,
                                                                                            appiumPortNum, wdaLocalPort, systemPort)

        # It will Include Tags if there are any
        for tag in allIncludeTagList:
            robotExecCmd = "{0} -i {1}".format(robotExecCmd, str(tag))
        # It will Exclude Tags if there are any
        for tag in allExcludeTagList:
            robotExecCmd = "{0} -e {1}".format(robotExecCmd, str(tag))
        return robotExecCmd

    def javaCommandCreator(self, logHtml, outputXml, outputJSON, testSuite):
        """
        This method will create Java execution command.
        """
        # Extract testsuite from current folder
        testSuiteToExec = "/".join((testSuite.split("/"))[1::])
        javaExecCmd = "mvn test" + " -Dcucumber.features=" + testSuiteToExec + \
                      " -Dcucumber.plugin=''pretty', 'html:../" + logHtml + "','junit:../" + \
                      outputXml + "','json:../" + outputJSON + "','"
        return javaExecCmd

    def pytestCommandCreator(self, execRunCmd, outputXml, logHtml):
        """
        This method will create Pytest execution command.
        """
        pytestExecCmd = execRunCmd + " --junit-xml=" + outputXml + " --html=" + logHtml
        return pytestExecCmd

    def scriptExecutor(self, deviceId, remoteUrl, appiumPortNum, wdaLocalPort, systemPort, testSuiteToExec,
                       testIncludeTag, testExcludeTag, mobileDevice):
        """
        This method will execute test suite on a specific ios device.
        """
        try:
            global logReportDir
            detailTestReportDir = ""
            allSuiteList = str(testSuiteToExec).split()
            allIncludeTagList = str(testIncludeTag).split()
            allExcludeTagList = str(testExcludeTag).split()
            execStartTime = self.objCommon.getCurrentTime("%Y%m%d%H%M%S")
            os.environ["execStartTime"] = execStartTime
            if execStartTime:
                logReportDir = "logs/{0}/".format(str(execStartTime))
                detailTestReportDir = "reports/{0}/".format(str(execStartTime))
            os.environ["logsFolder"] = logReportDir
            os.mkdir(os.environ["logsFolder"])
            os.mkdir(detailTestReportDir)
            # Trigger to test suite execution
            for testSuite in allSuiteList:
                tSuiteName = os.path.basename(testSuite).split(".")[0]
                detailTestReportSuiteDir = detailTestReportDir + tSuiteName + "/"
                os.mkdir(detailTestReportSuiteDir)
                file_extension = pathlib.Path(testSuite).suffix
                exeMethod = file_extension
                if exeMethod[1:] == 'py':
                    os.environ["exeMethod"] = self.exe_method = 'pytest'
                elif exeMethod[1:] == 'feature':
                    os.environ["exeMethod"] = self.exe_method = 'java'
                elif exeMethod[1:] == 'robot':
                    os.environ["exeMethod"] = self.exe_method = 'robot'
                for i in range(int(os.environ["TestIteration"])):
                    os.environ["Iteration"] = str(i + 1)
                    logDir = (os.environ["logsFolder"] + tSuiteName + str("_A" + str(i + 1)) + "/")
                    os.mkdir(logDir)
                    os.environ["logDir"] = logDir
                    execRunCmd = self.exe_method
                    # Creating General Output Files Names
                    outputXml = "{0}output_{1}_{2}_{3}.xml".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                   str("A" + str(i + 1)))
                    logHtml = "{0}log_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                               str("A" + str(i + 1)))
                    reportHtml = "{0}report_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))
                    outputJSON = "{0}output_{1}_{2}_{3}.json".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))

                    # Create .reportdata.txt file
                    self.objTRG.create_report_file(
                        self.configDict, logDir, mobileAppVer=os.environ["AppVersion"]
                    )

                    # Creating execution commands according to the languages
                    if self.exe_method == "robot":
                        execRunCmd = self.robotCommandCreator(execRunCmd, outputXml, logHtml, reportHtml,
                                                              allIncludeTagList, allExcludeTagList, deviceId, remoteUrl,
                                                              appiumPortNum, wdaLocalPort, systemPort)
                    elif self.exe_method == "pytest":
                        execRunCmd = self.pytestCommandCreator(
                            self.exe_method, outputXml, logHtml
                        )
                    elif self.exe_method == "java":
                        os.chdir("test_cucumber")
                        execRunCmd = self.javaCommandCreator(logHtml, outputXml, outputJSON, str(testSuite))

                    # Add Testsuite to the execution command
                    if self.exe_method != "java":
                        execRunCmd = "{0} {1}".format(execRunCmd, str(testSuite))

                    # Start Execution
                    self.objCommon.startExec(execRunCmd)
                    if self.exe_method == "java":
                        os.chdir("..")
                    reportCSVFolder = detailTestReportSuiteDir + "/Vol_DetailTestReport"

                    if self.exe_method == "robot":
                        self.objTRG.generateCsvReport(outputXml, reportCSVFolder)
                    elif self.exe_method == "pytest":
                        self.objTRG.generatePyTestCsvReport(logHtml, reportCSVFolder)
                    elif self.exe_method == "python3":
                        pass
                    elif self.exe_method == "java":
                        self.objTRG.generateCucumberTestCsvReport(outputJSON, reportCSVFolder)

                    if self.exe_method != "java":
                        self.objCommon.xmlToJson(outputXml, outputJSON)
                        self.objCommon.updateJson(outputJSON, self.objCommon.getCurrentEpochTime(), 'ios')
                    with open(".dynamoDBfilelist.txt", "a") as f:
                        f.write("%s\n" % (os.environ["CurrentPath"] + "/" + outputJSON))
                self.objTRG.getTestCategory(
                    tSuiteName, mobileDevice, os.environ["PlatformName"]
                )
        except Exception as err:
            print("ERROR : Execution ", err)
