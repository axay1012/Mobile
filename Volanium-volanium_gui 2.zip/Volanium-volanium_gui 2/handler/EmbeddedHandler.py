#!/usr/bin/env python

############################################################################
# Handler is a intermediate stage between TestDriver and Embedded Test Executor
# Handler Performs below operations:
# 1. Initialize Embedded Test Executor
# 2. Trigger Test execution on Embedded
############################################################################

import sys
import os
import pathlib

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../embedded/')))

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../src/common/')))

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             '../src/reportgenerator/')))

import common
import TestReportGenerator


class EmbeddedHandler:

    def __init__(self):
        self.objCommon = common.common()
        self.objTRG = TestReportGenerator.TestReportGenerator()
        self.exe_method = ""

    def getConfigData(self, configDict):
        """
        Parse config data from Config dict
        """
        try:
            os.environ["Environment"] = configDict['Configuration']['SetupConfiguration']['Common']['Environment']
            os.environ["TestIteration"] = configDict['Configuration']['SetupConfiguration']['Common']['TestIteration']
            os.environ["ReleaseBranch"] = configDict['Configuration']['SetupConfiguration']['Common']['ReleaseBranch']
            os.environ["DUT_DeviceName"] = \
                configDict["Configuration"]["SetupConfiguration"]["DUTDetails"]["projectDevice1"]["Name"]
            os.environ["DUT_ID"] = configDict["Configuration"]["SetupConfiguration"]["DUTDetails"]["projectDevice1"][
                "ID"]
            os.environ["DUT_FWversion"] = \
                configDict["Configuration"]["SetupConfiguration"]["DUTDetails"]["projectDevice1"]["FirmwareVersion"]
        except Exception as err:
            print("ERROR: Please Provide Correct WebConfiguration Data To config.xml File")
            print("ERROR: ", err)
            sys.exit(1)

    def xmlDatatoDict(self, fileName):
        Status = self.objCommon.fileExists(fileName)
        if Status:
            self.configDict = self.objCommon.xmlParser(fileName)
            self.getConfigData(self.configDict)

    def robotCommandCreator(self, execRunCmd, outputXml, logHtml, reportHtml, allIncludeTagList, allExcludeTagList):
        """
        This method will create robot execution command.
        """
        robotExecCmd = "{0} -o {1} -l {2} -r {3}".format(execRunCmd, outputXml, logHtml, reportHtml)

        # It will Include Tags if there are any
        for tag in allIncludeTagList:
            robotExecCmd = "{0} -i {1}".format(robotExecCmd, str(tag))
        # It will Exclude Tags if there are any
        for tag in allExcludeTagList:
            robotExecCmd = "{0} -e {1}".format(robotExecCmd, str(tag))
        return robotExecCmd

    def javaCommandCreator(self, logHtml, outputXml, outputJSON, testSuite):
        """
        This method will create Java execution command.
        """
        # Extract testsuite from current folder
        testSuiteToExec = "/".join((testSuite.split("/"))[1::])
        javaExecCmd = "mvn test" + " -Dcucumber.features=" + testSuiteToExec + \
                      " -Dcucumber.plugin=''pretty', 'html:../" + logHtml + "','junit:../" + \
                      outputXml + "','json:../" + outputJSON + "','"
        return javaExecCmd

    def pytestCommandCreator(self, execRunCmd, outputXml, logHtml):
        """
        This method will create Pytest execution command.
        """
        pytestExecCmd = execRunCmd + " --junit-xml=" + outputXml + " --html=" + logHtml
        return pytestExecCmd

    def triggerEmbeddedTestExecution(self, fileName, testSuiteToExec, testIncludeTag, testExcludeTag):
        """
        Trigger Embedded Test Execution on the device
        """
        try:

            # Get the XML config file into dict
            self.xmlDatatoDict(fileName)

            global logReportDir
            detailTestReportDir = ""
            allSuiteList = str(testSuiteToExec).split()
            allIncludeTagList = str(testIncludeTag).split()
            allExcludeTagList = str(testExcludeTag).split()
            execStartTime = self.objCommon.getCurrentTime("%Y%m%d%H%M%S")
            os.environ['execStartTime'] = execStartTime
            if execStartTime:
                logReportDir = 'logs/{0}/'.format(str(execStartTime))
                detailTestReportDir = 'reports/{0}/'.format(str(execStartTime))
            os.environ['logDir'] = logReportDir
            os.mkdir(os.environ['logDir'])
            os.mkdir(detailTestReportDir)
            # Trigger to test suite execution
            for testSuite in allSuiteList:
                tSuiteName = os.path.basename(testSuite).split(".")[0]
                detailTestReportSuiteDir = detailTestReportDir + tSuiteName + '/'
                os.mkdir(detailTestReportSuiteDir)
                file_extension = pathlib.Path(testSuite).suffix
                exeMethod = file_extension
                if exeMethod[1:] == 'py':
                    os.environ["exeMethod"] = self.exe_method = 'pytest'
                elif exeMethod[1:] == 'feature':
                    os.environ["exeMethod"] = self.exe_method = 'java'
                elif exeMethod[1:] == 'robot':
                    os.environ["exeMethod"] = self.exe_method = 'robot'
                for i in range(int(os.environ['TestIteration'])):
                    os.environ['Iteration'] = str(i + 1)
                    logDir = (os.environ["logsFolder"] + tSuiteName + str("_A" + str(i + 1)) + "/")
                    os.mkdir(logDir)
                    os.environ["logDir"] = logDir
                    execRunCmd = self.exe_method
                    # Creating General Output Files Names
                    outputXml = "{0}output_{1}_{2}_{3}.xml".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                   str("A" + str(i + 1)))
                    logHtml = "{0}log_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                               str("A" + str(i + 1)))
                    reportHtml = "{0}report_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))
                    outputJSON = "{0}output_{1}_{2}_{3}.json".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))

                    # Creating execution commands according to the languages
                    if self.exe_method == "robot":
                        execRunCmd = self.robotCommandCreator(execRunCmd, outputXml, logHtml, reportHtml,
                                                              allIncludeTagList, allExcludeTagList)
                    elif self.exe_method == "pytest":
                        execRunCmd = self.pytestCommandCreator(
                            self.exe_method, outputXml, logHtml
                        )
                    elif self.exe_method == "java":
                        os.chdir("test_cucumber")
                        execRunCmd = self.javaCommandCreator(logHtml, outputXml, outputJSON, str(testSuite))

                    # Add Testsuite to the execution command
                    if self.exe_method != "java":
                        execRunCmd = "{0} {1}".format(execRunCmd, str(testSuite))

                    # Start Execution
                    self.objCommon.startExec(execRunCmd)
                    if self.exe_method == "java":
                        os.chdir("..")
                    reportCSVFolder = detailTestReportSuiteDir + "/Vol_DetailTestReport"

                    if self.exe_method == "robot":
                        self.objTRG.generateCsvReport(outputXml, reportCSVFolder)
                    elif self.exe_method == "pytest":
                        self.objTRG.generatePyTestCsvReport(logHtml, reportCSVFolder)
                    elif self.exe_method == "python3":
                        pass
                    elif self.exe_method == "java":
                        self.objTRG.generateCucumberTestCsvReport(outputJSON, reportCSVFolder)

                    if self.exe_method != "java":
                        self.objCommon.xmlToJson(outputXml, outputJSON)
                        self.objCommon.updateJson(outputJSON, self.objCommon.getCurrentEpochTime(), 'android')
                    with open(".dynamoDBfilelist.txt", "a") as f:
                        f.write("%s\n" % (os.environ["CurrentPath"] + "/" + outputJSON))
                self.objTRG.getTestCategory(tSuiteName, mobileDevice=None, platform=None)
        except Exception as err:
            print("ERROR : Execution ", err)
