#!/usr/bin/env python

############################################################################
# Handler is a intermediate stage between TestDriver and ANDROID Test Executor
# Handler Performs below operations:
# 1. Initialize ANDROID Test Executor
# 2. Set ANDROID device prerequisite
# 3. Trigger Test execution over ANDROID device
############################################################################

import os
import subprocess
import sys
import time
import pathlib
from multiprocessing import Process

sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname(__file__), "../mobile/src/lib"))
)

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))
import common
import TestReportGenerator
import MobileCommon
import adbcommands


class AndroidHandler:
    def __init__(self):
        self.objAndroidconn = MobileCommon.MobileCommon()
        self.objCommon = common.common()
        self.objTRG = TestReportGenerator.TestReportGenerator()
        self.objadbCMD = adbcommands.adbcommands()
        self.exe_method = ""

    def setAndroidPrerequisite(self, adbServerPort):
        """
        Set Prerequsite to start Android device execution
        """
        try:
            deviceIdList = self.objAndroidconn.checkAndroidDeviceConnection(
                adbServerPort
            )
            if len(deviceIdList[0]) == 0:
                print(
                    """
                      -----------------------------------------------------------------
                      Device Not Connected, Please connect your device with test system
                      ------------------------------------------------------------------
                      """
                )
                return False
            else:
                for value in deviceIdList[0].values():
                    if value != "device":
                        print(
                            """"
                                   ---------------------------------------------
                                   Device Is In Offline Mode
                                   Please reconnect your device with test system
                                   ---------------------------------------------
                              """
                        )
                        return False
                return deviceIdList
        except Exception as err:
            print("ERROR: ", err)
            return False

    def getConfigData(self):
        """
        Parse config data from Config dict
        """
        try:
            os.environ["AppPackage"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Android"]["AppPackage"]
            os.environ["AppActivity"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Android"]["AppActivity"]
            os.environ["ApkPath"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Android"]["ApkPath"]
            os.environ["AppVersion"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Android"]["AppVersion"]
            os.environ["PlatformName"] = self.configDict["Configuration"]["SetupConfiguration"]["MoblieConfiguration"][
                "Platform"]
            os.environ["TestIteration"] = self.configDict["Configuration"]["SetupConfiguration"]["Common"]["TestIteration"]
        except Exception as err:
            print(
                "ERROR: Please Provide Correct AppConfiguration And AppCredential Data To config.xml File"
            )
            print("ERROR: ", err)
            sys.exit(1)

        self._configDataValidation()

    def xmlDatatoDict(self, fileName):
        Status = self.objCommon.fileExists(fileName)
        if Status:
            self.configDict = self.objCommon.xmlParser(fileName)
            self.getConfigData()

    def _configDataValidation(self):
        """
        Validate given configuration data
        """
        try:
            if os.environ["PlatformName"].lower() != "android":
                print("ERROR: Please Provide PlatformName As: android")
                sys.exit(1)
            if not self.objCommon.fileExists(os.environ["ApkPath"]):
                print(
                    "ERROR: .apk file Does Not Exists over "
                    + os.environ["ApkPath"]
                    + " Path !!"
                )
                sys.exit(1)
        except Exception as err:
            print("ERROR: ", err)
            return False

    def getAndroidVersion(self, deviceSerialId):
        """
        Get Android Device Version
        """
        try:
            androidVersion = subprocess.check_output(
                [
                    "adb",
                    "-s",
                    deviceSerialId,
                    "shell",
                    "getprop",
                    "ro.build.version.release",
                ]
            )
            return androidVersion.decode("UTF-8").split(".")[0]
        except Exception as err:
            print("ERROR: ", err)
            return False

    def triggerAndroidTestExecution(
            self, fileName, testSuiteToExec, testIncludeTag, testExcludeTag
    ):
        """
        Trigger test execution over android device
        """
        try:
            appiumPortNum = 4723
            adbServerPort = 5037
            systemPort = 8200

            # Get the XML config file into dict
            self.xmlDatatoDict(fileName)

            # Get the device connected UID
            DeviceID = self.setAndroidPrerequisite(adbServerPort)
            # Get the number of connected Android devices and list of test suites to execute
            totalDevices = len((list(DeviceID[0].keys())))
            allSuiteList = str(testSuiteToExec).split()

            for index, deviceId in enumerate(DeviceID[0].keys()):
                print("Connected Device ID is %s " % deviceId)

                appiumPortNum = int(appiumPortNum) + 5
                adbServerPort = int(adbServerPort) + 5
                systemPort = int(systemPort) + 5

                os.environ["deviceId"] = deviceId
                os.environ["appiumPortNum"] = str(appiumPortNum)
                os.environ["adbServerPort"] = str(adbServerPort)
                os.environ["systemPort"] = str(systemPort)

                # Get RemoteURL
                os.environ["remoteURL"] = self.objCommon.getAppiumRemoteUrl(
                    os.environ["appiumPortNum"]
                )

                # Get Mobile Model and OS details
                os.environ["androidDeviceVersion"] = androidDeviceVersion = self.objadbCMD.getMobileVersion(
                    os.environ["deviceId"]
                )
                os.environ["androidDeviceName"] = mobileModel = self.objadbCMD.getMobileModel(os.environ["deviceId"])
                mobileDevice = str(mobileModel) + " " + str(androidDeviceVersion)

                # Select locator file for Android App
                self.setAndroidLocatorPath(androidDeviceVersion)

                # Get the list of test suite(s) to execute
                currentSuiteList = allSuiteList[: int(len(allSuiteList) / totalDevices)]
                testSuiteToExec = " ".join([str(elem) for elem in currentSuiteList])

                # Reduce one Android device and test suite(s) being executed
                totalDevices = totalDevices - 1
                allSuiteList = [i for i in allSuiteList if i not in currentSuiteList]

                DeviceFW = ""
                globals()["process%s" % index] = Process(
                    target=self.scriptExecutor,
                    args=(
                        os.environ["deviceId"],
                        os.environ["remoteURL"],
                        os.environ["appiumPortNum"],
                        os.environ["adbServerPort"],
                        os.environ["systemPort"],
                        testSuiteToExec,
                        testIncludeTag,
                        testExcludeTag,
                        mobileDevice,
                    ),
                )
                globals()["process%s" % index].start()
                time.sleep(5)

            # Wait till forked process completion
            for index, deviceId in enumerate(DeviceID[0].keys()):
                globals()["process%s" % index].join()
            return True
        except Exception as err:
            print("ERROR: ", err)
            return False

    def setAndroidLocatorPath(self, androidDeviceVersion):
        """
        This Method will set the Android locator path into os environment
        :return: True if setting environment variable is success, else False if exception found.
        """
        try:
            print("The android device version is: %s" % androidDeviceVersion)

            Android11_locator = {
                # "locator": "${CURDIR}/../mobile/locators/android/android11locators.robot"  # Use the locator files like this while using the Robot framework
                "locator": f"mobile.locators.android.amazon11locators"   # Use the locator files like this while using the pytest framework
            }
            Android12_locator = {
                "locator": "${CURDIR}/../mobile/locators/android/android12locators.robot"
            }

            Android13_locator = {
                "locator": "${CURDIR}/../mobile/locators/android/android13locators.robot"
            }

            # Android OS Versions
            Android11OSList = ["11"]
            Android12OSList = ["12"]
            Android13OSList = ["13"]

            if androidDeviceVersion in Android11OSList:
                os.environ["AndroidLocatorFilePath"] = Android11_locator.get("locator")
                print(
                    "The selected locator path is: "
                    + os.environ["AndroidLocatorFilePath"]
                )
                return True
            elif androidDeviceVersion in Android12OSList:
                os.environ["AndroidLocatorFilePath"] = Android12_locator.get("locator")
                print(
                    "The selected locator path is: "
                    + os.environ["AndroidLocatorFilePath"]
                )
                return True
            elif androidDeviceVersion in Android13OSList:
                os.environ["AndroidLocatorFilePath"] = Android13_locator.get("locator")
                print(
                    "The selected locator path is: "
                    + os.environ["AndroidLocatorFilePath"]
                )
                return True
            else:
                print("Please connect supported Android version with the test system")

        except Exception as err:
            print(
                "ERROR: Failed to set Android device version environment variable ", err
            )
            return False

    def robotCommandCreator(self, execRunCmd, outputXml, logHtml, reportHtml, allIncludeTagList, allExcludeTagList,
                            deviceId, remoteUrl, appiumPortNum, adbServerPort, systemPort):
        """
        This method will create robot execution command.
        """
        robotExecCmd = "{0} -o {1} -l {2} -r {3} -v {4} -v {5} -v {6} -v {7} -v {8}".format(execRunCmd, outputXml,
                                                                                            logHtml, reportHtml,
                                                                                            deviceId, remoteUrl,
                                                                                            appiumPortNum, adbServerPort,
                                                                                            systemPort)

        # It will Include Tags if there are any
        for tag in allIncludeTagList:
            robotExecCmd = "{0} -i {1}".format(robotExecCmd, str(tag))
        # It will Exclude Tags if there are any
        for tag in allExcludeTagList:
            robotExecCmd = "{0} -e {1}".format(robotExecCmd, str(tag))
        return robotExecCmd

    def javaCommandCreator(self, logHtml, outputXml, outputJSON, testSuite):
        """
        This method will create Java execution command.
        """
        # Extract testsuite from current folder
        testSuiteToExec = "/".join((testSuite.split("/"))[1::])
        javaExecCmd = "mvn test" + " -Dcucumber.features=" + testSuiteToExec + \
                      " -Dcucumber.plugin=''pretty', 'html:../" + logHtml + "','junit:../" + \
                      outputXml + "','json:../" + outputJSON + "','"
        return javaExecCmd

    def pytestCommandCreator(self, execRunCmd, outputXml, logHtml):
        """
        This method will create Pytest execution command.
        """
        pytestExecCmd = execRunCmd + " --junit-xml=" + outputXml + " --html=" + logHtml
        return pytestExecCmd

    def scriptExecutor(self, deviceId, remoteUrl, appiumPortNum, adbServerPort, systemPort, testSuiteToExec,
                       testIncludeTag, testExcludeTag, mobileDevice):
        """
        This method will execute test suite on a specific android device.
        """
        try:
            global logReportDir
            detailTestReportDir = ""
            allSuiteList = str(testSuiteToExec).split()
            allIncludeTagList = str(testIncludeTag).split()
            allExcludeTagList = str(testExcludeTag).split()
            execStartTime = self.objCommon.getCurrentTime("%Y%m%d%H%M%S")
            os.environ["execStartTime"] = execStartTime
            if execStartTime:
                logReportDir = "logs/{0}/".format(str(execStartTime))
                detailTestReportDir = "reports/{0}/".format(str(execStartTime))
            os.environ["logsFolder"] = logReportDir
            os.mkdir(os.environ["logsFolder"])
            os.mkdir(detailTestReportDir)
            # Trigger to test suite execution
            for testSuite in allSuiteList:
                tSuiteName = os.path.basename(testSuite).split(".")[0]
                detailTestReportSuiteDir = detailTestReportDir + tSuiteName + "/"
                os.mkdir(detailTestReportSuiteDir)
                file_extension = pathlib.Path(testSuite).suffix
                exeMethod = file_extension
                if exeMethod[1:] == 'py':
                    os.environ["exeMethod"] = self.exe_method = 'pytest'
                elif exeMethod[1:] == 'feature':
                    os.environ["exeMethod"] = self.exe_method = 'java'
                elif exeMethod[1:] == 'robot':
                    os.environ["exeMethod"] = self.exe_method = 'robot'
                for i in range(int(os.environ["TestIteration"])):
                    os.environ["Iteration"] = str(i + 1)
                    logDir = (os.environ["logsFolder"] + tSuiteName + str("_A" + str(i + 1)) + "/")
                    os.mkdir(logDir)
                    os.environ["logDir"] = logDir
                    execRunCmd = self.exe_method
                    # Creating General Output Files Names
                    outputXml = "{0}output_{1}_{2}_{3}.xml".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                   str("A" + str(i + 1)))
                    logHtml = "{0}log_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                               str("A" + str(i + 1)))
                    reportHtml = "{0}report_{1}_{2}_{3}.html".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))
                    outputJSON = "{0}output_{1}_{2}_{3}.json".format(str(logDir), str(execStartTime), str(tSuiteName),
                                                                     str("A" + str(i + 1)))

                    # Create .reportdata.txt file
                    self.objTRG.create_report_file(
                        self.configDict, logDir, mobileAppVer=os.environ["AppVersion"]
                    )

                    # Creating execution commands according to the languages
                    if self.exe_method == "robot":
                        execRunCmd = self.robotCommandCreator(execRunCmd, outputXml, logHtml, reportHtml,
                                                              allIncludeTagList, allExcludeTagList, deviceId, remoteUrl,
                                                              appiumPortNum, adbServerPort, systemPort)
                    elif self.exe_method == "pytest":
                        execRunCmd = self.pytestCommandCreator(
                            self.exe_method, outputXml, logHtml
                        )
                    elif self.exe_method == "java":
                        os.chdir("test_cucumber")
                        execRunCmd = self.javaCommandCreator(logHtml, outputXml, outputJSON, str(testSuite))

                    # Add Testsuite to the execution command
                    if self.exe_method != "java":
                        execRunCmd = "{0} {1}".format(execRunCmd, str(testSuite))

                    # Start Execution
                    self.objCommon.startExec(execRunCmd)
                    if self.exe_method == "java":
                        os.chdir("..")
                    reportCSVFolder = detailTestReportSuiteDir + "/Vol_DetailTestReport"

                    if self.exe_method == "robot":
                        self.objTRG.generateCsvReport(outputXml, reportCSVFolder)
                    elif self.exe_method == "pytest":
                        self.objTRG.generatePyTestCsvReport(logHtml, reportCSVFolder)
                    elif self.exe_method == "python3":
                        pass
                    elif self.exe_method == "java":
                        self.objTRG.generateCucumberTestCsvReport(outputJSON, reportCSVFolder)

                    if self.exe_method != "java":
                        self.objCommon.xmlToJson(outputXml, outputJSON)
                        self.objCommon.updateJson(outputJSON, self.objCommon.getCurrentEpochTime(), 'android')
                    with open(".dynamoDBfilelist.txt", "a") as f:
                        f.write("%s\n" % (os.environ["CurrentPath"] + "/" + outputJSON))
                self.objTRG.getTestCategory(
                    tSuiteName, mobileDevice=mobileDevice, platform=os.environ["PlatformName"]
                )
        except Exception as err:
            print("ERROR : Execution ", err)
