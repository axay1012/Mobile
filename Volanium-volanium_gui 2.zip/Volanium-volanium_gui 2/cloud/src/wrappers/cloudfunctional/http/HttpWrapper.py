#!/usr/bin/env python

##############################################################################
#
# RequestWrapper is Cloud Application test library for Volanium it
# uses the Request library to perform cloud actions.
#
# This Library deliver keywords enhancement for robotframework requestLibrary.
#
##############################################################################

from requests import request


class HttpWrapper:
    def __init__(self):
        pass

    def httpWrapper(self):
        pass
