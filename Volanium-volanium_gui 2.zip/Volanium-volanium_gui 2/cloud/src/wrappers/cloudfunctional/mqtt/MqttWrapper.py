#!/usr/bin/env python

############################################################################
#
# This Library deliver keywords enhancement for robotframework MqttLibrary.
#
############################################################################


class MqttWrapper:
    def __init__(self):
        pass

    def mqttWrapper(self):
        pass
