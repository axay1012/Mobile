# -*- coding: utf-8 -*-
import sys
import csv
import matplotlib.pyplot as plt


class LocustWrapper:
    def generateCode(self, varName, varValue, fileObj):
        if varValue is not None:
            if isinstance(varValue, dict):
                fileObj.write("""            %s = { \n""" % varName)
                for key, value in varValue.items():
                    fileObj.write("""                "%s" : "%s", \n""" % (key, value))
                fileObj.write("""            }, \n""")
            if isinstance(varValue, tuple):
                fileObj.write("""            %s = ("%s"), \n""" % (varName, ', '.join(map(str, varValue))))
            if isinstance(varValue, bool) or isinstance(varValue, int) or isinstance(varValue, float):
                fileObj.write("""            %s = %s, \n""" % (varName, varValue))
            if isinstance(varValue, str):
                fileObj.write("""            %s = "%s", \n""" % (varName, varValue))

    def generateMqttCode(self, varName, varValue, varType, fileObj):
        if varValue is not None:
            if varType == dict:
                fileObj.write("""            %s = { \n""" % varName)
                for key, value in varValue.items():
                    fileObj.write("""                "%s" : "%s", \n""" % (key, value))
                fileObj.write("""            }, \n""")
            if varType == tuple:
                fileObj.write("""            %s = ("%s"), \n""" % (varName, ', '.join(map(str, varValue))))
            if varType in (bool, int, float):
                fileObj.write("""            %s = %s, \n""" % (varName, varValue))
            if varType == str:
                fileObj.write("""            %s = "%s", \n""" % (varName, varValue))

    def generateRequest(self, method, host, url, name=None, catch_response=None, params=None, data=None, headers=None,
                        cookies=None, files=None, auth=None, timeout=None, allow_redirects=None, proxies=None,
                        stream=None, verify=None, cert=None, max_wait=1000, min_wait=1000):
        """
        * method - method for the new Request object.
        * url - URL for the new Request object.
        * name - (optional) An argument that can be specified to use as label in Locust’s statistics instead of the URL path. This can be used to group different URL’s that are requested into a single entry in Locust’s statistics.
        * catch_response - (optional) Boolean argument that, if set, can be used to make a request return a context manager to work as argument to a with statement. This will allow the request to be marked as a fail based on the content of the response, even if the response code is ok (2xx). The opposite also works, one can use catch_response to catch a request and then mark it as successful even if the response code was not (i.e 500 or 404).
        * params - (optional) Dictionary or bytes to be sent in the query string for the Request.
        * data - (optional) Dictionary or bytes to send in the body of the Request.
        * headers - (optional) Dictionary of HTTP Headers to send with the Request.
        * cookies - (optional) Dict or CookieJar object to send with the Request.
        * files - (optional) Dictionary of 'filename': file-like-objects for multipart encoding upload.
        * auth - (optional) Auth tuple or callable to enable Basic/Digest/Custom HTTP Auth.
        * timeout (float) - (optional) How long to wait for the server to send data before giving up, as a float, or a (connect timeout, read timeout) tuple.
        * allow_redirects (bool) - (optional) Set to True by default.
        * proxies - (optional) Dictionary mapping protocol to the URL of the proxy.
        * stream - (optional) whether to immediately download the response content. Defaults to False.
        * verify - (optional) if True, the SSL cert will be verified. A CA_BUNDLE path can also be provided.
        * cert - (optional) If Tuple, (‘cert’, ‘key’) pair.
        * max_wait - (optional) Maximum waiting time for response, default 1000ms
        * min_wait - (optional) Minimum waiting time for response, default 1000ms
        """
        try:
            fileObj = open("locustfile.py", "w")
            fileObj.write("""from locust import HttpLocust, TaskSet, task \n""")
            fileObj.write("""import json \n """)
            fileObj.write("""\n""")
            fileObj.write("""class CloudTest(TaskSet): \n""")
            fileObj.write("""    @task \n""")
            fileObj.write("""    def request(self): \n""")
            fileObj.write("""        response = self.client.request(method="%s", \n""" % method.upper())
            fileObj.write("""            url = "%s", \n""" % url)
            varList = [('params', params), ('data', data), ('name', name), ('headers', headers),
                       ('cookies', cookies), ('files', files), ('auth', auth), ('timeout', timeout),
                       ('allow_redirects', allow_redirects), ('proxies', proxies), ('stream', stream),
                       ('verify', verify), ('cert', cert)]
            for varTup in varList:
                self.generateCode(varTup[0], varTup[1], fileObj)
            fileObj.write("""            )\n""")
            fileObj.write("""\n""")
            fileObj.write("""class Cloud(HttpLocust): \n""")
            fileObj.write("""     host = "%s" \n""" % host)
            fileObj.write("""     task_set = CloudTest \n""")
            fileObj.write("""     min_wait = %s \n""" % max_wait)
            fileObj.write("""     max_wait = %s \n""" % min_wait)
            fileObj.close()
            return True
        except:
            print("Not able to create locust.py")
            return False

    def generateMqttRequest(self, method, host, topic, qos, retry, timeout, payload=None, name='mqtt', max_wait=1000,
                            min_wait=1000):
        """
        * max_wait - (optional) Maximum waiting time for response, default 1000ms
        * min_wait - (optional) Minimum waiting time for response, default 1000ms
        """
        try:
            import os
            cwd = os.getcwd()
            path = os.path.join(cwd, 'cloud/src/wrappers/cloudload')
            fileObj = open("locustfile.py", "w")
            fileObj.write("""import sys \n""")
            fileObj.write("""sys.path.append('%s') \n""" % path)
            fileObj.write("""from locust import TaskSet, task \n""")
            fileObj.write("""from LocustMqttWrapper import MQTTLocust \n""")
            fileObj.write("""\n""")
            fileObj.write("""class CloudTest(TaskSet): \n""")
            fileObj.write("""    @task \n""")
            fileObj.write("""    def request(self): \n""")
            fileObj.write("""        response = self.client.%s(topic="%s", \n""" % (method, topic))
            varList = [('qos', qos, int), ('retry', retry, int), ('name', name, str), ('payload', payload, dict),
                       ('timeout', timeout, int)]
            for varTup in varList:
                self.generateMqttCode(varTup[0], varTup[1], varTup[2], fileObj)
            fileObj.write("""            )\n""")
            fileObj.write("""\n""")
            fileObj.write("""class Cloud(MQTTLocust): \n""")
            fileObj.write("""     host = "%s" \n""" % host)
            fileObj.write("""     task_set = CloudTest \n""")
            fileObj.write("""     min_wait = %s \n""" % max_wait)
            fileObj.write("""     max_wait = %s \n""" % min_wait)
            fileObj.close()
            return True
        except:
            print("Not able to create locust.py")
            return False

    def compareStatistics(self, responsePerSec, csvReportFile):
        """
        This function compares response/sec from locust csv report.
        """
        with open(csvReportFile + "_requests.csv", "r") as csvFile:
            reader = csv.reader(csvFile)
            for idx, line in enumerate(reader):
                if idx == 1:
                    rps = line[9]
        print(float(rps))
        if float(rps) >= float(responsePerSec):
            return True
        else:
            return False

    def plotGraph(self, plotFileName, csvReportFile):
        try:
            activities = ['Pass', 'Fail']
            colors = ['g', 'r']
            slices = []
            with open(csvReportFile + "_requests.csv", "r") as csvFile:
                reader = csv.reader(csvFile)
                for idx, line in enumerate(reader):
                    if idx == 2:
                        totalCount = int(line[2])
                        failCount = int(line[3])
                        passCount = totalCount - failCount
                        slices.append(passCount)
                        slices.append(failCount)
            patches, texts, _ = plt.pie(slices, labels=activities, colors=colors,
                                        startangle=90, shadow=True, explode=(0, 0.1),
                                        radius=1.2, autopct='%1.1f%%')
            plt.legend(patches, activities, loc="best")
            plt.savefig(plotFileName + '.png')
            return True
        except:
            print("Failed to genreate plot")
            return False
