import os
import sys


class sshresource:

    def __init__(self):
        pass

    def sshresource(self):
        pass
