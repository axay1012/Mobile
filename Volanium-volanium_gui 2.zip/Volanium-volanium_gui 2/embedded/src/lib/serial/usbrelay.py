import time
import serial


class usbrelay:

    def relayFn(self, usbRelayName, Cmd, relayNumber):
        """
        Open Serial Port, Perform Action, Close Serial Port.
        """
        try:
            # Open port for /dev/tty.usbmodem.....
            serPort = serial.Serial(usbRelayName, 19200, timeout=1)
            Cmd = str(Cmd)

            if int(relayNumber) < 10:
                relayIndex = str(relayNumber)
            else:
                relayIndex = chr(55 + int(relayNumber))

            print('Sending - relay ' + Cmd + " " + relayIndex)
            # Send the /dev/tty.usbmodem....
            serPort.write(str.encode("relay " + Cmd + " " + relayIndex + "\n\r"))
            # Close the port
            serPort.close()
            return True
        except Exception as err:
            print("Error: Relay Write Failed ", err)
            return False

    def factoryReset(self, usbRelayName, relayNumber, deviceName, numOfPressEvent):
        """
        Perform Factory Reset Action On Device.
        """
        try:
            if deviceName:
                print("Factory Reset the Device")
                push_number = int(numOfPressEvent)
                for i in range(push_number):
                    self.relayFn(usbRelayName, "on", relayNumber)
                    time.sleep(.5)
                    self.relayFn(usbRelayName, "off", relayNumber)
                    time.sleep(.5)
                return True
        except Exception as err:
            print("Error: Factory Reset Failed", err)
            return False

    def longPressRelayOn(self, usbRelayName, relayNumber):
        """
        Perform a continuous Relay Override for specified relay.
        Most likely useful for In-App push notification tests, where you need to control the time duration
        """
        try:
            self.relayFn(usbRelayName, "on", relayNumber)
            return True
        except Exception as err:
            print("Error: Long Press Relay ON Event Failed", err)
            return False

    def longPressRelayOff(self, usbRelayName, relayNumber):
        """
        Disable the continuous Relay Override for specified relay.
        """
        try:
            self.relayFn(usbRelayName, "off", relayNumber)
            return True
        except Exception as err:
            print("Error: Long Press Relay OFF Event Failed", err)
            return False


if __name__ == "__main__":
    objRelay = usbrelay()
