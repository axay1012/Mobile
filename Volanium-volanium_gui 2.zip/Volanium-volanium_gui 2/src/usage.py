#!/usr/bin/env python

import sys


class usage:

    def __init__(self):
        self.USAGE = '''
                Usage:
                ----------------------------------------------------------------------
                Below is the CLI options to run:
                -c/--component     - Execute specific Components(e.g. Android, iOS, Web, Cloud, Embedded)                       
                                   - Framework Supports below mentioned test component:
                                     (a) Android/android/ANDROID
                                     (b) iOS/ios/IOS
                                     (c) Cloud
                                     (d) Web
                                     (f) Embedded
                                   - This is mandatory parameter
                -s/--suite         - Absolute path of the robot test suite.
                                   - This flag can take one or more test suites as an input argument.                                      
                                   - This is mandatory parameter
                -i/--includetag    - This flag allow to execute selected test categories from the test suites.
                                   - This is an optional parameter
                -e/--excludetag    - This flag allow to not execute selected test categories from the test suites.
                                   - This is an optional parameter
                -r/--testrail      - This Flag allow you to update test result in testrail
                                   - Flag Value must be "yes" if user want to update result
                                   - This is an optional parameter
                -n/--confluence    - This Flag allow you to update test result in Confluence
                                   - Flag Value must be "yes" if user want to update result
                                   - This is an optional parameter

                ++++++++++++
                Run Command:
                ++++++++++++
                python3 TestDriver.py -c <TEST COMPONENT> -i <TEST TAG NAME> -s <TEST SUITE NAME>
                python3 TestDriver.py -c <TEST COMPONENT> -e <TEST TAG NAME> -s <TEST SUITE NAME>
                ---------
                Examples:
                ---------
                       1. Run single test suite from TestDriver.py
                          a) Android : Run single test suite with all test cases:                     
                             Example : python TestDriver.py -c Android -s 'demoSuite.robot'
                          b) iOS     : Run single test suite with all test cases:                     
                             Example : python TestDriver.py -c ios -s 'demoSuite.robot'
                       2. Run multiple test suite with all test cases:         
                          Example : python TestDriver.py -c Android -s 'demoSuite1.robot demoSuite2.robot demoSuite3.robot'
                          [Note]: there must be a single space between two suite name
                       3. Run single test suite with selective/include tag test cases:                  
                          Example : python TestDriver.py -c ios -s 'demoSuite.robot' -i 'smoke_test'
                       4. Run multiple test suite with selective/include tag test cases:
                          Example : python TestDriver.py -c Android -s 'demoSuite1.robot demoSuite2.robot' -i 'smoke_test'
                          [Note]: there must be a single space between two suite name
                       5. Execute only sanity and smoke include tag from test suite                 
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' -i 'sanity_test smoke_test'
                          [Note]: There must be a single space between two tag name
                       6. Exclude single test case from test suite
                          Example : python TestDriver.py -c ios -s 'demoSuite.robot' -e 'smoke_test'
                       7. Exclude multiple test case from test suite
                          Example : python TestDriver.py -c ios -s 'demoSuite.robot' -e "smoke_test sanity"
                       8. To update result in TestRail(only for sanity suite)
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' --testrail=yes
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' -r yes
                       8. To update result in Confluence
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' -n yes
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' --confluence yes
                       9. To update result in Grafana
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' -g yes
                          Example : python TestDriver.py -c Android -s 'demoSuite.robot' --grafana yes
                       [Note]: Before start execution of selected test cases from suite,
                               Make sure that test script consist Tags Names.
                ----------------------------------------------------------------------
                '''

    def displayUsage(self):
        """
        Display The Framework usage
        """
        print(self.USAGE)
        sys.exit(0)


if __name__ == "__main__":
    obj_usage = usage()
    obj_usage.displayUsage()
