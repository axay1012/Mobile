#!/usr/bin/env python

########################################################################
# This Library used to generate Master Summary report from csv file.
# This library takes csv file as an input and generate MasterSummaryReport.xls test report according to csv file data.
########################################################################

import os
import csv
import xlwt
import re
import xlrd
from collections import OrderedDict
from common import common

# Macros
MASTER_SUMMARY_REPORT_FILE_NAME = "/finalresults/Vol_MasterSummaryReport_"


class finalsummaryreport:

    def __init__(self):
        self.objCommon = common()
        self.TestCategoryDict = {}
        self.commonSectionDict = OrderedDict()
        self.tempDict = {}
        self.attempts = []
        self.attDict = {}
        self.onboardingResult = {}
        self.nonOnboardingResult = {}
        self.devCatList = []
        self.catList = []
        self.col = self.row = 1

    def _readCsvFile(self, listOfFile):
        """
        Read Test Category and Create common section Dict
        :return: commonSectionDict
        """
        try:
            for file in listOfFile:
                with open(file, 'r') as csvfile:
                    csvreader = csv.reader(csvfile)
                    for row in csvreader:
                        if len(row) == 0:
                            continue
                        if row[0] == "Test Category":
                            if row[1].strip().lower() == 'onboarding':
                                os.environ["suiteType"] = row[1]
                            self.TestCategoryDict[file] = row[1]
                            break
                        else:
                            if row[0] not in self.commonSectionDict:
                                self.commonSectionDict[row[0]] = [row[1]]
                            else:
                                self.commonSectionDict[row[0]].append(row[1])
            return self.commonSectionDict
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _generateXlsFile(self):
        """
        Create Xls file
        :return:
        """
        try:
            self.book = xlwt.Workbook(encoding="utf-8")

            self.sheet1 = self.book.add_sheet("MasterSummary")
            self.bordersFormate = xlwt.easyxf('font: bold off, color black;\
                                 borders: top_color black, bottom_color black, right_color black, left_color black,\
                                          left thin, right thin, top thin, bottom thin;')
            self.boldFormate = xlwt.easyxf('font: bold on, color black;\
                                 borders: top_color black, bottom_color black, right_color black, left_color black,\
                                          left thin, right thin, top thin, bottom thin;')

            self.firstCol = self.sheet1.col(0)
            self.firstCol.width = 60 * 20
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _writeCommonSection(self):
        """
        Write Release Branch, Environment,  Mobile Device/Browser, Mobile/Web App Version
        :return:
        """
        try:
            # Write Release Branch, Environment,  Mobile Device/Browser, Mobile/Web App Version
            for key, value in self.commonSectionDict.items():
                if key == "Release Branch":
                    self.sheet1.write(self.row, self.col, "Release Branch", self.bordersFormate)
                    self.col = self.col + 1
                    self.sheet1.write(self.row, self.col, value[0].strip(), self.bordersFormate)
                    self.col = self.col - 1
                    self.row = self.row + 1

            for key, value in self.commonSectionDict.items():
                if key == "Environment":
                    temp = list(set(value))
                    self.sheet1.write(self.row, self.col, key, self.bordersFormate)
                    self.col = self.col + 1
                    self.sheet1.write(self.row, self.col, temp[0], self.bordersFormate)
                    self.row = self.row + 1
                    self.col = self.col - 1
                if key == "Browser":
                    temp = list(set(value))
                    self.sheet1.write(self.row, self.col, key, self.bordersFormate)
                    self.col = self.col + 1
                    self.sheet1.write(self.row, self.col, temp[0].title(), self.bordersFormate)
                    self.row = self.row + 1
                    self.col = self.col - 1
                if key == "Web App Version":
                    temp = list(set(value))
                    self.sheet1.write(self.row, self.col, key, self.bordersFormate)
                    self.col = self.col + 1
                    self.sheet1.write(self.row, self.col, temp[0], self.bordersFormate)
                    self.row = self.row + 1
                    self.col = self.col - 1

                if key == "Platform":
                    upValue = []
                    for val in value:
                        if val not in upValue:
                            upValue.append(val)

                    if len(upValue) < 2:
                        upValue.append("None")

                    deviceList = []
                    for val in self.commonSectionDict["Mobile Device"]:
                        if val not in deviceList:
                            deviceList.append(val)

                    deviceVersionList = []
                    for val in self.commonSectionDict["Mobile App Version"]:
                        if val not in deviceVersionList:
                            deviceVersionList.append(val)

                    if upValue[0].lower().strip() == "android":
                        self.sheet1.write(self.row, self.col, "Android Device", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceList[0].strip(), self.bordersFormate)
                        self.col = self.col - 1
                    elif upValue[1].lower().strip() == "android":
                        self.sheet1.write(self.row, self.col, "Android Device", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceList[1].strip(), self.bordersFormate)
                        self.col = self.col - 1

                    if upValue[0].lower().strip() == "ios":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "iOS Device", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceList[0].strip(), self.bordersFormate)
                        self.col = self.col - 1
                    elif upValue[1].lower().strip() == "ios":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "iOS Device", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceList[1].strip(), self.bordersFormate)
                        self.col = self.col - 1

                    if upValue[0].lower().strip() == "android":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "Android App Version", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceVersionList[0].strip(), self.bordersFormate)
                        self.col = self.col - 1
                    elif upValue[1].lower().strip() == "android":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "Android App Version", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceVersionList[1].strip(), self.bordersFormate)
                        self.col = self.col - 1

                    if upValue[0].lower().strip() == "ios":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "iOS App Version", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceVersionList[0].strip(), self.bordersFormate)
                        self.col = self.col - 1
                    elif upValue[1].lower().strip() == "ios":
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, "iOS App Version", self.bordersFormate)
                        self.col = self.col + 1
                        self.sheet1.write(self.row, self.col, deviceVersionList[1].strip(), self.bordersFormate)
                        self.col = self.col - 1

        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _writeAttemptsSection(self):
        """
        Write Number of Attempts
        :return:
        """
        try:
            # Collect Number of attempts
            for key, value in self.TestCategoryDict.items():
                with open(key, 'r') as csvfile:
                    csvreader = csv.reader(csvfile)
                    self.datalist = []
                    for rows in csvreader:
                        self.datalist.append(rows)
                    TotalLen = len(self.datalist)
                    if value == "onboarding":
                        for iter in range(TotalLen):
                            if "Devices" in self.datalist[iter]:
                                i = iter + 1
                                self.attempts.append(self.datalist[i][1])
                                break
                    elif value != "onboarding":
                        for iter in range(TotalLen):
                            if "TestCase_ID" in self.datalist[iter]:
                                x = 0
                                for i in self.datalist[iter]:
                                    attList = re.findall("Iteration_*", i)
                                    if attList:
                                        x = x + 1
                                self.attDict[value] = x
                                break
                    self.datalist = []

            # Write OnBoarding Attempts Heading and Value
            self.col = self.col
            onboard_status = finalsummaryreport
            if os.environ.get("suiteType"):
                self.sheet1.write(self.row, self.col, "# of OnBoarding Attempts", self.bordersFormate)
                self.col = self.col + 1
                if self.attempts:
                    self.sheet1.write(self.row, self.col, self.attempts[-1], self.bordersFormate)
                else:
                    self.sheet1.write(self.row, self.col, " ", self.bordersFormate)
                onboard_status = True

            # Write Non OnBoarding Attempts Heading and Value
            for key, value in self.attDict.items():
                if not onboard_status:
                    self.col = self.col + 1
                if self.col == 2:
                    self.col = self.col - 1
                self.row = self.row + 1
                self.sheet1.write(self.row, self.col, "# of " + key + " Attempts", self.bordersFormate)
                self.col = self.col + 1
                self.sheet1.write(self.row, self.col, str(value), self.bordersFormate)
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _writeResultsSection(self):
        """
        Write Result of Onboarding and Non Onboarding
        :return:
        """
        try:
            # Collect Onboarding and Non Onboarding Results
            self.col = self.col - 1
            self.row = self.row + 2
            for key, value in self.TestCategoryDict.items():
                with open(key, 'r') as csvfile:
                    csvreader = csv.reader(csvfile)
                    self.datalist = []
                    for rows in csvreader:
                        self.datalist.append(rows)
                    TotalLen = len(self.datalist)
                    if value == "onboarding":
                        for iter in range(TotalLen):
                            if "Platform" in self.datalist[iter]:
                                i = iter + 1
                                t2 = []
                                t2.append(self.datalist[i - 1][1].strip())
                            if "Devices" in self.datalist[iter]:
                                i = iter + 1
                                t1 = []
                                t1.extend(self.datalist[i])
                                t1.append(value)
                                t1.extend(t2)
                                self.onboardingResult[key] = t1
                                break
                    elif value != "onboarding":
                        tempList = []
                        for iter in range(TotalLen):
                            if "DUT Device Name" in self.datalist[iter]:
                                self.catList.append(value)
                                tempList.append(self.datalist[iter][1])
                                tempList.append(value)
                                self.catList = list(set(self.catList))
                            if "Browser" in self.datalist[iter]:
                                self.browser = []
                                i = iter + 1
                                self.browser.append(self.datalist[i - 1][1].strip().title())
                                tempList.extend(self.browser)
                                self.devCatList.append(tuple(tempList))
                            if "Platform" in self.datalist[iter]:
                                self.platform = []
                                i = iter + 1
                                self.platform.append(self.datalist[i - 1][1].strip())
                                tempList.extend(self.platform)
                                self.devCatList.append(tuple(tempList))
                            if "Test ID" in self.datalist[iter]:
                                i = iter + 1
                                t2 = []
                                for a in range(i, len(self.datalist)):
                                    t2.append(self.datalist[a][1])
                                passCount = t2.count("PASS")
                                failCount = t2.count("FAIL")
                                total = passCount + failCount
                                self.nonOnboardingResult[key] = value, total, passCount, failCount
                                break

                    self.datalist = []

            # Write OnBoarding Results
            if self.onboardingResult:
                self.sheet1.write(self.row, self.col, "Onboarding", self.boldFormate)
                self.row = self.row + 2
                andOnboarding = {}
                iOSOnboarding = {}

                for k, v in self.onboardingResult.items():
                    if v[-1] == "android":
                        andOnboarding[k] = v
                    else:
                        iOSOnboarding[k] = v
                if andOnboarding:
                    self.sheet1.write_merge(self.row, self.row, self.col, self.col + len(andOnboarding) - 1, "Android",
                                            self.bordersFormate)

                    self.row = self.row + 1
                    for k, v in andOnboarding.items():
                        self.sheet1.write(self.row, self.col, v[0], self.bordersFormate)
                        self.col = self.col + 1
                    self.row = self.row + 1
                    self.col = self.col - len(andOnboarding)

                    for k, v in andOnboarding.items():
                        self.sheet1.write(self.row, self.col, v[-3] + "%", self.bordersFormate)
                        self.col = self.col + 1
                    self.row = self.row + 2
                    self.col = self.col - len(andOnboarding)

                if iOSOnboarding:
                    self.sheet1.write_merge(self.row, self.row, self.col, self.col + len(iOSOnboarding) - 1, "iOS",
                                            self.bordersFormate)

                    self.row = self.row + 1
                    for k, v in iOSOnboarding.items():
                        self.sheet1.write(self.row, self.col, v[0], self.bordersFormate)
                        self.col = self.col + 1
                    self.row = self.row + 1
                    self.col = self.col - len(iOSOnboarding)

                    for k, v in iOSOnboarding.items():
                        self.sheet1.write(self.row, self.col, v[-3] + "%", self.bordersFormate)
                        self.col = self.col + 1
                    self.row = self.row + 2
                    self.col = self.col - len(iOSOnboarding)

            # Write Non OnBoarding Results
            for data in self.catList:
                self.sheet1.write(self.row, self.col, data, self.boldFormate)
                self.row = self.row + 1
                for tup in self.devCatList:
                    if tup[1] == data:
                        self.row = self.row + 1
                        if tup[-1] == "android":
                            self.sheet1.write(self.row, self.col, "Android", self.bordersFormate)
                        elif tup[-1] == "ios":
                            self.sheet1.write(self.row, self.col, "iOS", self.bordersFormate)
                        else:
                            self.sheet1.write(self.row, self.col, tup[-1], self.bordersFormate)
                        self.row = self.row + 1
                        self.sheet1.write(self.row, self.col, tup[0], self.bordersFormate)
                        self.row = self.row + 1
                        for k, v in self.nonOnboardingResult.items():
                            if v[0] == data:
                                self.sheet1.write(self.row, self.col, "Total", self.bordersFormate)
                                self.row = self.row + 1
                                self.sheet1.write(self.row, self.col, str(v[1]), self.bordersFormate)
                                self.col = self.col + 1
                                self.row = self.row - 1
                                self.sheet1.write(self.row, self.col, "PASS", self.bordersFormate)
                                self.row = self.row + 1
                                self.sheet1.write(self.row, self.col, str(v[2]), self.bordersFormate)
                                self.col = self.col + 1
                                self.row = self.row - 1
                                self.sheet1.write(self.row, self.col, "FAIL", self.bordersFormate)
                                self.row = self.row + 1
                                self.sheet1.write(self.row, self.col, str(v[3]), self.bordersFormate)
                                self.col = 1
                                self.row = self.row + 1
                                self.nonOnboardingResult.pop(k, None)
                                break
                self.row = self.row + 1
                self.col = 1
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _saveXlsFile(self):
        """
        Save Xls File
        :return:
        """
        try:
            currentDir = os.getcwd()
            epochTime = self.objCommon.getCurrentEpochTime()
            self.fileName = currentDir + MASTER_SUMMARY_REPORT_FILE_NAME + str(epochTime) + ".xls"
            os.environ["MasterSummaryReport"] = self.fileName
            # Save File
            self.book.save(self.fileName)
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def _readXlsFileAndPerformFormating(self):
        """
        Open created file for formatting and re-save it
        :return:
        """
        try:
            # Open created file for formatting
            self.book1 = xlrd.open_workbook(self.fileName, formatting_info=True)
            self.firstSheet = self.book1.sheet_by_index(0)

            for r in range(2, 11):
                self.cell = self.firstSheet.cell(r, 2)
                if self.cell.value == '':
                    self.sheet1.write(r, 2, "", self.bordersFormate)

            for i in range(1, 4):
                col = self.sheet1.col(i)
                col.width = 100 * 65

            for i in range(3, self.firstSheet.ncols):
                col = self.sheet1.col(i)
                col.width = 100 * 50

            # Save File after formatting
            self._saveXlsFile()
        except Exception as err:
            print("Exception: " + str(err))
            return False

    def createMasterSummaryReport(self, listOfFileName):
        try:
            self._readCsvFile(listOfFileName)
            self._generateXlsFile()
            self._writeCommonSection()
            self._writeAttemptsSection()
            self._writeResultsSection()
            self._saveXlsFile()
            self._readXlsFileAndPerformFormating()
        except Exception as err:
            print("Exception: " + str(err))
            return False


if __name__ == "__main__":
    objReport = finalsummaryreport()
