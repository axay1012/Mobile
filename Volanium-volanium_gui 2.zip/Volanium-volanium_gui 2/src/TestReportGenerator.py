#!/usr/bin/env python

#####################################################################
# This library is used to generate Test report from Robot XML file.
# This library takes XML formatted file (output.xml) of robotframework as an input and generate CSV test report
#####################################################################

from common import common
from collections import OrderedDict
import csv
import re
import os
import json
import pandas as pd
from bs4 import BeautifulSoup

# Macros
REPORT_FILE_NAME = "../results/TestReport"
REPORT_COLUMN_0 = "TEST_SUITE"
REPORT_COLUMN_1 = "TEST_CASE"
REPORT_COLUMN_2 = "TEST_ID"
REPORT_COLUMN_3 = "TEST_CATEGORY"
REPORT_COLUMN_4 = "TEST_STATUS"
REPORT_COLUMN_5 = "FAILURE MSG"
REPORT_COLUMN_6 = "JIRA ID"
REPORT_COLUMN_7 = "COMMENTS"
CSV_FILE_EXT = "csv"
TOTAL_TEST_CASE = "TOTAL"
TOTAL_PASS_TEST = "PASS"
TOTAL_FAIL_TEST = "FAIL"
SUMMARY_REPORT_FILE_NAME = "/results/Vol_TestSummaryReport_"


class TestReportGenerator:
    def __init__(self):
        self.fileptr = None
        self.objCommon = common()
        self.objFilePtr = None
        self.objCsvWriter = None
        self.allReportList = []
        self.dict_TestSummary = {}
        self.dictAttempt = {}

    def _getTestSuiteName(self, suiteInfo):
        """
        Parse Test suite name from XML data
        """
        try:
            return suiteInfo.get("@name")
        except Exception as err:
            print("ERROR: Failed to Get Test Suite Name", err)
            return None

    def _getTestCaseName(self, testInfo):
        """
        Parse Test case name from XML data
        """
        try:
            return testInfo.get("@name")
        except Exception as err:
            print("ERROR: Failed to Get Test Case Name", err)
            return None

    def _getTestCaseId(self, testInfo):
        """
        Parse Test case ID from XML data
        """
        try:
            if isinstance(testInfo.get("tags").get("tag"), list):
                for tag in testInfo.get("tags").get("tag"):
                    if re.findall(r"\d", str(tag)):
                        return tag
            elif isinstance(testInfo.get("tags").get("tag"), str):
                if re.findall(r"\d", str(testInfo.get("tags").get("tag"))):
                    return str(testInfo.get("tags").get("tag"))
                else:
                    return False
        except Exception as err:
            print("Error: ", err)
            return None

    def _getTestCaseCategory(self, testInfo):
        """
        Parse test case category from XML data
        """
        try:
            if isinstance(testInfo.get("tags").get("tag"), list):
                for tag in testInfo.get("tags").get("tag"):
                    if not re.findall(r"[\d]", str(tag)):
                        return tag
            elif isinstance(testInfo.get("tags").get("tag"), str):
                if not re.findall(r"[\d]", str(testInfo.get("tags").get("tag"))):
                    return str(testInfo.get("tags").get("tag"))
                else:
                    return None
        except Exception as err:
            print("Error: ", err)
            return None

    def _getTestCaseStartTime(self, testInfo):
        """
        Parse test case start time from XML data
        """
        try:
            return testInfo.get("status").get("@starttime")
        except Exception as err:
            print("ERROR: Failed to Get Test Case Start Time", err)
            return None

    def _getTestCaseEndTime(self, testInfo):
        """
        Parse test case end time from XML data
        """
        try:
            return testInfo.get("status").get("@endtime")
        except Exception as err:
            print("ERROR: Failed to Get Test Case End Time", err)
            return None

    def _getTestCaseStatus(self, testInfo):
        """
        Parse test case status from XML data
        """
        try:
            return testInfo.get("status").get("@status")
        except Exception as err:
            print("ERROR: Failed to Get Test Case Status", err)
            return None

    def _getTestCaseDescription(self, testInfo):
        """
        Parse Test Case Description from XML data
        """
        try:
            return testInfo.get("doc")
        except Exception as err:
            print("ERROR: Failed to Get Test Case Description", err)
            return None

    def _writeRawDataInCsv(self, rawDataDict):
        """
        Write raw data into csv report
        """
        if rawDataDict:
            try:
                self.objCsvWriter.writerow(dict(rawDataDict))
                return True
            except Exception as err:
                print("ERROR: Failed to Write Raw Data into CSV File ", err)
                return False

    def _getTestCaseFailMsg(self, tcInfo):
        """
        Parse test case Failure string from XML data
        """
        try:
            tcStatus = self._getTestCaseStatus(tcInfo)
            if tcStatus == "FAIL":
                return tcInfo.get("status").get("#text")
        except Exception as err:
            print("ERROR: Failed to Get Test Case Failure Message ", err)
            return None

    def _getTestDataBuffer(self, tcInfo, tsName):
        """
        Prepare test data buffer to dump into CSV report
        """
        csvDataDict = {}
        try:
            csvDataDict[REPORT_COLUMN_0] = str(tsName)
            csvDataDict[REPORT_COLUMN_1] = self._getTestCaseName(tcInfo)
            csvDataDict[REPORT_COLUMN_2] = self._getTestCaseId(tcInfo)
            csvDataDict[REPORT_COLUMN_3] = self._getTestCaseCategory(tcInfo)
            csvDataDict[REPORT_COLUMN_4] = self._getTestCaseStatus(tcInfo)
            csvDataDict[REPORT_COLUMN_5] = self._getTestCaseFailMsg(tcInfo)
            return csvDataDict
        except Exception as err:
            print(
                "ERROR: Failed to Get Test Data Buffer and Creation of CSV Data Dict",
                err,
            )
            return csvDataDict

    def _writeTestStatistics(self, writeTag, writeVal):
        """
        Write test statistics in CSV report
        Total PASS, FAIL and Test Case Count
        """
        csvDataDict = {}
        try:
            csvDataDict[REPORT_COLUMN_0] = str(writeTag)
            csvDataDict[REPORT_COLUMN_1] = str(writeVal)
            return csvDataDict
        except Exception as err:
            print("ERROR: Failed to Write Test Statistics", err)
            return csvDataDict

    def _prepareCsvReportHeader(self):
        """
        Prepare CSV report Header data
        """
        headerList = []
        try:
            headerList = []
            for numCnt in range(7):
                headerList.append(eval("REPORT_COLUMN_{0}".format(numCnt)))
            return headerList
        except Exception as err:
            print("ERROR: Failed to Prepare CSV Report Header", err)
            return headerList

    def _getTestStatisticsData(self, tsInfo):
        """
        Get Test statistics data from XML report
        """
        try:
            passTestCnt = eval(tsInfo["statistics"]["total"]["stat"][1]["@pass"])
            failTestCnt = eval(tsInfo["statistics"]["total"]["stat"][1]["@fail"])
            totalTestCnt = int(passTestCnt) + int(failTestCnt)
        except Exception as err:
            print("ERROR: Failed to Get Test Statistics Data", err)
            passTestCnt = failTestCnt = totalTestCnt = 1

        return passTestCnt, failTestCnt, totalTestCnt

    def _getExecTestInfo(self, testData):
        """
        Dump test cases data into CSV report
        """
        try:
            testSuiteInfo = testData.get("robot")
            (passTc, failTc, totalTc) = self._getTestStatisticsData(testSuiteInfo)
            suiteInfo = testData.get("robot").get("suite")
            suiteName = suiteInfo.get("@name")
        except Exception as err:
            print("ERROR: Failed to Get the Test Execution Information", err)
            suiteInfo = totalTc = suiteName = 1

        return totalTc, suiteInfo, suiteName

    def _dumpTestStatisticsInCsv(self, tsData):
        """
        Dump statistics report into CSV file
        """
        try:
            testSuiteInfo = tsData.get("robot")
            (passTc, failTc, totalTc) = self._getTestStatisticsData(testSuiteInfo)
            self._writeRawDataInCsv(self._writeTestStatistics(TOTAL_TEST_CASE, totalTc))
            self._writeRawDataInCsv(self._writeTestStatistics(TOTAL_PASS_TEST, passTc))
            self._writeRawDataInCsv(self._writeTestStatistics(TOTAL_FAIL_TEST, failTc))
        except Exception as err:
            print("ERROR: Failed to Dump Test Statistics in CSV", err)
            return False

    def _dumpTestDataInCsv(self, totalTcCnt, suiteData, suiteName):
        """
        Parse and Dump test case data in CSV report
        """
        try:
            if int(totalTcCnt) == 1:
                tcInfo = suiteData.get("test")
                rawDataBuffer = self._getTestDataBuffer(tcInfo, suiteName)
                self._writeRawDataInCsv(rawDataBuffer)
            else:
                for tcInfo in list(suiteData.get("test")):
                    rawDataBuffer = self._getTestDataBuffer(tcInfo, suiteName)
                    self._writeRawDataInCsv(rawDataBuffer)
            return True
        except Exception as err:
            print("ERROR: Failed to dump Test Data In CSV", err)
            return False

    def _dumpHeaderDataInCsv(self):
        """
        Dump Header data into CSV report
        """
        try:
            headerFields = self._prepareCsvReportHeader()
            self.objCsvWriter = csv.DictWriter(self.objFilePtr, fieldnames=headerFields)
            self.objCsvWriter.writeheader()
            self.csvHeaderFlag = 1
            return True
        except Exception as err:
            print("ERROR: Failed to dump Header Data in CSV", err)
            return False

    def _openCsvReportFile(self, reportFile, tsName):
        """
        Create CSV file to prepare test report
        """
        try:
            epochTime = self.objCommon.getCurrentEpochTime()
            reportFileName = "{0}_{1}_{2}.{3}".format(
                reportFile, tsName, epochTime, CSV_FILE_EXT
            )
            if os.path.isfile(reportFileName):
                print("INFO: File {0} is already created".format(reportFileName))
            else:
                self.objFilePtr = self.objCommon.openFile(reportFileName)
                self.allReportList.append(reportFileName)
            return True
        except Exception as err:
            print("ERROR: Failed to Open CSV Report File", err)
            return False

    def _xmlToDictConverter(self, xmlFilePath):
        """
        Convert XML data into dictionary format
        """
        try:
            return self.objCommon.xmlParser(xmlFilePath)
        except Exception as err:
            print("ERROR : Failed to Convert XML to Dict", err)
            return False

    def generateCsvReport(self, robotXmlFile, csvReportName=REPORT_FILE_NAME):
        """
        Prepare CSV report file from robot XMl report File
        """
        if not self.objCommon.fileExists(robotXmlFile):
            print("ERROR: OUTPUT XML FILE {0} NOT FOUND".format(robotXmlFile))
            return False

        testDataDict = self._xmlToDictConverter(robotXmlFile)
        if not testDataDict:
            return False
        else:
            try:
                (totalCnt, tsData, tsName) = self._getExecTestInfo(testDataDict)
                self._openCsvReportFile(csvReportName, tsName)
                self._dumpHeaderDataInCsv()
                self._dumpTestDataInCsv(totalCnt, tsData, tsName)
                self._dumpTestStatisticsInCsv(testDataDict)
                self.objCommon.closeFile(self.objFilePtr)
                return True
            except Exception as err:
                print("ERROR : Failed to Generate CSV Report ", err)
                return False

    def generatePyTestCsvReport(self, htmlFile, csvReportName=REPORT_FILE_NAME):
        """
        Prepare CSV report file from HTML report File
        """
        if not self.objCommon.fileExists(htmlFile):
            print("ERROR: OUTPUT XML FILE {0} NOT FOUND".format(htmlFile))
            return False
        try:
            with open(htmlFile, 'r') as f:
                soup = BeautifulSoup(f.read(), 'html.parser')
                header_list = ['TEST_SUITE', 'TEST_CASE', 'TEST_ID', 'TEST_CATEGORY', 'TEST_STATUS', 'FAILURE MSG',
                               'JIRA ID', 'COMMENTS']

                info = soup.find_all('tbody', class_='results-table-row')
                dataframe_list = []
                sorted_data_list = []
                passed_tc = 0
                failed_tc = 0
                for i in info:
                    temp_data = [link.string if link.string else link.text for link in i.find_all('td')]
                    tsName = temp_data[1].split('::')[0]
                    testSuiteName = os.path.basename(tsName).split(".")[0]
                    sorted_data_list.append(testSuiteName)
                    for i in temp_data[2:5]:
                        sorted_data_list.append(i)
                    sorted_data_list[3] = sorted_data_list[3].replace(".py", "")
                    sorted_data_list.append(temp_data[0])
                    if sorted_data_list[4] == "Failed":
                        sorted_data_list[4] = "FAIL"
                        failed_tc = failed_tc + 1
                        sorted_data_list.append(temp_data[-1])
                    else:
                        sorted_data_list[4] = "PASS"
                        passed_tc = passed_tc + 1
                        sorted_data_list.append('')

                    sorted_data_list.extend(['', ''])
                    sorted_data_list[1] = sorted_data_list[1].split("::")[-1]
                    dataframe_list.append(sorted_data_list)

                self._openCsvReportFile(csvReportName, sorted_data_list[3])
                df = pd.DataFrame(dataframe_list, columns=header_list)
                df.to_csv(self.allReportList[0], index=False)
                df = pd.DataFrame([len(dataframe_list), passed_tc, failed_tc], ['TOTAL', 'PASS', "FAIL"])
                df.to_csv(self.allReportList[0], mode='a', header=False)
                return True
        except Exception as err:
            print("ERROR : Failed to Generate CSV Report ", err)
            return False

    def generateCucumberTestCsvReport(self, jsonFile, csvReportName=REPORT_FILE_NAME):
        """
        Prepare CSV report file from JSON report File
        """
        if not self.objCommon.fileExists(jsonFile):
            print("ERROR: OUTPUT XML FILE {0} NOT FOUND".format(jsonFile))
            return False
        try:
            with open(jsonFile, 'r') as f:
                header_list = ['TEST_SUITE', 'TEST_CASE', 'TEST_ID', 'TEST_CATEGORY', 'TEST_STATUS', 'FAILURE MSG',
                               'JIRA ID', 'COMMENTS']

                global_data_list = []
                with open(jsonFile) as json_file:
                    data = json.load(json_file)

                    passed_tc = failed_tc = 0
                    for i in range(len(data[0]['elements'])):
                        final_data_list = []
                        tc_name = data[0]['elements'][i]['name']
                        tc_type = data[0]['uri'].split("/")[-1]
                        final_data_list.extend([tc_type, tc_name])

                        tag_list = []
                        for tag in range(len(data[0]['elements'][i]['tags'])):
                            tag_name = data[0]['elements'][i]['tags'][tag]['name']
                            tag_list.append(tag_name)
                        final_data_list.append(':'.join(tag_list))
                        tc_category = data[0]['name']
                        final_data_list.append(tc_category)

                        for step in range(len(data[0]['elements'][i]['steps'])):
                            tc_status = "FAIL"
                            step_desc = data[0]['elements'][i]['steps'][step]['name']
                            step_status = data[0]['elements'][i]['steps'][step]['result']['status']
                            if step_status == "passed":
                                tc_status = "PASS"
                                error_message = ""
                            else:
                                error_message_keys = data[0]['elements'][i]['steps'][step]['result'].keys()
                                if "error_message" in error_message_keys:
                                    error_message = data[0]['elements'][i]['steps'][step]['result']['error_message']
                        if tc_status == "PASS":
                            passed_tc += 1
                        else:
                            failed_tc += 1
                        final_data_list.extend([tc_status])
                        final_data_list.extend([error_message, "", ""])
                        global_data_list.append(final_data_list)
                    self._openCsvReportFile(csvReportName, tc_name)
                    df = pd.DataFrame(global_data_list, columns=header_list)
                    df.to_csv(self.allReportList[0], index=False)
                    df = pd.DataFrame([len(global_data_list), passed_tc, failed_tc], ['TOTAL', 'PASS', "FAIL"])
                    df.to_csv(self.allReportList[0], mode='a', header=False)
                return True
        except Exception as err:
            print("ERROR : Failed to Generate CSV Report ", err)
            return False

    def getTestCategory(self, tSuiteName, mobileDevice=None, platform=None, browser=None):
        """
        This Method will get the Test Category and call the appropriate create summary report method
        """
        try:
            summaryReportType = ""
            for reportFileName in self.allReportList:
                with open(reportFileName, "r") as csvfile:
                    csvreader = csv.DictReader(csvfile)

                    for row in csvreader:
                        if (str(row["TEST_CATEGORY"]).strip()).lower() == "onboarding":
                            summaryReportType = "onboarding"
                            break
                        else:
                            summaryReportType = str(row["TEST_CATEGORY"]).strip()
                            break
                break
            if summaryReportType == "onboarding":
                self.createOnboardingSummaryReport(
                    tSuiteName, mobileDevice, platform, summaryReportType
                )
            else:
                self.createFeatureSummaryReport(
                    tSuiteName, mobileDevice, platform, summaryReportType, browser
                )
        except Exception as err:
            print("ERROR : Failed to Create Master Summary Report", err)
            return False

    def createOnboardingSummaryReport(
        self, tSuiteName, mobileDevice, platform, testCategory
    ):
        """
        This Method will generate onboarding Summary Report
        :param tSuiteName:
        :param mobileDevice:
        :return:
        """
        try:
            testSuiteIter = falseCount = passCount = 0
            attemptFailCount = attemptPassCount = 0
            dict_Temp = {}
            failureMsg = []
            tSuiteName = str(tSuiteName).lower()
            dName = self.createConfigData(mobileDevice, platform, tSuiteName)
            csv.register_dialect("myDialect", delimiter=",", skipinitialspace=True)
            df = pd.DataFrame([["Test Category", str(testCategory)], ["\n"]])
            df.to_csv(self.fileptr.name, mode='a', header=False, index=False)
            csv_columns = ["Iteration", str(tSuiteName), "Failure Msg", "Jira ID"]
            for rFile in self.allReportList:
                dict_Temp["SuiteName"] = dName[-1]
                testSuiteIter = testSuiteIter + 1
                with open(rFile, "r") as csvfile:
                    csvreader = csv.DictReader(csvfile)
                    data_line = []
                    for row in csvreader:
                        if not row["TEST_ID"]:
                            continue
                        if "FAIL" in row["TEST_STATUS"].upper():
                            falseCount = falseCount + 1
                            if "(" in row["FAILURE MSG"]:
                                row["FAILURE MSG"] = (
                                    row["FAILURE MSG"].split("(")[1].split(")")[0]
                                )
                            failureMsg.append(row["FAILURE MSG"].replace("\n", ""))
                        if "PASS" in row["TEST_STATUS"].upper():
                            passCount = passCount + 1
                    if falseCount >= 1:
                        attemptFailCount = attemptFailCount + 1
                        dict_Temp["IterationStatus"] = "Fail"
                    elif passCount != 0:
                        attemptPassCount = attemptPassCount + 1
                    dict_Temp["IterationStatus"] = "PASS"
                    dict_Temp["Iteration"] = testSuiteIter
                    dict_Temp["Passcount"] = attemptPassCount
                    dict_Temp["Failcount"] = attemptFailCount
                    if failureMsg:
                        dict_Temp["Failure_Message"] = failureMsg[0]
                    else:
                        dict_Temp['Failure_Message'] = ""
                    data_line.append([str(testSuiteIter), str(dict_Temp['IterationStatus']),
                                      str(dict_Temp['Failure_Message']), ''])
                    df = pd.DataFrame(data_line, columns=csv_columns)
                    df.to_csv(self.fileptr.name, mode='a', header=True, index=False)
                    falseCount = passCount = 0
                    failureMsg = []

            self._writeAttemptsCol(dict_Temp)
            print("\n{0}\n".format("=" * 60))
            print("INFO: LOG AND REPORT LOCATION DETAILS\n{0}\n".format("-" * 60))

            print("LOG FOLDER LOCATION IS : ", os.environ["logDir"])
            print("DETAIL SUMMARY CSV FILE LIST IS : ", self.allReportList)
            print(
                "Master SUMMARY CSV REPORT FILE NAME IS : ",
                os.environ["ReportFileName"],
            )
            print("\n{0}\n".format("=" * 60))
            self.allReportList = []
            return True
        except Exception as err:
            print("ERROR : Failed to Create Master Summary Report", err)
            return False

    def createFeatureSummaryReport(
        self, tSuiteName, mobileDevice=None, platform=None, testCategory=None, browser=None
    ):
        """
        Method will Create Summary CSV Report for other test category Sanity, ExtendedSanity
        :param tSuiteName: Test Suite Name
        :param mobileDevice: Mobile Device Details ( Device Name and Version)
        :param platform: Mobile Platform Name
        :param testCategory: Test Category (Ex: Sanity )
        :param browser: Test Browser that is being used
        :return:
        """
        try:
            totalIteration = len(self.allReportList)
            iterTCString = ""
            tSuiteName = str(tSuiteName).lower()
            self.createConfigData(mobileDevice, platform, tSuiteName, browser)
            csv.register_dialect("myDialect", delimiter=",", skipinitialspace=True)
            df = pd.DataFrame([["Test Category", str(testCategory)], ["\n"]])
            df.to_csv(self.fileptr.name, mode='a', header=False, index=False)

            for iter in range(totalIteration):
                iterTCString = iterTCString + "Iteration_" + str(iter + 1) + ","
            csv_columns = ["TestCase_ID", "TestName", iterTCString, "Failure Msg", "Jira ID"]
            tempdictTCID = OrderedDict()
            testSuiteIter = 0
            for rFile in self.allReportList:
                testSuiteIter = testSuiteIter + 1
                with open(rFile, "r") as csvfile:
                    csvreader = csv.DictReader(csvfile)
                    for row in csvreader:
                        if not row["TEST_ID"]:
                            break
                        TC_ID = str(row["TEST_ID"].strip())
                        TEST_CASE = str(row["TEST_CASE"].strip())
                        TC_Status = str(row["TEST_STATUS"].strip())
                        TC_MSG = str(row["FAILURE MSG"].strip())
                        TC_JIRAID = str(row["JIRA ID"].strip())
                        if TC_ID not in tempdictTCID:
                            tempdictTCID[TC_ID] = OrderedDict(
                                {"Iteration_" + str(testSuiteIter): [TEST_CASE, TC_Status, TC_MSG, TC_JIRAID]})
                        else:
                            tempdictTCID[TC_ID].update(
                                {"Iteration_" + str(testSuiteIter): [TEST_CASE, TC_Status, TC_MSG, TC_JIRAID]})

            tempDict = OrderedDict()
            final_temp_list = []
            for key, value in tempdictTCID.items():
                temp_list = []
                test_name = True
                line = ""
                line = line + key + ","
                temp_list.append(key)
                # To get the name of test case for each Iteration
                TC_IDSList = [elem[0] for elem in tempdictTCID[key].values()]
                tempList = []

                for data in TC_IDSList:
                    tempList.append(data)
                    if test_name:
                        line = line + data + ","
                        temp_list.append(data)
                        test_name = False
                # To get the status of test case for each Iteration
                TC_IDSList = [elem[1] for elem in tempdictTCID[key].values()]
                for data in TC_IDSList:
                    tempList.append(data)
                    line = line + data + ","
                    temp_list.append(data)
                tempDict[key] = tempList
                # To get the error msg of test case for each Iteration
                TC_IDEMList = [elem[2] for elem in tempdictTCID[key].values()]
                for data in TC_IDEMList:
                    if data not in line:
                        line = line + data + ";"
                        temp_list.append(data)
                    else:
                        temp_list.append("")
                line = line + ","
                # To get the jira id of test case for each Iteration
                TC_IDJiraList = [elem[3] for elem in tempdictTCID[key].values()]
                for data in TC_IDJiraList:
                    if data not in line:
                        line = line + data + ";"
                        temp_list.append(data)
                temp_list.append('')
                final_temp_list.append(temp_list)
            final_temp_list.append(["\n"])

            csv_columns_status = ["Test ID", "Test Status", "Test Name", "Comment"]
            # Loop update the Final Test Status

            temp_line_list = []
            for key, value in tempDict.items():
                line = ""
                line = line + key + ","
                if "FAIL" in (item.upper() for item in value):  # or "FAILED" in (item.upper() for item in value):
                    temp_line_list.append([line, "FAIL", str(value[0]), f"{str(value.count('FAIL'))} Fail Out Of {str(totalIteration)} Iteration"])
                else:
                    temp_line_list.append([key, "PASS", str(value[0]), ""])
            df = pd.DataFrame(final_temp_list, columns=csv_columns)
            df.to_csv(self.fileptr.name, mode='a', header=True, index=False)
            df = pd.DataFrame(temp_line_list, columns=csv_columns_status)
            df.to_csv(self.fileptr.name, mode='a', header=True, index=False)
            self.objCommon.closeFile(self.fileptr)

            print("\n{0}\n".format("=" * 60))
            print("INFO: LOG AND REPORT LOCATION DETAILS\n{0}\n".format("-" * 60))

            print("LOG FOLDER LOCATION IS : ", os.environ["logDir"])
            print("DETAIL SUMMARY CSV FILE LIST IS : ", self.allReportList)
            print("Master SUMMARY CSV REPORT FILE NAME IS : ", os.environ["ReportFileName"])
            print("\n{0}\n".format("=" * 60))
            self.allReportList = []
            return True
        except Exception as err:
            print("ERROR : Failed to Create Master Summary Report", err)
            return False

    def _writeAttemptsCol(self, dictAttempt):
        """
        Method to Write the Attempts Col into the detail CSV file
        :return:
        """
        try:
            line = "\nDevices,Attempts,PASS,FAIL,SUCCESS%"
            self.createTableTitle(line)
            dictAttempt['Success'] = float(dictAttempt['Passcount']) / float(dictAttempt['Iteration']) * 100
            line = str(dictAttempt["SuiteName"] + "," + str(dictAttempt['Iteration']) + "," \
                       + str(dictAttempt['Passcount']) + "," + str(dictAttempt['Failcount']) + "," + str(
                dictAttempt['Success']))
            self.createTableTitle(line)
            self.objCommon.closeFile(self.fileptr)
            return True
        except Exception as err:
            print("ERROR : Failed to Write Attempt in CSV Column", err)
            return False

    def createTableTitle(self, titleTableStr=None):
        """
        Method to create a Table Title in CSV File
        :return:
        """
        try:
            if titleTableStr is None:
                print("Table Title String is Missing")
                return False
            else:
                self.fileptr.write(titleTableStr + "\n")
                return True
        except Exception as err:
            print("Error : Failed to Create Table Title in CSV File", err)
            return False

    def get_general_summary(self, configDict):
        """
        This Method will get general summary data from Configuration
        """
        os.environ["Environment"] = configDict["Configuration"]["SetupConfiguration"][
            "Common"
        ]["Environment"]
        os.environ["ReleaseBranch"] = configDict["Configuration"]["SetupConfiguration"][
            "Common"
        ]["ReleaseBranch"]
        os.environ["DUT_DeviceName"] = configDict["Configuration"][
            "SetupConfiguration"
        ]["DUTDetails"]["projectDevice1"]["Name"]
        os.environ["DUT_ID"] = configDict["Configuration"]["SetupConfiguration"][
            "DUTDetails"
        ]["projectDevice1"]["ID"]
        os.environ["DUT_FWversion"] = configDict["Configuration"]["SetupConfiguration"][
            "DUTDetails"
        ]["projectDevice1"]["FirmwareVersion"]

    def create_report_file(self, configDict, logDir, mobileAppVer=None, webAppVer=None):
        """
        This method will create .reportdata.txt file for the CSV data
        """
        self.get_general_summary(configDict)
        config_file = open(logDir + "../.reportdata.txt", "w")
        config_file.write(f"Environment={os.environ['Environment']}\nTest Iteration={os.environ['TestIteration']}\nRelease Branch={os.environ['ReleaseBranch']}\nDUT Device Name={os.environ['DUT_DeviceName']}\nDUT ID={os.environ['DUT_ID']}\nDUT FW Version={os.environ['DUT_FWversion']}\n")
        if mobileAppVer:
            config_file.write(f"Mobile App Version={mobileAppVer}\n")
        elif webAppVer:
            config_file.write(f"Web App Version={webAppVer}\n")
        config_file.close()

    def createConfigData(self, mobileDevice, platform, testSuiteName, browser=None):
        """
        This will populate static data into the Report file
        :return:
        """
        try:
            CurrentDirectory = os.getcwd()
            summaryReportFileName = SUMMARY_REPORT_FILE_NAME + testSuiteName + "_"
            FileName = CurrentDirectory + summaryReportFileName
            self.fileptr = self.objCommon.createReportfile(FileName)
            reportFilePath = os.environ["logDir"]
            # Write of data into CSV File
            with open(reportFilePath + "../.reportdata.txt", "r") as in_file:
                stripped = (line.strip("\n") for line in in_file)
                lines = (line.split("=") for line in stripped if line)
                lineList = list(lines)
            scenario_data_list = []

            writer = csv.writer(self.fileptr)
            for line in lineList:
                if "DUT Device Name" in line:
                    deviceName = line
                else:
                    deviceName = None
                scenario_data_list.append(line)
            if mobileDevice:
                line = "Mobile Device, " + mobileDevice + "\n"
                scenario_data_list.append(line.split(","))
                line = "Platform, " + platform + "\n"
                scenario_data_list.append(line.split(","))
            elif browser:
                line = "Browser, " + browser + "\n"
                scenario_data_list.append(line.split(","))
            line = "Release Branch, " + os.environ["ReleaseBranch"] + "\n"
            scenario_data_list.append(line.split(","))
            df = pd.DataFrame(scenario_data_list)
            df.to_csv(self.fileptr.name, header=False, index=False)
            return deviceName
        except Exception as err:
            print("Error : Failed to Create Config Data ", err)
            return False

    def _writeIterationSummary(self, line):
        """
        Method to Write the Iteration Summary of onboarding
        :return:
        """
        try:
            self.fileptr.write(line)
        except Exception as err:
            print("Error : Failed to Write Iteration Summary", err)
            return False


if __name__ == "__main__":
    objReport = TestReportGenerator()
