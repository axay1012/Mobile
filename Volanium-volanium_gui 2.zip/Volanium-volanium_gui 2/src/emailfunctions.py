#!/usr/bin/env python

##################################################################
# Library To Generate the Data Required for Email of Test Results
##################################################################
from common import common
from xlrd import open_workbook


class emailfunctions():

    def __init__(self):
        self.commonobj = common()

    def getSubjectLine(self, subFilePath):
        """
        Method Parse email subject file.
        :param Absolute Path of the subject file name
        :return: Subject String
        """
        try:
            sub = ""
            if self.commonobj.fileExists(subFilePath):
                with open(subFilePath, 'r') as f:
                    details = f.readlines()
                    for detail in details:
                        sub = sub + " " + detail.rstrip('\n')
            else:
                print("Specified Subject File is Missing : ", subFilePath)
                return False
            return sub
        except Exception as err:
            print("Error : Failed to Parse the subject file", err)
            return None

    def getToAddress(self, emailFilePath):
        """
        Method to get To Address List from the File
        :param emailFilePath: The Absolute Path of email ID detail file
        :return: List of To Email ID's
        """
        try:
            if self.commonobj.fileExists(emailFilePath):
                with open(emailFilePath, 'r') as emailfile:
                    details = emailfile.readlines()
                    for detail in details:
                        if detail.startswith('To') or detail.startswith('to') or detail.startswith('TO'):
                            emailToAddressList = detail.rstrip('\n').split('=')[1].split(',')
                        if detail.startswith('Cc') or detail.startswith('cc') or detail.startswith('CC'):
                            emailCcAddressList = detail.rstrip('\n').split('=')[1].split(',')
            else:
                print("Email To Address File is Missing : ", emailFilePath)
                return False
            return emailToAddressList, emailCcAddressList
        except Exception as err:
            print("Error : Failed to Get the To Email List", err)
            return None

    def getAttachments(self, FilePath):
        """
        Method to get the File Name list for the Email Attachment
        :param FilePath: The Absolute Path of FilePath
        :return: List of FileName to be attached
        """
        try:
            fileForAttachment = list()
            if self.commonobj.fileExists(FilePath):
                with open(FilePath, 'r') as f:
                    details = f.readlines()
                    for detail in details:
                        fileForAttachment.append(detail.rstrip('\n'))
            else:
                print("List of Attachement File is Missing : ", FilePath)
                return False
            return fileForAttachment
        except Exception as err:
            print("Error : Failed to Get the List to attach the email ", err)
            return None

    def getEmailBody(self, emailBodyFilePath):
        """
        Method to get the Email body from the absolute Path of email details file
        :param FilePath: The Absolute Path of FilePath
        :return: Body String
        """
        try:
            self.emailFilePath = emailBodyFilePath
            if self.commonobj.fileExists(self.emailFilePath):
                with open(self.emailFilePath, 'r') as emailfile:
                    email = emailfile.read()
                body = email[email.find('###START_BODY###') + len('###START_BODY###'):email.rfind('###END_BODY###')]
                return body
            else:
                print("Email Body Details File is Missing : ", emailBodyFilePath)
                return False
        except Exception as err:
            print("Error : Failed to Read the Email Body", err)
            return None

    def excelToListHTMLTableStr(self, masterSummaryReport):
        """
        Method to Read the Master Summary Report (Excel File) and Create
        the List of Strings
        :param masterSummaryReport: absolute Path of the Master Summary Report Excel File
        :return: List of String to create a HTML String
        """
        try:
            # Check Whether Master Summary Report Exist or Not
            if self.commonobj.fileExists(masterSummaryReport):
                wb = open_workbook(masterSummaryReport)
                sheet = wb.sheet_by_name("MasterSummary")
                values = []
                for row in range(sheet.nrows):
                    col_value = []
                    for col in range(sheet.ncols):
                        value = (sheet.cell(row, col).value)
                        if value != "":
                            col_value.append(value)
                    values.append(col_value)
            return values
        except Exception as err:
            print("Reading Excel File Failed ", err)
            return False

    def listToHTMLTableStr(self, listofvalues):
        """
        Method to Generate HTML Table String
        :param listofvalues:
        :return: HTML Table in String format
        """
        count = 0
        # For Loop to get the Total Number of Attempts String
        for data in listofvalues:
            for value in data:
                if "# of " in value:
                    count += 1

        # Below Section will Create an HTML Table for Test Setup Details

        # write <table> tag
        HtmlStr = ''
        HtmlStr += '<table border="1">'
        temp = 0
        IndexNumber = 0
        for data1 in listofvalues:
            HtmlStr += '<tr>'  # write <tr> tag
            for value1 in data1:
                if "# of " in value1:
                    temp += 1
                HtmlStr += '<th style="width: 120px;">' + value1 + '</th>'
            HtmlStr += '</tr>'
            if temp == count:
                IndexNumber = listofvalues.index(data1)
                break

        # # write </table> tag
        HtmlStr += '</table>'

        # Below Section will Create an HTML Table for Test Result Details

        HtmlStr += '<table border="1">'

        for i in range(IndexNumber + 1, len(listofvalues)):
            HtmlStr += '<tr>'  # write <tr> tag
            for value in listofvalues[i]:
                if value == "Onboarding" or value == "Sanity" or value == "Regression":
                    HtmlStr += '<th style="width: 100px;">' + value + '</th>'
                else:
                    HtmlStr += '<td style="width: 100px;">' + value + '</td>'
            HtmlStr += '</tr>'
        # # write </table> tag
        HtmlStr += '</table>'

        return HtmlStr


if __name__ == '__main__':
    objemailfunctions = emailfunctions()
