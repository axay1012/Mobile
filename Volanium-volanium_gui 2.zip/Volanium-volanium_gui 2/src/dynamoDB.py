#!/usr/bin/env python

##################################################################
# Library To push the json data into DynamoDB
##################################################################

import json
import boto3
from botocore.exceptions import *


class DynamoDB(object):

    def load_table(self, jsonFiles, region, tableName, dynamodb=None):
        """
        This function will take the passed in parameters and loads the data on dynamoDB table.
        :param jsonFiles:
        :param region:
        :param tableName:
        :return:
        """
        if not dynamodb:
            dynamodb = boto3.resource('dynamodb', region_name=region)
        try:
            for jsonFile in jsonFiles:
                with open(jsonFile) as f:
                    data_list = json.load(f)
                    data_list['test_id'] = str(data_list['test_id'])
                    table = dynamodb.Table(tableName)
                table.put_item(Item=data_list)
                print(data_list)
        except Exception as error_message:
            print("\n\nFailed to Load JSON Data on DynamoDB:- {} \n\n".format(error_message))

    def validate_user(self, region, tableName):
        """
        This function will be used for authenticating user on dynamoDB
        Returns: True or False
        """
        dynamodb_client = boto3.client('dynamodb', region_name=region)
        try:
            response = dynamodb_client.describe_table(TableName=tableName)
            json.loads(response)
            return True
        except NoCredentialsError:
            print("ERROR : Could Not Get AWS Credentials, Please Configure AWS")
            return False
        except dynamodb_client.exceptions.ResourceNotFoundException:
            print("ERROR : Could Not Find Table = ", tableName)
            return False
