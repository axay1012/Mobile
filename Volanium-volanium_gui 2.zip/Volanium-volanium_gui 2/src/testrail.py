"""
Info: Python script to communicate with the testrail account and update the tests status
"""

from builtins import str
import re
import json
from time import sleep
import requests
import pandas as pd

CONTENT_TYPE_HEADER = {'Content-Type': 'application/json'}
RUN_ID = None
TEST_CONFIG = {}
trUrlList = []
fileListLength = 0
last_run_id = 0
RUN_STATUS = False
VALID_TESTS = []
FAIL_TESTS = {}


class TestRailRequest(object):
    def __init__(self, url, username, passwd, project_id=None, testcases=None, testRunName=None):
        self.url = url
        self.username = username
        self.passwd = passwd
        self.project_id = project_id
        self.testcases = testcases
        self.testRunName = testRunName
        self.new_run_id = self.create_run_id(self.project_id, self.testcases, self.testRunName)
        global RUN_ID
        RUN_ID = self.new_run_id
        print("Run id already created:- {}".format(RUN_ID))
        print("Username is {0} and Password is {1}, Run id:- {2}\
              and project id is {3} and testrun title is\
              {4}".format(self.username,
                          self.passwd,
                          RUN_ID,
                          self.project_id,
                          self.testRunName))

    def get_run_id(self):
        return self.new_run_id

    def check_testrail_status(self, status):
        if not status:
            return False
        else:
            return True

    def create_run_id(self, project_id, testcases, testRunName):
        """
        Method to get the run id of the project

        :param project_id: Particular project id
        :return test_id: Test Run id
        """
        # Testrail API configuration
        params = (('/api/v2/add_run/{}'.format(str(project_id)), ''),)
        headers = CONTENT_TYPE_HEADER
        int_testcases = [re.findall(r'\d+', test)[0] for test in testcases]
        testRunTitle = testRunName
        # Upload the test data in to the testrail with the help of testrail API
        # POST index.php?/api/v2/add_run/:project_id
        data = {"name": testRunTitle, "include_all": False, "case_ids": int_testcases}
        data = json.dumps(data)
        response = requests.post(self.url,
                                 headers=headers,
                                 params=params,
                                 data=data,
                                 auth=(self.username, self.passwd))
        current_test_id = json.loads(response.text)
        test_id = current_test_id.get("id")
        if response.status_code != 200:
            print("response code is : ", response.status_code)
            return False

        global RUN_ID
        RUN_ID = test_id
        return test_id

    def update_run_id(self, project_id, testcases, testRunName):
        """
        Method to get the run id of the project

        :param project_id: Particular project id
        :return test_id: Test Run id
        """
        # Testrail API configuration
        global RUN_ID
        params = (('/api/v2/update_run/{}'.format(str(RUN_ID)), ''),)
        headers = CONTENT_TYPE_HEADER
        int_testcases = [re.findall(r'\d+', test)[0] for test in testcases]
        testRunTitle = testRunName
        # Upload the test data in to the testrail with the help of testrail API
        # POST index.php?/api/v2/add_run/:project_id
        data = {"name": testRunTitle, "include_all": False, "case_ids": int_testcases}
        data = json.dumps(data)
        response = requests.post(self.url,
                                 headers=headers,
                                 params=params,
                                 data=data,
                                 auth=(self.username, self.passwd))
        print("Result code is {0} and message is {1}".format(response, response.text))
        current_test_id = json.loads(response.text)
        test_id = current_test_id.get("id")

        return test_id

    def get_testrail_summary(self):
        """
        Method to get the testrail summary of the particular run id
        :param run_id: Particular Run id
        :return status of run id
        
        GET index.php?/api/v2/get_results_for_run/:run_id
        Testrail API configuration
        params = (('/api/v2/add_run/{}'.format(str(project_id)), ''),)
        GET index.php?/api/v2/get_results_for_run/1&created_by=5&limit=10
        """
        run_id = RUN_ID
        # GET index.php?/api/v2/get_results/1&status_id=4,5&limit=10
        total_params = (('/api/v2/get_tests/{}'.format(str(run_id)), ''),)
        # GET index.php?/api/v2/get_tests/:run_id
        headers = CONTENT_TYPE_HEADER

        total_response = requests.get(self.url,
                                      headers=headers,
                                      params=total_params,
                                      auth=(self.username, self.passwd))
        total_tests_response = json.loads(total_response.text)
        total_data = [data.get('status_id') for data in total_tests_response]
        total_tests = len(total_data)
        passed_tests = total_data.count(1)
        failed_tests = total_data.count(10)
        testrail_data = {}
        testrail_data["total"] = total_tests
        testrail_data["passed"] = passed_tests
        testrail_data["failed"] = failed_tests
        global TEST_CONFIG
        TEST_CONFIG = testrail_data
        return testrail_data

    def add_comment(self, case_id, status_id, comment):
        """
        Method to upload the data into the testrail account

        :param case_id: Test case id
        :param status_id:  Status of the particular tests
        :param comment: Test Comment
        """
        print("Received values are:- case_id: {0}, status_id: {1} \
              and comment: {2}".format(case_id, status_id, comment))
        self.results = {'PASS': 1, 'FAIL': 10}
        run_id = RUN_ID
        # convert the case id into the valid value
        new_case_id = re.findall(r'\d+', case_id)[0]

        # get the current status id of the tests result(pass/fail)
        current_status = self.results.get(status_id)

        # Testrail API configuration
        params = (('/api/v2/add_result_for_case/{0}/{1}'.format(str(run_id), str(new_case_id)), ''),)
        headers = CONTENT_TYPE_HEADER
        data = {"status_id": current_status, "comment": comment}
        data = json.dumps(data)

        # Upload the test data in to the testrail with the help of testrail API
        response = requests.post(self.url,
                                 headers=headers,
                                 params=params,
                                 data=data,
                                 auth=(self.username, self.passwd))
        return response


def read_csv(filename):
    """
    Method to read the csv file

    :param filename: Name of Test file
    :return df: Pandas DataFrame
    """
    df = pd.read_csv(filename, usecols=range(0, 42), header=None, engine='python')
    return df


def get_shape(df):
    """
    Method to get the current shape of the data

    :param df: Pandas DataFrame
    :return row, column: Number of rows and columns
    """
    row, column = df.shape
    return row, column


def get_row_index(col_name, col_val, df):
    """
    Get the row index number based on the column value and number

    :param col_name: Column name
    :param col_val:  Column values
    :param df: Pandas DataFrame
    :return Row index number
    """
    return df.index[df[col_name] == col_val].to_list()


def get_test_case(df):
    """
    Method to get the current valid testcases

    :param df: Pandas DataFrame
    :return valid_df: DataFrame of valid Testcases
    """
    valid_df = df[df[0].apply(lambda x: x.startswith('C'))]
    return valid_df


def get_fail_data(df):
    """
    Method to get the testcases who had fail Label.

    :param df: Pandas DataFrame
    :return fail_tests: Number of Failed Testcases
    """
    fail_indexes = get_row_index(1, 'FAIL', df)
    fail_tests = [df.loc[index][0] for index in fail_indexes]
    return fail_tests


def get_fail_comment(df, fail_tests):
    """
    Method to get the fail comments of the Failed Testcases.

    :param df: Pandas DataFrame
    :param fail_tests: Number of Failed Testcases
    :return fail_comments_tc: Comments of Failed Testcases
    """
    global FAIL_TESTS
    for tests in fail_tests:
        value = get_row_index(0, tests, df)[0]
        try:
            FAIL_TESTS[tests] = df.iloc[value, -2]
        except Exception as error_message:
            FAIL_TESTS[tests] = 'Failed'
    return FAIL_TESTS


def upload_data_testrail(file_name):
    """
    Method to upload the data to the Testrail from the report file

    :param file_name: Report filename
    :param user_name: Testrail username
    :param password: Testrail password
    :param run_id:  Testrail Run id
    :param test_url:  Testrail URL
    """
    try:
        print("Uploading Data into the testrail:- {}".format(file_name))
        dataframe = read_csv(file_name)
        row, column = get_shape(dataframe)
        row_number = get_row_index(0, 'Test ID', dataframe)[0]
        valid_df = dataframe[row_number:row]
        valid_tests = get_test_case(valid_df)
        updated_df = dataframe[0:row_number]
        fail_data = get_fail_data(valid_tests)
        fail_com = get_fail_comment(updated_df, fail_data)
        indexes = valid_tests.index.tolist()

        # upload the data one by one
        testcases = [valid_tests.loc[data][0] for data in indexes]
        for data in indexes:
            VALID_TESTS.append(valid_tests.loc[data][0])
        print(valid_tests)
        return valid_tests, "Successfully parsed testrail case ids", True

    except Exception as error_message:
        print("Received Exception in upload_data_testrail and error:- {}".format(error_message))
        return False, error_message, False


def testrail_update_result(file_names, user_name, password, test_url, project_id, run_name):
    # global RUN_STATUS
    try:
        print("Initialize the testrail update process")
        for file_name in file_names:
            df, return_message, return_status = upload_data_testrail(file_name)

        if not return_status:
            return False, "Parsing Error:- {}".format(return_message)

        # validation for the required data
        if not project_id:
            return False, "Please specify valid project id"

        if not user_name or not password or not test_url or not project_id:
            return False, "Error in retrieving username, password, test_url or project id"

        # get the shape of the data
        length, _ = get_shape(df)
        print("Length of the data is : {}".format(length))

        test_rail = TestRailRequest(url=test_url,
                                    username=user_name,
                                    passwd=password,
                                    project_id=project_id,
                                    testcases=VALID_TESTS,
                                    testRunName=run_name)

        testrail_status = test_rail.check_testrail_status(RUN_ID)
        print("value of testrail_status is : ", testrail_status)
        if not testrail_status:
            print("Error While Uploading data to TestRail")
            return False, "Error While Uploading data to TestRail"

        for data in VALID_TESTS:
            sleep(1)
            if data not in FAIL_TESTS:
                test_status = 'PASS'
                test_comment = 'PASS. Received expected output'
            else:
                test_status = 'FAIL'
                test_comment = FAIL_TESTS.get(data)
            test_case_id = data
            print("Comment:- {0}\n test_status:- {1}\n test_id: {2}".format(test_comment, test_status, test_case_id))

            test_rail.add_comment(test_case_id, test_status, test_comment)

        sleep(5)

        return True, "{}index.php?/runs/view/{}".format(test_url, RUN_ID)

    except Exception as error_message:
        print("Encountered Error:- ", error_message)
        return False, "Error:- {}".format(error_message)


if __name__ == '__main__':
    run_name = 'Automation_Execution'
    testrail_update_result(file_names=None, user_name=None, password=None, test_url=None, project_id=None, run_name=run_name)
