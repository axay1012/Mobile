#!/usr/bin/env python

##################################################################
# Common Library includes all common functions used by Framework
##################################################################

import datetime
import time
import os
import re
import xmltodict
import json
import xml.dom.minidom as dom
import subprocess
from flatten_json import flatten

rFileList = []


class common:

    def startADBServer(self, portNum):
        """
        Start ADB Server on specific port
        """
        try:
            FNULL = open(os.devnull, 'w')
            subprocess.call(["adb", "-P", str(portNum), "start-server"],
                            stdout=FNULL,
                            stderr=subprocess.STDOUT)
            return True
        except Exception as err:
            print("Error: Start ADB Server Failed", err)
            return False

    def stopADBServer(self, portNum):
        """
        Stop ADB Server from specific port
        """
        try:
            if self.killProcessByPort(portNum):
                return True
            else:
                return False
        except Exception as err:
            print("ERROR : Stop ADB Server Failed", err)
            return False

    def checkAppiumServerStatus(self):
        """
        Check that appium server is running or not.
        Return 0 if appium server is running otherwise 1.
        """
        try:
            pid = subprocess.Popen("pgrep [n]ode", shell=True, stdout=subprocess.PIPE)
            return pid.stdout.readline().decode('utf-8').rstrip()
        except Exception as err:
            print("Error: Appium Server Status Check Failed ", err)
            return False

    def startAppiumServer(self, portNum):
        """
        Starts the Appium server on specific port
        """
        try:
            FNULL = open(os.devnull, 'w')
            port = int(portNum)
            bootStrapPort = int(portNum) + 1

            output = subprocess.Popen("appium -p {0} --base-path /wd/hub".format(port),
                                      shell=True,
                                      stderr=FNULL,
                                      stdout=subprocess.PIPE)
            while True:
                if "started" in output.stdout.readline().decode("UTF-8"):
                    time.sleep(3)
                    break
            return True
        except Exception as err:
            print("Error: Start Appium Server Failed", err)
            return False

    def stopAppiumServer(self, portNum):
        """
        Stops the Appium server from specific port
        """
        try:
            if self.killProcessByPort(portNum):
                return True
            else:
                return False
        except Exception as err:
            print("ERROR : Stop Appium Server Failed", err)
            return False

    def getAppiumRemoteUrl(self, portNum):
        """
        Prepare Remote URL of Appium Server
        """
        try:
            return "http://localhost:{0}/wd/hub".format(str(portNum))
        except Exception as err:
            print("ERROR : ", err)
            return False

    def fileExists(self, fileName):
        """
        This function checks whether file exists or not
        Argument : Absolute file pathR
        Return : True if Success, else False
        """
        try:
            if os.path.isfile(fileName):
                return True
            else:
                return False
        except Exception as err:
            print("Error : Failed to check file exist or not ", err)
            return False

    def dirExists(self, dirName):
        """
        This function checks whether directory exists or not
        Argument : Absolute directory path
        Return : True if success, else False
        """
        try:
            if os.path.isdir(dirName):
                return True
            else:
                return False
        except Exception as err:
            print("Error : Failed to check directory exist or not", err)
            return False

    def xmlValidator(self, fileName):
        """
        This function validates the syntax of a XML file
        Argument : Absolute file path with file name
        Return : True if Success, else False
        """
        if self.fileExists(fileName):
            with open(fileName) as f:
                try:
                    dom.parse(fileName)
                    return True
                except Exception as err:
                    print("Error : XML File format is incorrect !!", err)
                    return False
        else:
            return False

    def xmlParser(self, fileName):
        """
        This function Converts the given xml file into ordered dictionary
        Argument : Absolute file path with file name
        Return : Dictionary if xml parser is success, else false.
        """
        if self.xmlValidator(fileName):
            try:
                with open(fileName) as f:
                    dictData = xmltodict.parse(f.read())
                    configJson = json.dumps(dictData)
                    configDict = json.loads(configJson)
                    return configDict
            except Exception as err:
                print("Error : XML Parser Failed ", err)
                return False
        else:
            return False

    def xmlToJson(self, xmlFile, jsonFile):
        """
        This function Converts the given xml file data to json
        Argument : Absolute file path with file name
        Return : json file if successful, Error if not successful
        """
        if not self.fileExists(xmlFile):
            print("ERROR: OUTPUT XML FILE {0} NOT FOUND".format(xmlFile))
            return False

        if self.xmlValidator(xmlFile):
            try:
                with open(xmlFile) as f:
                    dictData = xmltodict.parse(f.read(), attr_prefix='')
                    configJson = json.dumps(dictData)
                    jsonDataDict = json.loads(configJson)
            except Exception as err:
                print("Error : XML Parser Failed ", err)
                return False

        if not jsonDataDict:
            return False
        else:
            try:
                with open(jsonFile, 'w') as f:
                    json.dump(jsonDataDict, f)
                return True
            except Exception as err:
                print("Error : XML to JSON Parser Failed ", err)
                return False

    def updateJson(self, jsonFile, testId, component):
        """
        This function updates the given json file with given key-value pairs
        Argument : Absolute file path with file name
        Return : json file if successful, Error if not successful
        """
        if not self.fileExists(jsonFile):
            print("ERROR: JSON FILE {0} NOT FOUND".format(jsonFile))
            return False
        try:
            with open(jsonFile) as f:
                jsonDataDict = json.load(f)
            jsonDataDict.update({'test_id': testId})
            jsonDataDict.update({'environment': os.environ['Environment']})
            if component.lower() == 'android' or component.lower() == 'ios':
                jsonDataDict.update({'mobilePlatform': os.environ['PlatformName']})
            elif component.lower() == 'web':
                jsonDataDict.update({'Browser': os.environ['Browser']})

            flat_json = flatten(jsonDataDict)
            with open(jsonFile, 'w') as f:
                json.dump(flat_json, f)
            return True
        except Exception as err:
            print("Error : Fail to Update JSON File ", err)
            return False

    def getCurrentTime(self, timeFormatRequired='%H:%M:%S'):
        """
        This function get the current system time.
        Argument : Required Time Format. Default is '%H:%M:%S')
        Return: Current time in requested format or default format.
        """
        try:
            timeStr = time.strftime(timeFormatRequired)
            return timeStr
        except Exception as err:
            print("Error: Failed to get Current Time", err)
            return False

    def getTodayDate(self, dateFormatRequired='%d:%m:%Y'):
        """
        This function get the system today's date.
        Argument : Required date Format. Default is '%d:%m:%Y')
        Return: Current date in requested format or default format.
        """
        try:
            dateStr = time.strftime(dateFormatRequired)
            return dateStr
        except Exception as err:
            print("Error: Failed to get Today's Date ", err)
            return False

    def getCurrentEpochTime(self):
        """
        This function get the current EpochTime of the system.
        Return: Current Epoch time , False when exception.
        """
        try:
            temp = datetime.datetime.now()
            currentEpochTime = int(time.mktime(temp.timetuple()))
            return currentEpochTime
        except Exception as err:
            print("Error: Failed to get Current Epoch Time ", err)
            return False

    def splitLines(self, lineToSplit):
        """
        Splits the lines and removes the white spaces
        Argument : Line to split
        Return : List of splited line
        """
        try:
            return re.split(r'[\r\n]+', lineToSplit.rstrip())
        except Exception as err:
            print("Error: Failed to split the lines", err)
            return False

    def deleteFile(self, fileName):
        """
        This function deletes the file
        Argument : Absolute path of file
        Return : Ture if deleted, False if not deleted
        """
        if self.fileExists(fileName):
            try:
                os.remove(fileName)
                return True
            except Exception as err:
                print("Error: Failed to delete a file", err)
                return False
        else:
            return False

    def openFile(self, fileName, fileMode='a'):
        """
        Open File at given path
        Argument: File Name and file open mode
        Return: File pointer
        """
        try:
            filePtr = open(fileName, fileMode)
            return filePtr
        except Exception as err:
            print("ERROR : Failed to Open a file in a specific mode", err)
            return False

    def closeFile(self, filePtr):
        """
        Close File
        Argument: File pointer
        Return: True on successful close
        """
        try:
            filePtr.close()
            return True
        except Exception as err:
            print("ERROR: Failed to Close a file", err)
            return False

    def getFileSize(self, fileName):
        """
        This function gives file size
        Argument : File Name
        Return : Size of file in bytes
        """
        if self.fileExists(fileName):
            try:
                size = os.stat(fileName)
                return size.st_size
            except Exception as err:
                print("ERROR: Failed to Get the File Size", err)
                return False
        else:
            return False

    def killProcessByPort(self, portNum):
        """
        Kill the process over specific port
        Argument: port_number
        Return: "True" if process over given port terminated succesfuuly
        """
        try:
            killCmd = 'kill -9 $(lsof -t -i:{0} -sTCP:LISTEN)'. \
                format(int(portNum))
            retCode = os.system(killCmd + "> /dev/null 2>&1")
            if int(retCode) != 0:
                return False
            return True
        except Exception as err:
            print("ERROR : Failed to kill the process by port number", err)
            return False

    def removeWhiteSpace(self, inputStr):
        """
        Remove White Space of device name
        """
        try:
            return inputStr.strip().rstrip()
        except Exception as err:
            print("ERROR: failed to remove the White Space in a string", err)
            return False

    def createReportfile(self, fileName):
        try:
            epochTime = self.getCurrentEpochTime()
            reportFileName = str(fileName) + str(epochTime) + ".csv"
            emailAttachmentReportFileList = os.environ['CurrentPath'] + "/.reportfilelistforemailattachment.txt"
            reportfileptr = self.openFile(emailAttachmentReportFileList, fileMode='a')
            reportfileptr.write(reportFileName + "\n")
            reportfileptr.close()
            os.environ['ReportFileName'] = reportFileName
            # Variable rFileList Stores filename in a list
            global rFileList
            rFileList.append(reportFileName)
            with open('.testrailfilelist.txt', 'w+') as f:
                for item in rFileList:
                    f.write("%s\n" % item)
            fileptr = self.openFile(reportFileName, fileMode='a')
            os.environ['fileListLength'] = str(len(rFileList))
            return fileptr
        except Exception as err:
            print("ERROR: Failed to Create Report File", err)
            return False

    def startExec(self, CMD):
        try:
            os.system(CMD)
            return True
        except Exception as err:
            print("ERROR: Failed to start the Execution.", err)
            return False

    def getMobileAppLogs(self, deviceId, logFileName):
        """
        This Method will start the adb logcat command in background to capture the Mobile app log file
        :param deviceId and logFileName
        :return: PID of the Mobile Log file
        """
        try:

            CMD_to_CaptureLog = "adb -s " + deviceId + " logcat -d>> " + logFileName + " &"
            subprocess.run(CMD_to_CaptureLog, stdout=subprocess.PIPE, shell=True)
            time.sleep(1)
            CMD_to_GetPID = "ps aux | grep 'adb -s " + deviceId + " logcat' | grep -v grep | awk '{print $2}'"
            mobileAppLogFilePID = subprocess.run(CMD_to_GetPID, stdout=subprocess.PIPE, shell=True)
            return str(mobileAppLogFilePID.stdout).split("\\n")[0].split('b')[1].split('\'')[1]
        except Exception as err:
            print("ERROR: Failed to start the Mobile App log capture ", err)
            return False

    def getTestrailDetails(self, filename):
        """
        :param testrailUrl: Testrail URL , For Ex : https://xxxx.testrail.net/
        :param userName: testrail username
        :param passWord: testrail password
        :return:
        """
        try:
            configDict = self.xmlParser(filename)
            testrail_Details = {}
            testrail_Details["testrailUrl"] = configDict['Configuration']['SetupConfiguration']['TestRail']['Url']
            testrail_Details["trUserName"] = configDict['Configuration']['SetupConfiguration']['TestRail']['userName']
            testrail_Details["trPassWord"] = configDict['Configuration']['SetupConfiguration']['TestRail']['passWord']
            testrail_Details["testProjectId"] = configDict['Configuration']['SetupConfiguration']['TestRail'][
                'testProjectId']
            testrail_Details["trRunName"] = configDict['Configuration']['SetupConfiguration']['TestRail'][
                'testRunTitle']
            return testrail_Details, "Successfully received"
        except Exception as err:
            print("Error: Failed to Get Testrail Credentials", err)
            return False, err

    def getConfluenceDetails(self, filename):
        """
        :param confluenceUrl: URL of Confluence , Here : https://xxxx.atlassian.net/
        :param userName: confluence username
        :param authToken: confluence authToken
        :param Parent Page ID: Parameter for taking Parent Page ID
        :return:
        """
        try:
            print(filename)
            configDict = self.xmlParser(filename)
            confluence_Details = {}
            confluence_Details["confluenceUrl"] = configDict['Configuration']['SetupConfiguration']['Confluence']['Url']
            confluence_Details["username"] = configDict['Configuration']['SetupConfiguration']['Confluence']['userName']
            confluence_Details["authToken"] = configDict['Configuration']['SetupConfiguration']['Confluence'][
                'authToken']
            confluence_Details["parentPageId"] = configDict['Configuration']['SetupConfiguration']['Confluence'][
                'parentPageId']
            confluence_Details["pageTitle"] = configDict['Configuration']['SetupConfiguration']['Confluence'][
                'pageTitle']
            return confluence_Details, "Successfully received"
        except Exception as err:
            print("Error: Failed to Get Required Details for Confluence", err)
            return False, err


if __name__ == "__main__":
    objCommon = common()
