# This code sample uses the 'requests' library:
# http://docs.python-requests.org
import requests
import json
import os
import zipfile
from collections import OrderedDict
import pandas as pd


class prepare_confluence_data(object):

    def __init__(self):
        self.url = None
        self.filename = None
        self.pageID = None
        self.username = None
        self.password = None

    def check_status_code(self, response, pass_message='Received Expected information',
                          fail_message='Fail to retrieve the information'):
        """ 
        Utility for checking the status code,
   
        :param response: Http Response
       :param pass_message: Message for Successful attempt
        :pa ram fail_message: Message for Unsuccessful attempt
        :return None
        """
        if response.status_code == 200:
            print(pass_message)
        else:
            print(fail_message)
            print(response.text)

    def add_comment(self, auth1, url, pagetitle, comment):
        """
        Utility to add comment on the confluence page

        :param auth1: Authentication (username and token)
        :param url: Link of the Confluence page where we want to add comment
        :param comment: Comment to add on the particular page.
        :return None
        """

        # Get the parent page id from the confluence
        r = requests.get(url,
                         params={'title': pagetitle},
                         auth=auth1)
        print(r.status_code)

        # Check for the Status Code
        self.check_status_code(r)

        parentPage = r.json()['results'][0]
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        # update the page comment format
        page_comment = "<p> {} </p>".format(comment)
        parentPage = r.json()['results'][0]
        pageData = {'type': 'comment', 'container': parentPage,
                    'body': {'storage': {'value': page_comment, 'representation': 'storage'}}}

        # request to the confluence with necessary data
        r = requests.post(url,
                          data=json.dumps(pageData),
                          auth=auth1,
                          headers=({'Content-Type': 'application/json'}))
        print(r.status_code)

        # check status code again
        self.check_status_code(r)

    def upload_with_request(self, url, auth1, query, filename):
        data = {"comment": "this is data file"}

        files = {'file': open(filename, 'rb')}
        headers = {"X-Atlassian-Token": "nocheck"}
        r = requests.request(
            "PUT",
            url,
            data=data,
            headers=headers,
            params=query,
            files=files,
            auth=auth1
        )

        print(r.status_code)

        # check status code again
        self.check_status_code(r)

    def get_content_version(self, url, pagetitle, auth1=None):
        """
        Utility to get the Version number of the Page

        :param url: Page URL
        :param pagetitle: Title of the page
        :return version_num: Page Version number
        """
        received_response = self.get_page_content(url, pagetitle, auth1)
        version_link = (received_response['version']['_links']['self'])
        version_num = version_link.split('/')[-1]
        return version_num

    def get_content_pageid(self, response=None, url=None, pagetitle=None, new=True, auth1=None):
        """
        Utility to get the Page id of the Page

        :param url: Page URL
        :param pagetitle: Title of the page
        :return page_id: Page ID
        """
        if new == True:
            response = json.loads(response)
            page_id = response['_links']['self'].split('/')[-1]
        else:
            received_response = self.get_page_content(url, pagetitle, auth1)
            page_id = (received_response['results'][0]['id'])
        return page_id

    def get_page_content(self, url, pagetitle, auth1=None):
        """
        Utility to get the page content

        :param url: Page URL
        :param pagetitle: Title of the page
        :return received_response: Page Response in text format
        """
        r = requests.get(url,
                         params={'title': pagetitle},
                         auth=auth1)
        print(r.status_code)
        self.check_status_code(r)
        received_response = (r.json())
        return received_response

    def authenticate_user(self, url, username, authToken):
        self.url = url
        self.username = username
        self.authToken = authToken
        headers = {"Application": "application/json"}
        response = requests.get(self.url, headers=headers, auth=(self.username, self.authToken))
        try:
            json.loads(response.text)
            print("Authentication Successful")
            return True
        except ValueError as err:
            return False

    def upload_docs(self, url, filename, pageID, username, password):
        """
        url: https://xxxx.atlassian.net/wiki/rest/api/content/
        """
        url = str(url) + str(pageID)
        command = 'curl -v -S -u {}:{} -X POST -H "X-Atlassian-Token: no-check" -F "file=@{}" -F  "comment=this is test file" "{}/child/attachment"'.format(
            username, password, filename, url)
        os.system(command)

    def upload_content_request(self, url, pagetitle, contentid, auth1, table_data, last_dataframe_index, df, pageID,
                               filenames, cnfLogDir):

        uname = auth1[0]
        token = auth1[1]
        fileToUpload = filenames[0]
        self.upload_docs(url, fileToUpload, contentid, uname, token)
        masterSummaryFile = filenames[0].split('/')[-1]
        print("cnfLogDir = ", cnfLogDir)
        print("\n File Names = ", masterSummaryFile)
        fileLink = [masterSummaryFile]

        # Uploading CSV Files #
        csvFiles = cnfLogDir.get('csvPath')
        for files in csvFiles:
            self.upload_docs(url, files, contentid, uname, token)
            detailSummaryFile = files.split('/')[-1]
            fileLink.append(detailSummaryFile)

        # header for senfing datas
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        # variable for creating html content
        html_data_content = " "
        table_prefix = "<tr><td>"
        table_Suffix = "</td><td>"
        table_end = "</td></tr>"

        for row, column in table_data.items():
            if str(column).strip().lower() != 'nan':
                html_data_content = html_data_content + table_prefix + str(row) + str(table_Suffix) + str(
                    column) + table_end

        """ Table Structure
        "<table><tbody>

        <tr>
             <td>Normal Cell 1</td>
             <td>Normal Cell 2</td>
        </tr>
        <tr>
             <td>Normal Cell 1</td>
             <td>Normal Cell 2</td>
        </tr>
        <tr>
            <td>Normal Cell 1</td>
            <td>Normal Cell 2</td>
        </tr>
        </tbody></table> ",

        """
        data_upload = "<table style='margin: 0px auto'><tbody>{}</tbody></table>".format(html_data_content)
        # adding last dataframe html content
        for test_index in last_dataframe_index:
            test_dataframe = df.iloc[test_index[0]:test_index[1]][:]
            topic_data = test_dataframe.iloc[0][1]
            updated_dataframe = test_dataframe.iloc[:][:]
            updated_dataframe = updated_dataframe.drop([0], axis=1)
            new_dataframe = ' '
            # adding heading
            heading_data = "<tr><th><strong>{}</strong></th><th></th><th></th></tr>".format(topic_data)
            for index, data in updated_dataframe.iterrows():
                new_dataframe = new_dataframe + '<tr>'
                for col, val in data.items():

                    if str(val).lower().strip() in ['android',
                                                    'ios', 'total', 'pass', 'fail']:
                        val = "<strong>{}</strong>".format(val)

                    if str(val).lower().strip() == 'nan':
                        new_dataframe = new_dataframe + '<td style="height:25px;width:170px">' + ' ' + '</td>'
                    else:
                        new_dataframe = new_dataframe + '<td  style="height:25px;width:170px">' + str(val) + '</td>'
                new_dataframe = new_dataframe + '</tr>'

            data_upload = data_upload + "<table style='margin: 0px auto'><tbody>{}{}</tbody></table>".format(
                heading_data, new_dataframe)

        # Upload the data on the confluence page
        file_pre = "<h3> LOGS </h3><p></p>"
        file_curr = " "

        for data in fileLink:
            file_curr = file_curr + '<p><ac:link> <ri:attachment ri:filename="{}"/> </ac:link></p>'.format(data)
        file_html = file_pre + file_curr

        data_upload = data_upload + file_html
        #########################################

        payload = json.dumps({
            "version": {
                "number": 41
            },
            "title": pagetitle,
            "type": "page",
            "status": "current",
            "ancestors": [
                {
                    "id": pageID
                }
            ],
            "body": {
                "storage": {
                    "value": data_upload,
                    "representation": "storage"
                }
            }
        })

        response = requests.request(
            "PUT",
            url,
            data=payload,
            headers=headers,
            auth=auth1
        )

        print(response.status_code)
        if response.status_code == 200:
            print("Content Updated.")
        elif response.status_code == 409:
            print("Error: Version need to be updated before uploading")
            new_version = self.get_content_version(url, pagetitle, auth1)
            print("Current Version:-   {}".format(new_version))
            expected_version = int(new_version) + 1

            # request http for one more time

            payload = json.dumps({
                "version": {
                    "number": expected_version
                },
                "title": pagetitle,
                "type": "page",
                "status": "current",
                "ancestors": [
                    {
                        "id": pageID
                    }
                ],
                "body": {
                    "storage": {
                        "value": data_upload,
                        "representation": "storage"
                    }
                }
            })

            updated_response = requests.request("PUT", url, data=payload, headers=headers, auth=auth1)
            self.check_status_code(updated_response)

    def get_data_from_excel(self, filename):
        df = pd.read_excel(filename, header=None)
        dict1 = OrderedDict()
        TESTCASE = ["Onboarding", "Sanity", "Regression"]
        test_suites = {}
        # Get the row number
        for tests in TESTCASE:
            new_data = df[df[1] == tests]
            if not new_data.empty:
                index_number = df[df[1] == tests].index[0]
                if index_number:
                    test_suites[str(tests)] = index_number

        index_values = test_suites.values()
        index_sort_values = sorted(index_values)
        # last_index_value = index_sort_values[-1]
        rem_indexes = index_sort_values[:-1]

        min_index = min(index_values)

        for test_name, test_index in test_suites.items():
            if test_index == min_index:
                expected_test = test_name

        index_num = df[df[1] == expected_test].index[0]

        # Get the values of all the testcases

        for sorted_values in index_sort_values:
            print(sorted_values)
        total_row = (df.shape[0])

        index_sort_values.append(total_row)

        updated_df = df.iloc[1:index_num - 1][:]
        for index in updated_df.index:
            dict1[(updated_df[1][index])] = updated_df[2][index]

        data_rem = []
        if len(index_sort_values) > 1:
            for data in range(0, len(index_sort_values) - 1):
                list1 = []
                list1.append(index_sort_values[data])
                list1.append(index_sort_values[data + 1])
                data_rem.append(list1)

        return dict1, data_rem, df

    # Validating If Parent Page ID is Proper or not    
    def validate_parent_page(self, url, username, authToken, pageID):
        self.url = url + pageID
        self.username = username
        self.authToken = authToken
        headers = {"Application": "application/json"}
        response = requests.get(self.url, headers=headers, auth=(self.username, self.authToken))
        try:
            # Start - Getting Current Version and Next Version of the Page #
            data = json.loads(response.text)
            os.environ["spaceKey"] = data.get('space').get('key')
            if data.get("statusCode") != 404:
                print("Parent Page Validation Successful")
                return True
            else:
                return False
        except ValueError as err:
            return False

    def get_content_details(self, url, username, authToken, pageID):
        # Use get content by id , Returns space , history , version #
        self.url = url + pageID
        self.username = username
        self.authToken = authToken
        headers = {"Application": "application/json"}
        query = {'expand': "version"}
        response = requests.get(self.url, headers=headers, params=query, auth=(self.username, self.authToken))
        try:
            # Start - Getting Current Version and Next Version of the Page #
            data = json.loads(response.text)
            if data.get("statusCode") != 404:
                version_number = data.get("version").get("number")
                print("version_number = ", version_number)
                next_version = version_number + 1
                print("next_version = ", next_version)
                # End - Getting Current Version and Next Version of the Page #
                return True
            else:
                return False
        except ValueError as err:
            return False

    def upload_confluence_data(self, filename, content_url, pagetitle1, client_pageid, auth1, pageID, cnfLogDir):
        print("Filename = ", filename)
        table_data, last_dataframe_index, df = self.get_data_from_excel(filename)
        filename = [filename]
        self.upload_content_request(content_url, pagetitle1, client_pageid, auth1, table_data, last_dataframe_index, df,
                                    pageID, filename, cnfLogDir)

    def get_logs_info(self, epoch_time, logdir='../../logs/'):
        """
        Utility will get the file location information from the
        specified location

        :param logdir: Robot Logs directory information
        :return List of all the file location
        """
        print("Getting Execution Logs: {} and Epoch Time: {}".format(logdir, epoch_time))
        zipfilename = 'robot_logs_{}.zip'.format(epoch_time)
        list_files = os.listdir(logdir)
        print("Location:- ", list_files)

        # create a zip file with epoch name
        logs_zip = zipfile.ZipFile(os.path.join(logdir, zipfilename), 'w')

        # get the epoch folder logs information (epoch time)
        for files in list_files:
            if str(files) == epoch_time:
                print('Searching in epoch directory')
                files = os.path.join(logdir, files)
                print('files location: ', files)

                # Get the iteration folder(A1, A2)
                for iter_filename in os.listdir(files):
                    sub_files = os.path.join(files, iter_filename)
                    print("\n\nFilename is {}\n\n".format(sub_files))

                    # Get the sub robot logs information
                    for robot_logfile in os.listdir(sub_files):
                        print("Robot Files :  {}".format(robot_logfile))
                        logs_location = os.path.join(sub_files, robot_logfile)
                        logs_zip.write(logs_location, compress_type=zipfile.ZIP_DEFLATED)
        logs_zip.close()

    def create_page(self, page_title, url, username, authToken, pageID):
        """
        Utility to create page

        :param page_title: Title of the page
        :param url: COnfluence URL
        :param username: Confluence username
        :param authToken:  Token of the user
        :return status_code: Status code of the API
        """
        print("calling create page")
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        spaceKey = os.environ["spaceKey"]
        payload = json.dumps({
            "title": page_title,
            "type": "page",
            "space": {
                "key": spaceKey
            },
            "status": "current",
            "ancestors": [
                {
                    "id": pageID
                }
            ],
            "body": {
                "storage": {
                    "value": "Storage View",
                    "representation": "storage"
                },
            }
        })

        response = requests.request(
            "POST",
            url,
            data=payload,
            headers=headers,
            auth=(username, authToken)
        )

        print(response.status_code)
        print(response.text)

        self.check_status_code(response, pass_message='Page Created successfully',
                               fail_message='Unexpected error occured')

        return response.status_code, response.text


if __name__ == '__main__':
    confluence_api = prepare_confluence_data()
