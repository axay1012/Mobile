#!/usr/bin/env python

###############################################################
# Library To Email the results or reports to one or more users
###############################################################
import os
import smtplib
import ssl

from common import common
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from emailfunctions import emailfunctions


class sendemail:

    def __init__(self):
        self.commonobj = common()
        self.emailfunobj = emailfunctions()
        self.fromAddr = 'volanium@gmail.com'
        self.password = 'fkfwzbndgxgubjhk'
        self.port = 465
        self.smtpServer = "smtp.gmail.com"

    def configEmailandSend(self, subject, masterSummaryFilePath, detailSummaryFileNames, toAddr, ccAddr):
        """
        Method to Config the Email and Send a email with
        Master Summary and all the detail summary report.
        :param subject:
        :param masterSummaryFilePath:
        :param detailSummaryFileNames:
        :param toAddr:
        :param ccAddr:
        :return:
        """
        # Section to Get All the data from Excel to List
        try:
            excelData_list = self.emailfunobj.excelToListHTMLTableStr(masterSummaryFilePath)
        except Exception as err:
            print("Failed to Get the Data From Excel to List", err)
            return False

        # Section to Create the HTML Table String
        try:
            HTMLStrValues = self.emailfunobj.listToHTMLTableStr(excelData_list)
        except Exception as err:
            print("Failed to Convert From List to HTML STRING With Table Tags ", err)
            return False

        # Section To Create the Email Configuration
        try:

            text = """            
            """ + HTMLStrValues + """
            """
            html = """
            <html><body>
            """ + HTMLStrValues
            if os.environ.get("testrail"):
                if not os.environ["testrail"] == 'False':
                    html = html + """
                <p class="small"><b><font color='Blue'><p>
                    <table border = “1” cellspacing=“1" “>
                        <tr>
                            <td align=“center”;  width=“40%“>Testrail Link</td>
                                <td align=“center”;  width=“70%“>{}</td>
                                    </tr>
                    </table>""".format(os.environ["testrail"])

            # adding confluence page url
            if os.environ.get("confluence"):
                if not os.environ["confluence"] == 'False':
                    html = html + """
                <p class="small"><b><font color='Blue'><p>
                    <table border = “1” cellspacing=“1" “>
                        <tr>
                            <td align=“center”;  width=“40%“> Confluence </td>
                                <td align=“center”;  width=“70%“>{}</td>
                                    </tr>
                    </table>""".format(os.environ["confluence"])

            html = html + """<p class="small"><b><font color='Blue'><b></b>Onboarding formula is: # of Onboarding Pass Attempts / # of Onboarding Attempts * 100 </font></b><br>
            <b><font> Example : 12 / 15 * 100  is Equal to 80 % </font></b><br>
            <b><font color='Blue'>Sanity : Final Result will be FAIL if any one Attempt is Fail </font></b></p>
            <p><b><font>Note: Detail Results are specified in CSV Files</font></b></p>
            </body></html>
            """

            message = MIMEMultipart("alternative", None, [MIMEText(text), MIMEText(html, 'html')])
            message["From"] = self.fromAddr
            message["Subject"] = str(subject)
            temp = ""
            cc_temp = ""

            for receiver in toAddr:
                temp = temp + str(receiver) + ","
            for receiver in ccAddr:
                cc_temp = cc_temp + str(receiver) + ","
            message["To"] = str(temp)
            message["Cc"] = str(cc_temp)
            # Reading the Files to get list of file to be attached
            reportFileLists = self.emailfunobj.getAttachments(detailSummaryFileNames)
            # print(reportFileLists)
            for filename in reportFileLists:
                rFileName = str(filename).rstrip("\n")
                if self.commonobj.fileExists(rFileName):
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(open(rFileName, "rb").read())
                    encoders.encode_base64(part)
                    part.add_header("Content-Disposition", 'attachment; filename="%s"' % os.path.basename(rFileName))
                    message.attach(part)
                else:
                    print("File to Attach Not Found in a Specified Path")
                    print("Email Send is Aborted ")

            # Attachment of Excel to for email
            if self.commonobj.fileExists(masterSummaryFilePath):
                part = MIMEBase("application", "octet-stream")
                part.set_payload(open(masterSummaryFilePath, "rb").read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition",
                                'attachment; filename="%s"' % os.path.basename(masterSummaryFilePath))
                message.attach(part)
            else:
                print("Master Summary Report Missing : ", masterSummaryFilePath)
                return False
            text = message
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(self.smtpServer, self.port, context=context) as server:
                server.login(self.fromAddr, self.password)
                server.send_message(from_addr=self.fromAddr, msg=text)
                server.quit()
        except Exception as err:
            print("Failed to Email ", err)
            return False

        return True

    def modifyEmailSubject(self):
        """
        Modify subject email subject line dynamically
        """
        try:

            if "Onboarding" in os.environ['testSuite']:
                suiteType = "Onboarding"
            elif "Sanity" in os.environ['testSuite']:
                suiteType = "Sanity"
            else:
                suiteType = os.environ['testSuite']

            subjectFileNamePath = os.environ['CurrentPath'] + "/mail/subject.txt"

            # Write new app version to .report.txt file
            with open(subjectFileNamePath, 'r') as file:
                # read a list of lines into data
                data = file.readlines()
            # Update line 2 with new version number
            data[0] = "Volanium Automation Report for " + os.environ['AppName'] + "\n"
            data[1] = suiteType + "\n"
            data[2] = "" + "\n"

            # Write changes back to the file
            with open(subjectFileNamePath, 'w') as file:
                file.writelines(data)

            return True
        except Exception as err:
            print("Error: Failed to the iOS App Version", err)
            return False


if __name__ == '__main__':
    obj = sendemail()
