#!/usr/bin/env python

###########################################################################
# - Test Driver Script perform following Operations:
#   1. Input data validation
#   2. Test component validation(E.g. Android, iOS, Web, Cloud)
#   3. Initialize test device handler
#   4. Set test execution Prerequisite
#   5. Trigger the execution of test suite
############################################################################

import sys
import os
import getopt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             'src/')))

import common
import usage
import sendemail
import emailfunctions
import finalsummaryreport
import testrail
import confluence_upload
import dynamoDB

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                             'mobile/src/lib')))

import adbcommands

from handler import AndroidHandler, IosHandler, CloudHandler, EmbeddedHandler, WebHandler

# Global Variables
testSuiteToExec = None
testIncludeTag = ""
testExcludeTag = ""
testComponentLst = []
testConfigFile = None

# Macros
ANDROID = 'android'
IOS = 'ios'
CLOUD = 'cloud'
WEB = 'web'
EMBEDDED = 'embedded'

reportFileLists = []
supportedComponentList = ['ANDROID', 'IOS', 'CLOUD', 'WEB', 'EMBEDDED']

class TestDriver:

    def __init__(self):
        self.objCommon = common.common()
        self.objUsage = usage.usage()
        self.objAndroidHndlr = AndroidHandler.AndroidHandler()
        self.objiOSHndlr = IosHandler.IosHandler()
        self.objCloudHndlr = CloudHandler.CloudHandler()
        self.objEmbeddedHndlr = EmbeddedHandler.EmbeddedHandler()
        self.objWebHndlr = WebHandler.WebHandler()
        self.objadbCMD = adbcommands.adbcommands()
        self.objSendMail = sendemail.sendemail()
        self.objMailFunc = emailfunctions.emailfunctions()
        self.objMasterSummary = finalsummaryreport.finalsummaryreport()
        self.TestRailStatus = False
        self.confluenceStatus = False
        self.grafanaStatus = False
        self.masterSummaryReportFilePath = ""
        self.confluence_upload = confluence_upload.prepare_confluence_data()
        self.dynamoDB_upload = dynamoDB.DynamoDB()

    def _validateTestSuiteFile(self, testSuiteLst):
        """
        Validate test suite file is available at given path
        """
        suiteList = testSuiteLst.split()
        for suite in suiteList:
            if not self.objCommon.fileExists("{0}".format(suite)):
                print("""
                      -----------------------------------------------------
                      Test Suite Script: %s is not available.
                      Please provide proper location of the Test Suite.
                      -----------------------------------------------------
                      """ % suite)
                sys.exit(1)

    def cmdLineParser(self, argv):
        """
        command line parsing and validation
        """
        global testSuiteToExec
        global testIncludeTag
        global testExcludeTag
        global testComponentLst
        global testrailUpdate
        global testConfigFile
        global confluenceUpdate
        global grafanaUpdate

        try:
            opts, args = getopt.getopt(argv, 'h:c:s:f:i:e:r:n:g:',
                                       ['component=', 'suite=', 'configfile=', 'includetag=', 'excludetag=',
                                        'testrail=', 'confluence=', 'grafana='])
        except getopt.GetoptError:
            self.objUsage.displayUsage()

        for opt, arg in opts:
            if opt in ('-h', '--help'):
                self.objUsage.displayUsage()
            elif opt in ('-c', '--component'):
                testComponentLst = str(arg).split()
                testComponentLst = [elem.lower() for elem in testComponentLst]
            elif opt in ('-i', '--includetag'):
                testIncludeTag = str(arg)
            elif opt in ('-e', '--excludetag'):
                testExcludeTag = str(arg)
            elif opt in ('-s', '--suite'):
                testSuiteToExec = str(arg)
                os.environ["testSuite"] = testSuiteToExec
            elif opt in ('-r', '--testrail'):
                testrailUpdate = str(arg)
                self.TestRailStatus = testrailUpdate
            elif opt in ('-n', '--confluence'):
                confluenceUpdate = str(arg)
                self.confluenceStatus = confluenceUpdate
            elif opt in ('-g', '--grafana'):
                grafanaUpdate = str(arg)
                self.grafanaStatus = grafanaUpdate
            elif opt in ('-f', '--configfile'):
                testConfigFile = str(arg)
                print("Config File:", testConfigFile)
            else:
                self.objUsage.displayUsage()

        if not (testSuiteToExec and testComponentLst):
            print("""
                  ---------------------------------------------------------
                  Test suite name and component is mandatory for execution.
                  ---------------------------------------------------------
                  """)
            self.objUsage.displayUsage()

        if testSuiteToExec:
            self._validateTestSuiteFile(testSuiteToExec)

        if testConfigFile is None:
            # Config File Path
            CurrentPath = os.path.abspath(os.path.join(os.path.dirname(__file__)))
            fileName = CurrentPath + "/config/config.xml"
        else:
            fileName = testConfigFile

        os.environ['fileName'] = fileName

    def _validateTestComponent(self):
        """
        Validate input test components
        """
        try:
            for testModule in testComponentLst:
                if testModule.upper() not in supportedComponentList:
                    print("""
                          -------------------------------------------
                          You have selected invalid test component.
                          -------------------------------------------
                          """)
                    self.objUsage.displayUsage()
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)

    def _initTestHandler(self):
        """
        Initialize test component's handler
        """
        try:
            if ((ANDROID in testComponentLst)
                    and (IOS in testComponentLst)):
                print("""
                       ------------------------------------------- 
                       Framework does not support execute of Android and iOS 
                       component simultaneously
                       -------------------------------------------""")
                self.objUsage.displayUsage()
        except Exception as err:
            print("ERROR: Initialize Of Test Handler Failed ", err)
            sys.exit(1)

    def _triggerTestExecution(self):
        """
        Trigger test suite execution
        """
        # # Config File Path
        CurrentPath = os.path.abspath(os.path.join(os.path.dirname(__file__)))
        os.environ['CurrentPath'] = CurrentPath

        # Check for reportfilelistforemailattachment exist and removing the file
        self.objCommon.deleteFile(os.environ['CurrentPath'] + "/.reportfilelistforemailattachment.txt")

        # Check for dynamoDBfilelist exist and removing the file
        self.objCommon.deleteFile(os.environ['CurrentPath'] + "/.dynamoDBfilelist.txt")

        try:
            if ANDROID in testComponentLst:
                if not self.objAndroidHndlr.triggerAndroidTestExecution(os.environ['fileName'], testSuiteToExec,
                                                                        testIncludeTag, testExcludeTag):
                    print("\n\nFailed to trigger test execution over Android device\n\n")
                    sys.exit(1)
            if IOS in testComponentLst:
                if not self.objiOSHndlr.triggeriOSTestExecution(os.environ['fileName'], testSuiteToExec, testIncludeTag,
                                                                testExcludeTag):
                    print("\n\nFailed to trigger test execution over iOS device\n\n")
                    sys.exit(1)
            if EMBEDDED in testComponentLst:
                if not self.objEmbeddedHndlr.triggerEmbeddedTestExecution(os.environ['fileName'], testSuiteToExec,
                                                                          testIncludeTag, testExcludeTag):
                    print("\n\nFailed to trigger test execution on Embedded Device\n\n")
                    sys.exit(1)
            if WEB in testComponentLst:
                if not self.objWebHndlr.triggerWebTestExecution(os.environ['fileName'], testSuiteToExec, testIncludeTag,
                                                                testExcludeTag):
                    print("\n\nFailed to trigger test execution on Web\n\n")
                    sys.exit(1)
            if CLOUD in testComponentLst:
                if not self.objCloudHndlr.triggerCloudTestExecution(testSuiteToExec, testIncludeTag, testExcludeTag):
                    print("\n\nFailed to trigger test execution on Cloud\n\n")
                    sys.exit(1)
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)

    def _createMasterSummary(self):
        global reportFileLists
        try:
            # Getting List of Detail CSV file for Master Summary Report
            # Reading the Files to get list of file to be attached
            reportFileLists = self.objMailFunc.getAttachments(os.environ['CurrentPath'] +
                                                              "/.reportfilelistforemailattachment.txt")
            self.masterSummaryReportFilePath = self.objMasterSummary.createMasterSummaryReport(reportFileLists)
        except Exception as err:
            print("ERROR: Create of Master Summary Failed ", err)
            sys.exit(1)

    def _TestRailUpdate(self):
        """
        Update execution results to TestRail
        """
        if self.TestRailStatus:
            getTestrailDetails, error_message = self.objCommon.getTestrailDetails(os.environ['fileName'])
            if not getTestrailDetails:
                print("\n\nFailed to Update Test Rail:- {} \n\n".format(error_message))
            try:
                with open(os.environ['CurrentPath'] + "/.testrailfilelist.txt") as f:
                    filenames = f.read().splitlines()

                testrail_status, test_link = testrail.testrail_update_result(filenames,
                                                                             getTestrailDetails['trUserName'],
                                                                             getTestrailDetails['trPassWord'],
                                                                             getTestrailDetails['testrailUrl'],
                                                                             getTestrailDetails['testProjectId'],
                                                                             getTestrailDetails['trRunName'])
                if test_link == "Error While Uploading data to TestRail":
                    os.environ["testrail"] = ""
                else:
                    os.environ["testrail"] = test_link
            except Exception as error_message:
                print("\n\nFailed to Update Test Rail:- {} \n\n".format(error_message))
        else:
            print("TestRail Not Configured")

    def _confluenceUpdate(self):
        """
        Method For Confluence Update
        """
        if self.confluenceStatus:
            getConfluenceValues, error_message = self.objCommon.getConfluenceDetails(os.environ['fileName'])
            if not getConfluenceValues:
                print("\n\nFailed to Update On Confluence:- {} \n\n".format(error_message))
            print("Provided Confluence Parameters are = ", getConfluenceValues)
            cnfUrl, cnfUsername = getConfluenceValues.get("confluenceUrl"), getConfluenceValues.get("username")
            cnfAuthToken, pageID, pageTitle = getConfluenceValues.get("authToken"), getConfluenceValues.get(
                "parentPageId"), getConfluenceValues.get("pageTitle")
            authentication_check = self.confluence_upload.authenticate_user(cnfUrl, cnfUsername, cnfAuthToken)
            validate_parent_page_id = self.confluence_upload.validate_parent_page(cnfUrl, cnfUsername, cnfAuthToken,
                                                                                  pageID)
            print('cnfUrl , cnfUsername = ', cnfUrl, cnfUsername)
            if authentication_check:
                if validate_parent_page_id:
                    get_content_details = self.confluence_upload.get_content_details(cnfUrl, cnfUsername, cnfAuthToken,
                                                                                     pageID)
                else:
                    return False
                auth1 = (cnfUsername, cnfAuthToken)
                # Condition for page creation
                print(pageTitle, cnfUrl, cnfUsername, cnfAuthToken)
                create_page_status_code, create_page_response = self.confluence_upload.create_page(pageTitle, cnfUrl,
                                                                                                   cnfUsername,
                                                                                                   cnfAuthToken, pageID)
                print("Page Created : ", create_page_response)
                if create_page_status_code == 200:
                    print("Page is already created")
                    client_pageid = self.confluence_upload.get_content_pageid(create_page_response, url=None,
                                                                              pagetitle=None, new=True, auth1=auth1)
                elif create_page_status_code == 400:
                    print("Page Title already Exists")
                    client_pageid = self.confluence_upload.get_content_pageid(create_page_response, cnfUrl, pageTitle,
                                                                              False, auth1)
                else:
                    print("ERROR: Received Unexpected status code")
                    return False

                # Update for page id and log filename
                content_url = '{}{}'.format(cnfUrl, client_pageid)
                filename = os.environ["MasterSummaryReport"]
                logDir = None
                csvDir = reportFileLists
                cnfLogDir = {'logPath': logDir, 'csvPath': csvDir}
                self.confluence_upload.upload_confluence_data(filename, content_url, pageTitle, client_pageid, auth1,
                                                              pageID, cnfLogDir)

                # Adding the Confluence URL in the report email template
                confUrl = self.confluence_upload.get_confUrl(content_url, pageTitle, auth1)
                print("Confluence Url:- {}".format(confUrl))
                os.environ["confluence"] = confUrl

            else:
                if not validate_parent_page_id:
                    print("ERROR : Please Provide Valid Credentials and Parent Page ID")
                    return False
                else:
                    print("ERROR : Please Provide Valid Credentials")
                    return False
        else:
            print("Confluence Not Configured")

    def _grafanaUpdate(self):
        """
        Update execution results to Grafana dashboard
        """
        if self.grafanaStatus:
            getDynamoDBDetails, error_message = self.objCommon.getDynamoDBDetails(os.environ['fileName'])
            if not getDynamoDBDetails:
                print("\n\nFailed to get DynamoDB Parameters:- {} \n\n".format(error_message))
                return False
            print("Provided DynamoDB Parameters are = ", getDynamoDBDetails)
            dBRegion, dbTable = getDynamoDBDetails.get("region"), getDynamoDBDetails.get("table")
            with open(os.environ['CurrentPath'] + "/.dynamoDBfilelist.txt") as f:
                jsonFiles = f.read().splitlines()
            self.dynamoDB_upload.load_table(jsonFiles, dBRegion, dbTable)
        else:
            print("Grafana Not Configured")

    def _sendmail(self):
        """
        Sends execution report summary via Email to configured email address with configured email subject
        """

        # Need to call the method get the subject and master Summary File Path and Detail Summary FileName File Path
        try:
            masterSummaryFilePath = os.environ['MasterSummaryReport']
            detailSummaryFileNames = os.environ['CurrentPath'] + "/.reportfilelistforemailattachment.txt"
        except KeyError:
            masterSummaryFilePath = "No Report"
            detailSummaryFileNames = "No Detail"
        print(detailSummaryFileNames)
        print(masterSummaryFilePath)

        try:
            if masterSummaryFilePath == "No Report" or detailSummaryFileNames == "No Detail":
                print("Master Summary Report Excel File or Detail Summary CSV "
                      "File is Missing for Attachment")
                print("Aborting send email of module ")
                return False

            # Get the Subject
            subjectFileNamePath = os.environ['CurrentPath'] + "/mail/subject.txt"
            mailsubject = self.objMailFunc.getSubjectLine(subjectFileNamePath)

            # Get the To Address
            toAddressFileNamePath = os.environ['CurrentPath'] + "/mail/emailtoaddress.txt"
            to_list, cc_list = self.objMailFunc.getToAddress(toAddressFileNamePath)

            # Calling Send Email Method to email the Test Report
            self.objSendMail.configEmailandSend(mailsubject, masterSummaryFilePath, detailSummaryFileNames, to_list,
                                                cc_list)
            return True
        except Exception as err:
            print("Failed to Call Send Email Module ", err)
            return False


# Driver entry point
if __name__ == '__main__':

    objDriver = TestDriver()
    if len(sys.argv) < 5:
        objDriver.objUsage.displayUsage()
    else:
        objDriver.cmdLineParser(sys.argv[1:])

    # Init test component handler
    objDriver._initTestHandler()

    # Validate input test components
    objDriver._validateTestComponent()

    # Trigger test suite execution
    objDriver._triggerTestExecution()

    # Trigger Master Summary Report
    objDriver._createMasterSummary()

    # Trigger TestRail Report
    objDriver._TestRailUpdate()

    # Trigger Confluence
    objDriver._confluenceUpdate()

    # Trigger Grafana
    objDriver._grafanaUpdate()

    # Send Email
    objDriver._sendmail()
