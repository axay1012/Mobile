package org.qaFactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class DriverFactory {
	public WebDriver driver;

	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<WebDriver>();

	/**
	 * This method is used to initialize the thradlocal driver on the basis of given browser
	 * @param browser
	 * @return this will return tldriver.
	 */
	public WebDriver init_driver(String browser) {
		System.out.println("browser value is: " + browser);
		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path: "+projectPath);
		
	   
		if (browser.equals("chrome")) {
			//WebDriverManager.chromedriver().setup();
		   
			System.setProperty("webdriver.chrome.driver", 
			"/Users/siddharthrathod/Documents/Volanium/test_cucumber/Drivers/chromedriver");
			ChromeOptions option = new ChromeOptions();
	         option.addArguments("--remote-allow-origins=*");
			tlDriver.set(new ChromeDriver(option));
	
		//	tlDriver.set(WebDriverManager.chromedriver().setup());
		
			// System.out.println("Please pass the correct browser value: " + browser);
		}
		getDriver().manage().deleteAllCookies();
//		driver.manage().addCookie(cookie);
		getDriver().manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		return getDriver();
	}
	public static synchronized WebDriver getDriver() {
	
		return tlDriver.get();
	}
}
