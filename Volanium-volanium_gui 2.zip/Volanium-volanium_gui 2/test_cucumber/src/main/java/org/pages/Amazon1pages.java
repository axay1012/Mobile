package org.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Amazon1pages {
	private WebDriver driver;
	@FindBy(id="twotabsearchtextbox")
	private WebElement searchfld;
	
	@FindBy(xpath = "//*[@id='nav-search-submit-button']")
	private WebElement submitbtn;

	@FindBy(xpath = "(//*[@class='a-icon a-icon-checkbox'])[3]")
	WebElement ftrOnBrand;
	
	@FindBy(xpath = "//span[@class='a-color-state a-text-bold']")
	WebElement resultsText;

	@FindBy(xpath = "//a[@id='nav-logo-sprites']")
	WebElement amazonLogo;
	
	public Amazon1pages(WebDriver driver)	//constructor
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	public void SearchField(String abc) {
		searchfld.sendKeys(abc);
	}
	public void SubmitButton () {
		submitbtn.click();
	}
	public void FilterOnBrand() {
		ftrOnBrand.click();
	}
	public void ResultsTextVer() {
		resultsText.isDisplayed();
	}
	public void AmazonLogoVer() {
		amazonLogo.click();
	}
}
