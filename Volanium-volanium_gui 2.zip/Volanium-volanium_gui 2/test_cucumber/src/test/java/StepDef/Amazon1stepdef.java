package StepDef;

import org.pages.Amazon1pages;
import org.qaFactory.DriverFactory;

import Hooks.AppHooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Amazon1stepdef {
	Amazon1pages amz = new Amazon1pages(DriverFactory.getDriver());
	
	@Given("user is on amazon login page")
	public void user_is_on_amazon_login_page() {
	 DriverFactory.getDriver().get(AppHooks.prop.getProperty("url"));
	}

	@And("user enter value {string} in search field")
	public void user_enter_value_in_search_field(String String) {
		amz.SearchField(String);
		amz.SubmitButton();
	}

	@And("user apply filter")
	public void user_apply_filter() {
	amz.FilterOnBrand();
	}

	@And("user get promted on result screen")
	public void user_get_promted_on_result_screen() {
		amz.ResultsTextVer();
	}

	@And("user clicks on amazon logo")
	public void user_clicks_on_amazon_logo() {
		amz.AmazonLogoVer();
	}

	@And("validate home screen")
	public void validate_home_screen() {
		DriverFactory.getDriver().get(AppHooks.prop.getProperty("url"));
	}

	@Then("close the current browser")
	public void close_the_currunt_browser() {
	 DriverFactory.getDriver().close();
	}
}
