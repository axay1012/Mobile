import xml.etree.ElementTree as ET

def create_configuration_xml(environment, release_branch, wifi_name, wifi_password, test_iteration,
                            testrail_url, testrail_username, testrail_password, testrail_project_id,
                            confluence_url, confluence_username, confluence_auth_token, confluence_parent_page_id, confluence_page_title,
                            dut_details, web_url, web_app_version, web_browser, web_email_id, web_email_password,
                            mobile_email_id, mobile_email_password, mobile_platform, mobile_android_app_version, mobile_apk_path, mobile_app_package, mobile_app_activity, mobile_ios_app_version, mobile_ipa_path, mobile_xcode_org_id):
    root = ET.Element("Configuration")
    setup_configuration = ET.SubElement(root, "SetupConfiguration")
    common = ET.SubElement(setup_configuration, "Common")

    ET.SubElement(common, "Environment").text = environment
    ET.SubElement(common, "ReleaseBranch").text = release_branch
    ET.SubElement(common, "WifiName").text = wifi_name
    ET.SubElement(common, "WifiPassword").text = wifi_password
    ET.SubElement(common, "TestIteration").text = test_iteration

    testrail = ET.SubElement(setup_configuration, "TestRail")

    ET.SubElement(testrail, "Url").text = testrail_url
    ET.SubElement(testrail, "userName").text = testrail_username
    ET.SubElement(testrail, "passWord").text = testrail_password
    ET.SubElement(testrail, "testProjectId").text = testrail_project_id

    confluence = ET.SubElement(setup_configuration, "Confluence")

    ET.SubElement(confluence, "Url").text = confluence_url
    ET.SubElement(confluence, "userName").text = confluence_username
    ET.SubElement(confluence, "authToken").text = confluence_auth_token
    ET.SubElement(confluence, "parentPageId").text = confluence_parent_page_id
    ET.SubElement(confluence, "pageTitle").text = confluence_page_title

    dut_details = ET.SubElement(setup_configuration, "DUTDetails")
    for device in dut_details:
        device_element = ET.SubElement(dut_details, device)
        ET.SubElement(device_element, "Name").text = dut_details[device]['Name']
        ET.SubElement(device_element, "ID").text = dut_details[device]['ID']
        ET.SubElement(device_element, "FirmwareVersion").text = dut_details[device]['FirmwareVersion']
        ET.SubElement(device_element, "SerialNumber").text = dut_details[device]['SerialNumber']
        ET.SubElement(device_element, "RelayName").text = dut_details[device]['RelayName']
        ET.SubElement(device_element, "RelayNumber").text = dut_details[device]['RelayNumber']

    web_configuration = ET.SubElement(setup_configuration, "WebConfiguration")

    ET.SubElement(web_configuration, "WebUrl").text = web_url
    ET.SubElement(web_configuration, "WebAppVersion").text = web_app_version
    ET.SubElement(web_configuration, "Browser").text = web_browser
    ET.SubElement(web_configuration, "EmailId").text = web_email_id
    ET.SubElement(web_configuration, "EmailPassword").text = web_email_password

    mobile_configuration = ET.SubElement(setup_configuration, "MobileConfiguration")

    ET.SubElement(mobile_configuration, "EmailId").text = mobile_email_id
    ET.SubElement(mobile_configuration, "EmailPassword").text = mobile_email_password
    ET.SubElement(mobile_configuration, "Platform").text = mobile_platform

    android = ET.SubElement(mobile_configuration, "Android")
    ET.SubElement(android, "AppVersion").text = mobile_android_app_version
    ET.SubElement(android, "ApkPath").text = mobile_apk_path
    ET.SubElement(android, "AppPackage").text = mobile_app_package
    ET.SubElement(android, "AppActivity").text = mobile_app_activity

    ios = ET.SubElement(mobile_configuration, "iOS")
    ET.SubElement(ios, "AppVersion").text = mobile_ios_app_version
    ET.SubElement(ios, "IpaPath").text = mobile_ipa_path
    ET.SubElement(ios, "XcodeOrgId").text = mobile_xcode_org_id
    tree = ET.ElementTree(root)
    tree.write("config.xml", encoding='utf-8', xml_declaration=True)

