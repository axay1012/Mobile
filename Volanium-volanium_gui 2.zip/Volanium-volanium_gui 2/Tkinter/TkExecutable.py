import tkinter  as tk
from tkinter import PhotoImage
from PIL import Image, ImageTk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import os


class Executable():

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Test Automation Execution")
        self.root.configure(bg="white")
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.root.maxsize(width=self.screen_width, height=self.screen_height)
        self.root.minsize(width=self.screen_width, height=self.screen_height)


    def set_logo_and_background(self):
        background_Image = Image.open(""r"Tkinter/Src/Pics.png")
        background_Image = background_Image.resize((self.screen_width, self.screen_height))
        self.background_photo = ImageTk.PhotoImage(background_Image)
        background_label = tk.Label(self.root, image=self.background_photo)
        background_label.place(relwidth=1, relheight=1)
        self.background_photo.background_Image = self.background_photo

    def get_clicked(self):
        if self.CkButton.get():
            Wifi_SSID_label = ttk.Label(self.root, text="Wi-Fi Name ", font=("Google Sans", 16))
            Wifi_SSID_label.grid(row=8, padx=40, column=0, sticky="w")
            # Wifi_SSID_label.configure(bg="white")

            Wifi_SSID_TextBox = ttk.Entry(self.root, width=15,
                                          font=("Google Sans", 14), bootstyle="dark")
            Wifi_SSID_TextBox.grid(row=8, column=0, padx=170, pady=10, sticky="w", )

            Wifi_Password_label = ttk.Label(self.root, text="Wi-Fi Password ", font=("Google Sans", 16))
            Wifi_Password_label.grid(row=9, padx=40, column=0, sticky="w")

            Wifi_Password_TextBox = ttk.Entry(self.root, width=15,
                                              font=("Google Sans", 14), bootstyle="dark", show="*")
            Wifi_Password_TextBox.grid(row=9, column=0, padx=170, pady=10, sticky="w", )

        else:
            self.CkButton.set(1)

    def common_widgets_setup(self):
        # Environment Selection Combobox

        Environment_label = tk.Label(self.root)
        Environment_label.grid(row=0, column=0, padx=50, pady=40, sticky="w")
        Environment_label.configure(bg="white")

        Environment_label = tk.Label(self.root, text="Environment ", font=("Google Sans", 16))
        Environment_label.grid(row=4, column=0, padx=40, pady=10, sticky="w")
        Environment_label.configure(bg="white")

        Environment_dropdown_values = ["Test", "Staging", "Production"]
        Environment_dropdown = ttk.Combobox(self.root, width=10, values=Environment_dropdown_values,
                                            font=("Google Sans", 14), bootstyle="dark")
        Environment_dropdown.grid(row=4, column=0, padx=170, pady=10, sticky="w", )

        default_value = "Test"
        Environment_dropdown.set(default_value)

        # Release Branch Selection Combobox

        Releasebranch_label = tk.Label(self.root, text="Release Branch ", font=("Google Sans", 16))
        Releasebranch_label.grid(row=5, padx=40, column=0, sticky="w")
        Releasebranch_label.configure(bg="white")

        Releasebranch_dropdown_values = ["Master", "Development"]
        Releasebranch_dropdown = ttk.Combobox(self.root, width=10, values=Releasebranch_dropdown_values,
                                              font=("Google Sans", 14),
                                              bootstyle="dark")
        Releasebranch_dropdown.grid(row=5, column=0, padx=170, pady=10, sticky="w", )

        default_value = "Master"
        Releasebranch_dropdown.set(default_value)

        # Test Iteration  Selection Spinbox

        TestIteration_label = tk.Label(self.root, text="Test iteration ", font=("Google Sans", 16))
        TestIteration_label.grid(row=6, padx=40, column=0, sticky="w")
        TestIteration_label.configure(bg="white")

        Test_Iteration = ttk.Spinbox(self.root, from_=1, to=5, width=9, font=("Google Sans", 14), bootstyle="dark")
        Test_Iteration.grid(row=6, column=0, padx=170, pady=10, sticky="w", )

        default_value = "1"
        Test_Iteration.set(default_value)

        # Checkbutton Widget for WiFi Credential

        Checkbutton_label = tk.Label(self.root, text="WiFi Details ", font=("Google Sans", 16))
        Checkbutton_label.grid(row=7, padx=40, column=0, sticky="w")
        Checkbutton_label.configure(bg="white")

        self.CkButton = ttk.IntVar()
        Checkbutton_textbox = ttk.Checkbutton(self.root, variable=self.CkButton, width=10, bootstyle="dark",
                                              command=self.get_clicked)
        Checkbutton_textbox.grid(row=7, column=0, padx=170, pady=10, sticky="w", )


    def get_suite_file_name(self):

        suite_file_path = []
        file_name = []
        extensions = ['.py', '.feature', '.robot']
        directory = ["test_cucumber", "test_pytest", "test_robot"]
        for i in directory:
            for root, dirs, files in os.walk(i):
                for filename in files:
                    file_path = os.path.join(root, filename)
                    _, file_extension = os.path.splitext(filename)
                    if file_extension in extensions:
                        suite_file_path.append(file_path)
                        file_name.append(filename)

        return suite_file_path, file_name

    def update_text(self):
        selected_values = []
        for var, value in zip(self.variables, self.suite_values):
            if var.get():
                selected_values.append(value)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, ", ".join(selected_values))

    def Test_Suite_Selection(self):

        SuiteFiles = self.get_suite_file_name()
        self.suite_values = SuiteFiles[1]

        self.variables = [tk.BooleanVar() for _ in self.suite_values]

        menu_button = ttk.Menubutton(self.root, text="Select Test Suite", bootstyle="warning")
        menu_button.grid(column=1, row=4, padx=2, pady=10, sticky="w")

        menu = tk.Menu(menu_button, tearoff=0)

        for var, value in zip(self.variables, self.suite_values):
            menu.add_checkbutton(label=value, variable=var, onvalue=True, offvalue=False, command=self.update_text,font=("Google Sans", 14))
            menu_button.config(menu=menu)

        self.result_text = ttk.Text(self.root, height=2, width=22,font=("Google Sans", 14))
        self.result_text.grid(row=5, column=1, padx=2, pady=10)

        button = ttk.Button(self.root, text="START", bootstyle="warning")
        button.grid(row=19, padx=40, column=1, sticky="w")

         

    def execute_ui(self):
        self.root.mainloop()


if __name__ == "__main__":
    objExecutable = Executable()
    objExecutable.set_logo_and_background()
    objExecutable.common_widgets_setup()
    objExecutable.Test_Suite_Selection()
    objExecutable.execute_ui()
