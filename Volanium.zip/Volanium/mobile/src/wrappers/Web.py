#!/usr/bin/env python

############################################################################
#
# Selenium2Library is Web Application test library for Volanium it
# uses the Selenium library to control the Web App actions.
#
# This Library deliver keywords enhancement for robotframework Selenium2Library
# and its used to execute test actions on web.
#
############################################################################

from Selenium2Library import Selenium2Library


class Web(Selenium2Library):

    def __init__(self):
        Selenium2Library.__init__(self, timeout=5, run_on_failure='Nothing')
