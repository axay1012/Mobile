import pyautogui
import os
import tzlocal
from datetime import datetime, timedelta
from pytz import timezone
import time
from pathlib import Path
from zipfile import ZipFile
from pytesseract import image_to_string
from PIL import Image
import csv
import xml.etree.ElementTree as ET
from selenium import webdriver
import requests
import  pyotp


def PerformClick(filename: str):
    append_file_name = '../../testdata/PopUpImage/{}'.format(filename)
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '{}'.format(append_file_name)))
    print(path)
    location = pyautogui.locateOnScreen(path)
    print(location)
    pyautogui.click(location.left + (location.width / 2), location.top + (location.height / 2))

def Verify(filename: str):
    append_file_name = '../../testdata/PopUpImage/{}'.format(filename)
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '{}'.format(append_file_name)))
    print(path)
    location = pyautogui.locateOnScreen(path)
    print(location)
    if location == None:
        raise assertionerror

def GetTimeZone():
    localtime = tzlocal.get_localzone().zone
    return str(localtime)

def DeleteScreenshot(value):
        int_value = int(value)
        append_file_name = '../../../logs'
        print("append_file_name")
        logpath = os.path.abspath(os.path.join(os.path.dirname(__file__), '{}'.format(append_file_name)))

        deleteDate = datetime.today() - timedelta(days=int_value)
        for pics in Path(logpath).glob('**/*.png'):
            pic_loc = pics.absolute()
            modTimesinceEpoc = os.path.getmtime(pic_loc)
            modificationTimeInStr = time.strftime('%Y-%m-%d %H:%M', time.localtime(modTimesinceEpoc))
            modificationTime = datetime.strptime(modificationTimeInStr, '%Y-%m-%d %H:%M')
            if modificationTime < deleteDate:
                os.remove(pic_loc)

def convert24(str1):
    # Checking if last two elements of time
    # is AM and first two elements are 12
    if str1[-2:] == "AM" and str1[:2] == "12":
        return "00" + str1[2:-2]

    # remove the AM
    elif str1[-2:] == "AM":
        return str1[:-2]

    # Checking if last two elements of time
    # is PM and first two elements are 12
    elif str1[-2:] == "PM" and str1[:2] == "12":
        return str1[:-2]

    else:
        
        # add 12 to hours and remove PM
        return str(int(str1[:2]) + 12) + str1[2:6]

def NextFiveMultipleTime(direction='up', resolution=5):
    dt = datetime.now()
    new_minute = (dt.minute // resolution + (1 if direction == 'up' else 0)) * resolution
    r = dt + timedelta(minutes=new_minute - dt.minute)
    mins = r.strftime("%M")
    hour = r.strftime("%I")
    am_pm = r.strftime("%p")
    day_of_week = r.strftime("%a")
    if day_of_week == 'Tue':
        day_of_week = 'Tues'
    elif day_of_week == 'Thu':
        day_of_week = 'Thur'
    return [hour,mins,am_pm,day_of_week]

def ExtractZipFile(file_name: str):
    # opening the zip file in READ mode
    with ZipFile(file_name, 'r') as zip:
        zip.extractall("../../../Volanium/mobile/testdata/LogFile")

def Add_Given_Device_To_Csv_Template(csvfilename,*deviceIDs):
    '''
        Adds the given deviceIDs to a the given csv file using the Vienna's default add device using CSV Template
    '''
    csv_for_default_column_names = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../testdata/defaultAddDeviceTemplate.csv'))
    print(csv_for_default_column_names)
    fields = []
    with open(csv_for_default_column_names, 'r') as f:
        csvreader = csv.reader(f)
        fields = next(csvreader)
    with open(csvfilename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for device in deviceIDs:
            writer.writerow({'DeviceName': device, ' SerialNumber': device})

def Add_Given_Device_To_Csv_Template_With_Name(csvfilename,*deviceIDs):
    '''
        Adds the given deviceIDs to a the given csv file using the Vienna's default add device using CSV Template
    '''
    csv_for_default_column_names = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../testdata/defaultAddDeviceTemplate.csv'))
    print(csv_for_default_column_names)
    fields = []
    with open(csv_for_default_column_names, 'r') as f:
        csvreader = csv.reader(f)
        fields = next(csvreader)
    with open(csvfilename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for device in deviceIDs:
            writer.writerow({'DeviceName': device})

def edit_the_config_file_to_launch_apk(packageName:str, ver:str):
    now_playing_editable_config_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../testdata/ValidFiles/oneToOneLauncher.xml'))
    tree = ET.parse(now_playing_editable_config_file)
    root = tree.getroot()
    for element in root.iter('androidPackageName'):
        element.text = packageName
    for element in root.iter('version'):
        element.text = ver
    tree.write(now_playing_editable_config_file,xml_declaration=True,encoding='UTF-8')

def find_content_type_to_download(url:str):
    content_type = requests.head(url).headers['content-type']
    return content_type

def create_profile_for_csv_downloads():
    downloads_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../testdata/TestFiles/'))
    print(downloads_dir)
    fp = webdriver.FirefoxProfile()
    fp.set_preference("browser.download.folderList", 2)
    fp.set_preference("browser.download.manager.showWhenStarting", False)
    fp.set_preference("browser.download.dir", downloads_dir)
    fp.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/csv")
    fp.update_preferences()
    return fp.path

def GetMexicoTimeZone():
    Mexico_time = timezone('America/Mexico_City')
    mc_time = datetime.now(Mexico_time)
    mc = mc_time.strftime('%d %B %Y %H:%M')
    return (mc)

def Get_Text_From_Given_Image():
    path_to_captured_device_ss = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../testdata/TestFiles/error.png'))
    text=(image_to_string(Image.open(path_to_captured_device_ss)))
    return text

def Fetch_Text_From_Given_Image(pic_path:str):
    path_to_captured_device_ss = os.path.abspath(os.path.join(os.path.dirname(__file__), pic_path))
    text=(image_to_string(Image.open(path_to_captured_device_ss)))
    return text

def Fetch_AuthenticationCode(URL:str):
    totp = pyotp.TOTP(URL)
    return totp.now()