#!/usr/bin/env python

########################################################
#
# This Library consist of Volanium usage to trigger
# Execution for individual as well as integrated
# IOT-Echo system.
#
########################################################

import sys
from CommonVariables import *


class VolaniumUsage:

    def __init__(self):
        pass

    def displayUsage(self):
        """
        Display The Framework usage
        """
        print(VOLANIUM_USAGE)
        sys.exit(0)
