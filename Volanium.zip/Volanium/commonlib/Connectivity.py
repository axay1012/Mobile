import os
import sys
import requests
import csv
from datetime import datetime
import threading
import subprocess
import psutil

class Connectivity:

    def __init__(self):
        self.healthCheckCsvFileName = None
        self.healthCheckcsvHeader = None
        self.serverPingMonitoringCsvFileName = None
        self.serverPingMonitoringCsvHeader = None
        self.networkPingMonitoringCsvFileName = None
        self.networkPingMonitoringCsvHeader = None
        self.healthCheckTimer = 0
        self.serverPingMonitorTimer = 0
        self.networkPingMonitorTimer = 0

    def generateCSV(self):

        procList = []
        for proc in psutil.process_iter():
                if proc.name() == "robot":
                    procList.append(proc.pid)
                    procList.append(proc.parent().pid)
        [os.system("kill -9 {0}".format(i)) for i in procList]


        csvTimeStamp = str(datetime.now().strftime("%m%d%H%M%S"))
        healthCheckCSV = "HealthCheckMonitoring_"+csvTimeStamp+".csv"
        serverPingCheckCSV = "ServerPingMonitoring_"+csvTimeStamp+".csv"
        internetPingCheckCSV = "InternetPingMonitoring_"+csvTimeStamp+".csv"

        recentReportDir = 'monitoring/'
        cur_dir = os.getcwd()
        monitoringReportDir = "{}/{}".format(cur_dir, recentReportDir)
        try:
            if not os.path.exists(monitoringReportDir):
                os.makedirs(monitoringReportDir)
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)


        self.healthCheckCsvFileName = "{}/{}".format(monitoringReportDir, healthCheckCSV)
        self.healthCheckcsvHeader = ['TimeStamp', 'Status', 'Response Time(s)', 'Response(json)']

        self.serverPingMonitoringCsvFileName = "{}/{}".format(monitoringReportDir, serverPingCheckCSV)
        self.serverPingMonitoringCsvHeader = ['TimeStamp', 'Status', 'Ping Response']

        self.networkPingMonitoringCsvFileName = "{}/{}".format(monitoringReportDir, internetPingCheckCSV)
        self.networkPingMonitoringCsvHeader = ['TimeStamp', 'Status', 'Ping Response']


        with open(self.healthCheckCsvFileName, 'w') as file:
            healthCsvWritter = csv.DictWriter(file, fieldnames=self.healthCheckcsvHeader)
            healthCsvWritter.writeheader()

        with open(self.serverPingMonitoringCsvFileName, 'w') as file:
            serverPingCsvWritter = csv.DictWriter(file, fieldnames=self.serverPingMonitoringCsvHeader)
            serverPingCsvWritter.writeheader()

        with open(self.networkPingMonitoringCsvFileName, 'w') as file:
            networkPingCsvWritter = csv.DictWriter(file, fieldnames=self.networkPingMonitoringCsvHeader)
            networkPingCsvWritter.writeheader()

    def healthCheckMonitoring(self):
        url = "https://m.elodio.us//restapi/healthCheck"
        headers = {'content-type': 'application/json', 'Accept-Charset': 'application/json'}
        try:
            r = requests.get(url, headers=headers)
            data = [
                {'TimeStamp': datetime.now(), 'Status': r.status_code, 'Response Time(s)': r.elapsed.total_seconds(),
                 'Response(json)': r.text}]
        except Exception or requests.RequestException or requests.HTTPError as err:
            if err.response != None:
                data = [
                    {'TimeStamp': datetime.now(), 'Status': err.response.status_code, 'Response Time(s)': err.response.total_seconds(),
                     'Response(json)': err.response.text}]
            else:
                data = [
                    {'TimeStamp': datetime.now(), 'Status': "NO INTERNET", 'Response Time(s)': "ERROR",
                     'Response(json)': "ERROR"}]
            print("ERROR: ", err)

        with open(self.healthCheckCsvFileName, 'a') as file:
            healthCsvWritter = csv.DictWriter(file, fieldnames=self.healthCheckcsvHeader)
            healthCsvWritter.writerows(data)

        t1 = threading.Timer(1.0, self.healthCheckMonitoring)
        t1.start()
        if "robot" not in (p.name() for p in psutil.process_iter()):
            self.healthCheckTimer += 1
        else:
            self.healthCheckTimer = 0
        if self.healthCheckTimer == 30:
            t1.cancel()
            t1.join()

    def serverPingMonitoring(self):
        try:
            monitor = subprocess.Popen(['ping', '-c 1', 'm.elodio.us'], stdout=subprocess.PIPE)
            output = monitor.stdout.read()
        except Exception as err:
            print("ERROR: ", err)

        if "1 received, 0% packet loss," in str(output):
            status = "PASS"
        else:
            status = "FAIL"

        data = [{'TimeStamp': datetime.now(), 'Status': status, 'Ping Response': str(output)}]

        with open(self.serverPingMonitoringCsvFileName, 'a') as file:
            serverPingCsvWritter = csv.DictWriter(file, fieldnames=self.serverPingMonitoringCsvHeader)
            serverPingCsvWritter.writerows(data)

        t2 = threading.Timer(1.0, self.serverPingMonitoring)
        t2.start()
        if "robot" not in (p.name() for p in psutil.process_iter()):
            self.serverPingMonitorTimer += 1
        else:
            self.serverPingMonitorTimer = 0
        if self.serverPingMonitorTimer == 30:
            t2.cancel()
            t2.join()

    def networkPingMonitoring(self):
        try:
            monitor = subprocess.Popen(['ping', '-c 1', 'google.com'], stdout=subprocess.PIPE)
            output = monitor.stdout.read()
        except Exception as err:
            print("ERROR: ", err)

        if "1 received, 0% packet loss," in str(output):
            status = "PASS"
        else:
            status = "FAIL"

        data = [{'TimeStamp': datetime.now(), 'Status': status, 'Ping Response': str(output)}]

        with open(self.networkPingMonitoringCsvFileName, 'a') as file:
            networkPingCsvWritter = csv.DictWriter(file, fieldnames=self.networkPingMonitoringCsvHeader)
            networkPingCsvWritter.writerows(data)

        t3 = threading.Timer(1.0, self.networkPingMonitoring)
        t3.start()
        if "robot" not in (p.name() for p in psutil.process_iter()):
            self.networkPingMonitorTimer += 1
        else:
            self.networkPingMonitorTimer = 0
        if self.networkPingMonitorTimer == 30:
            t3.cancel()
            t3.join()
