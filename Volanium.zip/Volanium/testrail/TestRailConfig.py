#!/usr/bin/env python

############################################
#
# This File Consist of a Configuration
# required to Update test result over
# the Test Rail
#
############################################

https = "https://"

#Testrail URL
testRailUrl = "elosystemsteam.testrail.com"

#To change Automation Field of Testcase, If 1 then Automation = Yes and 0 then Automation = No
update_automation = 1
