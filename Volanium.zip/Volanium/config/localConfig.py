WEBURL        = ""
SERIALNUMBERS = ""
USERNAMES     = ""
PASSWORDS     = ""

#elo local server settings
eloLocalServerClientUID =  ""
eloLocalServerContractUID = ""
eloLocalPortNumber = ""


#################################          CONFIGURABLE   VARIABLES        #############################################
invitationSenderEmailAdd    = "noreply@localhost-ic.eloci.us"
imapHostId                  = "imap.gmail.com"
invitedUserEmailAdd         = "eloview10@gmail.com"
invitedUserEmailPwd         = "vienna@123"
imapPortNo                  = "993"
eloOneLoginURL              = "https://volansys-dev.onelogin.com"
eloOneLoginUserId           = "dhruvesh.soni@volansystech.com"
eloOneLoginUserPwd          = "EloAuto@54321"
eloCustomeURLPwd            = "EloAuto@54321"
eloOneLoginUserProfileName  = "Dhruvesh"
eloOneLoginCompanyName      = "SAML Test Connector (ELO AUTOMATON)"
spoofUserId                 = ""
spoofUserPwd                = ""
