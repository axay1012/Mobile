#!/usr/bin/env python

############################################################################
#
# This Library deliver keywords enhancement for robotframework MqttLibrary.
#
############################################################################

from MQTTLibrary import MQTTLibrary


class MqttWrapper(MQTTLibrary):
        pass
