#!/usr/bin/env python

#################################################
#
# Test Handler for Web App automation
#
#################################################


class WebHandler:
	
	def __init__(self):
		pass
	
	def setWebPrerequisite(self):
		pass
