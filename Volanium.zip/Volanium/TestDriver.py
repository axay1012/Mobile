#!/usr/bin/env python

###########################################################################
#
# - Test Driver Script for Volanium
#
# - Test Driver Script perform following Operations:
#   1. Input data validation
#   2. Test component validation(E.g. Android, iOS, web)
#   3. Initialize test device handler
#   4. Set test execution Prerequisite
#   5. Trigger the execution of test suite
#
############################################################################

import sys
import os
import getopt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                'commonlib/')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                'testrail/')))
import Common
import VolaniumUsage
import Connectivity
from TestRailConfig import *
from config import *

from commonlib  import CommonVariables

from handler import AndroidHandler
from handler import IosHandler
from handler import CloudHandler
from handler import EmbeddedHandler
from handler import WebHandler

# Global Variables
testSuiteToExec = None
testTagToExec = None
testComponentLst = []
testrailUpdate = None

# Macros
ANDROID = 'android'
IOS = 'ios'
CLOUDFUNCTIONAL = 'cloudfunctional'
CLOUDLOAD = 'cloudload'
WEB = 'web'
EMBEDDED = 'embedded'


class TestDriver:

    def __init__(self):
        self.objCommon = Common.Common()
        self.objUsage = VolaniumUsage.VolaniumUsage()
        self.objConnect = Connectivity.Connectivity()

    def _validateTestSuiteFile(self, testSuiteLst):
        """
        Validate test suite file is available at given path
        """
        suiteList = testSuiteLst.split()
        for suite in suiteList:
            if not self.objCommon.fileExists("{0}.robot".format(suite)):
                print("""
                      -----------------------------------------------------
                      Test Suite Script: %s.robot is not available.
                      Please provide proper location of the Test Suite.
                      -----------------------------------------------------
                      """%suite)
                sys.exit(1)

    def cmdLineParser(self, argv):
        """
        command line parsing and validation
        """
        global testSuiteToExec
        global testTagToExec
        global testComponentLst
        global testrailUpdate

        try:
            opts, args = getopt.getopt(argv, 'h:c:s:t:r:v:u:p:i:', ['component=', 'suite=', 'tag=', 'testrail=', 'vienna=' , 'username=', 'password=', 'runid=', ])
        except getopt.GetoptError:
            self.objUsage.displayUsage()

        for opt, arg in opts:
            if opt in ('-h', '--help'):
                self.objUsage.displayUsage()
            elif opt in ('-c', '--component'):
                testComponentLst = str(arg).split()
                testComponentLst = [elem.lower() for elem in testComponentLst]
            elif opt in ('-t', '--tag'):
                testTagToExec = str(arg)
            elif opt in ('-s', '--suite'):
                testSuiteToExec = str(arg)
            elif opt in ('-r', '--testrail'):
                testrailUpdate = str(arg)
            elif opt in ('-v', '--vienna'):
                server = str(arg)
                configPath = os.path.abspath(os.path.join(os.path.dirname(__file__),'config/'))
                testConfigFile = configPath+"/"+server.lower()+"Config.py"
                if os.path.isfile(testConfigFile):
                    os.environ['SERVER'] = server.lower()
                    os.environ['ENVFILE'] = testConfigFile
                else:
                    print("INFO: File {0} is not provided".format(testConfigFile))
                    print("[Error]: Please provide proper config File\n\n")
                    sys.exit(1)

            elif opt in ('-u', '--username'):
                self.testRailUserName = str(arg)
            elif opt in ('-p', '--password'):
                self.testRailPassword = str(arg)
            elif opt in ('-i', '--runid'):
                self.runId = str(arg)
            else:
                self.objUsage.displayUsage()

        if not (testSuiteToExec and testComponentLst):
            print("""
                  -------------------------------------------
                  Test suite name, component is mandatory
                  for Volanium execution.
                  -------------------------------------------""")
            self.objUsage.displayUsage()

        if testSuiteToExec:
            self._validateTestSuiteFile(testSuiteToExec)

    def _validateTestComponent(self):
        """
        Validate input test components
        """
        try:
            for testModule in testComponentLst:
                if ((testModule != ANDROID) and (testModule != IOS)
                     and (testModule != WEB) and (testModule != CLOUDFUNCTIONAL)
                     and (testModule != CLOUDLOAD) and (testModule != EMBEDDED)):
                    print("\n\nYou have selected invalid test component\n\n")
                    self.objUsage.displayUsage()
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)

    def _initTestHandler(self):
        """
        Initialize test component's handler
        """
        try:
            if ((ANDROID in testComponentLst)
                    and (IOS in testComponentLst)):
                print("""
                       ------------------------------------------- 
                       Framework does not allow to execute Android
                       and iOS component simuntaneously
                       -------------------------------------------""")
                self.objUsage.displayUsage()
            else:
                if ANDROID in testComponentLst:
                    if (str(sys.platform) != 'linux'):
                        print(""""
                        ---------------------------------------------------
                        You can test Android device with Linux system only.
                        Please connect your Android device with Linux system.
                        ---------------------------------------------------""")
                        sys.exit(1)
                    self.objAndroidHndlr = AndroidHandler.AndroidHandler()
                if IOS in testComponentLst:
                    if (str(sys.platform) != 'darwin'):
                        print(""""
                        ---------------------------------------------------
                        You can test iOS device with Mac system only.
                        Please connect your iPhone device with MAC system.
                        ---------------------------------------------------""")
                        sys.exit(1)
                    self.objIosHndlr = IosHandler.IosHandler()
            if CLOUDFUNCTIONAL in testComponentLst:
                self.objCloudHndlr = CloudHandler.CloudHandler()
            if CLOUDLOAD in testComponentLst:
                self.objCloudHndlr = CloudHandler.CloudHandler()
            if EMBEDDED in testComponentLst:
                self.objEmbeddedHndlr = EmbeddedHandler.EmbeddedHandler()
            if WEB in testComponentLst:
                self.objWebHndlr = WebHandler.WebHandler()
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)

    def _setTestPrerequisite(self):
        """
        Set test execution prerequisite for specific component
        """
        try:
            if ANDROID in testComponentLst:
                if not self.objAndroidHndlr.setAndroidPrerequisite(testSuiteToExec, testTagToExec):
                    print("""
                       ----------------------------------------------
                       Failed to set Android prerequisite..
                       Terminating test execution over Android device
                       ----------------------------------------------""")
                    sys.exit(1)
            if IOS in testComponentLst:
                if not self.objIosHndlr.setIosPrerequisite(testSuiteToExec, testTagToExec):
                    print("""
                        --------------------------------------------
                        Failed to set iOS prerequisite..
                        Terminating test execution over iOS device.
                        --------------------------------------------""")
                    sys.exit(1)
            if CLOUDFUNCTIONAL in testComponentLst:
                if not self.objCloudHndlr.setCloudPrerequisite(testSuiteToExec, testTagToExec):
                    print("""
                        ---------------------------------------------
                        Failed to set Cloud Functional prerequisite..
                        Terminating test execution on cloud.
                        ---------------------------------------------""")
                    sys.exit(1)
            if CLOUDLOAD in testComponentLst:
                if not self.objCloudHndlr.setCloudPrerequisite(testSuiteToExec, testTagToExec):
                    print("""
                        ----------------------------------------------
                        Failed to set Cloud Load prerequisite..
                        Terminating test execution on cloud.
                        ----------------------------------------------""")
                    sys.exit(1)
            if EMBEDDED in testComponentLst:
                if not self.objEmbeddedHndlr.setEmbeddedPrerequisite(testSuiteToExec, testTagToExec):
                    print("""
                        ----------------------------------------------
                        Failed to set Embedded Device prerequisite..
                        Terminating test execution on Embedded Device.
                        ----------------------------------------------""")
                    sys.exit(1)
            if WEB in testComponentLst:
                pass
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)

    def _checkEloConnectivity(self):
        """
        Check health monitoring and connectivity of Elo Server
        """
        self.objConnect.generateCSV()
        self.objConnect.healthCheckMonitoring()
        self.objConnect.serverPingMonitoring()
        self.objConnect.networkPingMonitoring()

    def _triggerTestExecution(self):
        """
        Trigger test suite execution over the perticular device
        """
        os.environ["testRailListnerCmd"] = ""

        if (testrailUpdate != None) and (str(testrailUpdate.lower()) == "yes"):
            os.environ["testRailListnerCmd"] = "--listener {0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}:{9}:{10}:{11}".format(
                    "testrail/TestRailListener.py", testRailUrl, self.testRailUserName, self.testRailPassword, self.runId,
                    https, 1, 1, None, None, self.objAndroidHndlr.viennaVersion, self.objAndroidHndlr.deviceVersion
                    )
        try:
            if ANDROID in testComponentLst:
                if not self.objAndroidHndlr.triggerAndroidTestExecution():
                    print("\n\nFailed to trigger test execution over Android device\n\n")
                    sys.exit(1)
            if IOS in testComponentLst:
                if not self.objIosHndlr.triggerIosTestExecution():
                    print("\n\nFailed to trigger test execution over iOS device\n\n")
                    sys.exit(1)
            if CLOUDFUNCTIONAL in testComponentLst:
                if not self.objCloudHndlr.triggerCloudTestExecution():
                    print("\n\nFailed to trigger test execution on Cloud\n\n")
                    sys.exit(1)
            if CLOUDLOAD in testComponentLst:
                if not self.objCloudHndlr.triggerCloudTestExecution():
                    print("\n\nFailed to trigger test execution on Cloud\n\n")
                    sys.exit(1)
            if EMBEDDED in testComponentLst:
                if not self.objEmbeddedHndlr.triggerEmbeddedTestExecution():
                    print("\n\nFailed to trigger test execution on Embedded Device\n\n")
                    sys.exit(1)
            if WEB in testComponentLst:
                pass
        except Exception as err:
            print("ERROR: ", err)
            sys.exit(1)


# Driver entry point
if __name__ == '__main__':

    objDriver = TestDriver()
    if len(sys.argv) < 7:
        objDriver.objUsage.displayUsage()
    else:
        objDriver.cmdLineParser(sys.argv[1:])

    # Validate input test components
    objDriver._validateTestComponent()

    # Init test component handler
    objDriver._initTestHandler()

    # Set test execution prerequisists
    objDriver._setTestPrerequisite()

    # Check Health Monitoring And Network Connectivity
    objDriver._checkEloConnectivity()

    # Trigger test suite execution
    objDriver._triggerTestExecution()
